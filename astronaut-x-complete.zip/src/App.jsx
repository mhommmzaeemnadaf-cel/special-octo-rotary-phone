import React, { useState, useEffect } from 'react';
import { ProgressProvider, useProgress } from './context/ProgressContext';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import CosmosMissionControlCenter from './features/mission-control/CosmosMissionControlCenter';
import IntroSection from './components/IntroSection';
import SolarSystemExplorer from './features/solar-system/SolarSystemExplorer';
import EvaMissionOperationsHub from './features/eva-mission/EvaMissionOperationsHub';
import SpaceGamesArcade from './features/games/SpaceGamesArcade';
import AstronautAcademy from './features/academy/AstronautAcademy';
import NasaMediaExplorer from './features/space-explorer/NasaMediaExplorer';
import RocketBuilder from './features/simulations/RocketBuilder';
import SpaceBiologyLab from './features/space-biology/SpaceBiologyLab';
import SpaceAgriculture from './features/simulations/SpaceAgriculture';
import HabBaseBuilder from './components/HabBaseBuilder';
import MarsWeatherStation from './components/MarsWeatherStation';
import NasaScientificResources from './features/scientific-resources/NasaScientificResources';
import PillarsSection from './components/PillarsSection';
import RoverExplorer from './components/RoverExplorer';
import CadetBadges from './components/CadetBadges';
import MissionDashboardPreview from './components/MissionDashboardPreview';
import HowItWorksSection from './components/HowItWorksSection';
import DiscoverMarsSection from './components/DiscoverMarsSection';
import CtaSection from './components/CtaSection';
import Footer from './components/Footer';
import MissionSimulatorModal from './components/MissionSimulatorModal';
import PresentationModal from './components/PresentationModal';
import CertificateModal from './components/CertificateModal';
import CadetAuthModal from './components/CadetAuthModal';
import StudentLoginPage from './features/auth/StudentLoginPage';
import AstraAssistant from './features/ai-assistant/AstraAssistant';
import HackathonDemoTour from './components/HackathonDemoTour';
import { Bot, Sparkles, Award } from 'lucide-react';

function AppContent() {
  const { recentToast } = useProgress();
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);
  const [isCertificateOpen, setIsCertificateOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isAstraOpen, setIsAstraOpen] = useState(false);
  const [astraPrompt, setAstraPrompt] = useState('');
  const [isDemoTourOpen, setIsDemoTourOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingProgress, setLoadingProgress] = useState(0);

  // View routing (Platform vs Dedicated Student Login Portal)
  const [currentView, setCurrentView] = useState(() => {
    if (typeof window !== 'undefined') {
      const hash = window.location.hash;
      if (hash === '#login' || hash === '#student-login') return 'login';
    }
    return 'platform';
  });

  // Synchronize hash navigation
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash === '#login' || hash === '#student-login') {
        setCurrentView('login');
      } else if (hash === '' || hash === '#platform') {
        setCurrentView('platform');
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Cinematic initial loading sequence
  useEffect(() => {
    const timer = setInterval(() => {
      setLoadingProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(() => setLoading(false), 400);
          return 100;
        }
        return prev + Math.floor(Math.random() * 16) + 10;
      });
    }, 90);

    return () => clearInterval(timer);
  }, []);

  // Global keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.code === 'Space' && !isSimulatorOpen && !isPresentationOpen && !isCertificateOpen) {
        e.preventDefault();
        setIsSimulatorOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSimulatorOpen, isPresentationOpen, isCertificateOpen]);

  const handleOpenLogin = () => {
    setCurrentView('login');
    window.location.hash = '#login';
  };

  const handleBackToMission = () => {
    setCurrentView('platform');
    window.location.hash = '';
  };

  const handleLaunchSimulator = () => {
    setIsSimulatorOpen(true);
  };

  const handleOpenPresentation = () => {
    setIsPresentationOpen(true);
  };

  const handleOpenCertificate = () => {
    setIsCertificateOpen(true);
  };

  const handleOpenAstra = (initialQuestion) => {
    if (initialQuestion) {
      setAstraPrompt(initialQuestion);
    }
    setIsAstraOpen(true);
  };

  const handleNavigateSection = (sectionId) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Dedicated Student Login & Security Clearance Portal View
  if (currentView === 'login') {
    return (
      <div className="relative min-h-screen bg-[#030712] text-[#F8FAFC]">
        <StudentLoginPage
          onBackToMission={handleBackToMission}
          onLoginSuccess={handleBackToMission}
        />
      </div>
    );
  }

  return (
    <div className="relative min-h-screen bg-[#080B12] text-[#F5F1E8] film-grain selection:bg-[#C65B43] selection:text-[#F5F1E8]">
      {/* Precision Loading Sequence */}
      {loading && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#080B12] text-white">
          <div className="w-full max-w-md px-8 text-center">
            {/* Logo Emblem Pulse */}
            <div className="relative w-16 h-16 mx-auto mb-8 flex items-center justify-center">
              <span className="w-16 h-16 rounded-full bg-[#C65B43]/20 animate-ping absolute" />
              <span className="w-12 h-12 rounded-full bg-[#C65B43] shadow-[0_0_40px_#C65B43] flex items-center justify-center font-display font-black text-xl text-white">
                AX
              </span>
            </div>

            <div className="font-mono text-xs tracking-widest text-[#C65B43] uppercase mb-2">
              ESTABLISHING SOLAR SYSTEM TELEMETRY LINK
            </div>
            <div className="font-display text-2xl font-bold tracking-tight text-[#F5F1E8] mb-6">
              ASTRONAUT-X FLIGHT COMMAND
            </div>

            {/* Precision Loading Progress Bar */}
            <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden mb-3 border border-white/10">
              <div
                className="bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#34D399] h-full transition-all duration-150"
                style={{ width: `${Math.min(100, loadingProgress)}%` }}
              />
            </div>

            <div className="flex justify-between text-[10px] font-mono text-[#9298A3]">
              <span>INITIALIZING SOLAR SYSTEM ORRERY & NASA MULTIMEDIA</span>
              <span>{Math.min(100, loadingProgress)}%</span>
            </div>
          </div>
        </div>
      )}

      {/* Floating XP / Achievement Notification Toast */}
      {recentToast && (
        <div className="fixed top-20 right-4 z-50 animate-in slide-in-from-right duration-300">
          <div className="px-4 py-3 rounded-xl bg-[#101827]/95 backdrop-blur-md border border-[#FBBF24]/50 shadow-[0_0_25px_rgba(251,191,36,0.25)] text-white flex items-center space-x-3">
            <Sparkles className="w-5 h-5 text-[#FBBF24] shrink-0" />
            <div className="text-xs font-mono">
              <div className="text-[#FBBF24] font-bold">FLIGHT TELEMETRY LOG:</div>
              <div className="text-white/90">{recentToast.message}</div>
            </div>
          </div>
        </div>
      )}

      {/* Primary Navigation Bar */}
      <Navbar
        onLaunchSimulator={handleLaunchSimulator}
        onOpenPresentation={handleOpenPresentation}
        onOpenAstra={() => handleOpenAstra()}
        onOpenDemoTour={() => setIsDemoTourOpen(true)}
        onOpenCertificate={handleOpenCertificate}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenLogin={handleOpenLogin}
      />

      {/* SECTION 1 — CINEMATIC HERO (WITH THREE.JS MARS CANVAS) */}
      <HeroSection
        onStartMission={handleLaunchSimulator}
        onExploreUniverse={() => handleNavigateSection('nasa-media-explorer')}
        onOpenAcademy={() => handleNavigateSection('astronaut-academy')}
        onOpenAstra={() => handleOpenAstra()}
        onOpenSolarSystem={() => handleNavigateSection('solar-system-explorer')}
        onOpenGames={() => handleNavigateSection('space-games-arcade')}
        onOpenLogin={handleOpenLogin}
      />

      {/* SECTION 2 — BRIEFING & INTRO */}
      <IntroSection />

      {/* 🚀 SECTION 3 — COSMOS MISSION CONTROL CENTER (LIVE TELEMETRY DASHBOARD) */}
      <CosmosMissionControlCenter />

      {/* 🪐 SECTION 4 — INTERACTIVE SOLAR SYSTEM ORRERY & PLANETARY COMMAND */}
      <SolarSystemExplorer
        onSearchNasa={() => handleNavigateSection('nasa-media-explorer')}
        onNavigateSection={handleNavigateSection}
      />

      {/* 👨‍🚀 SECTION 4 — NASA EVA & EXTRAVEHICULAR OPERATIONS HUB */}
      <EvaMissionOperationsHub />

      {/* 🎮 SECTION 5 — SPACE GAMES ARCADE (5 INTERACTIVE SIMULATIONS) */}
      <SpaceGamesArcade />

      {/* 🎓 SECTION 5 — ASTRONAUT ACADEMY (10-STEP SCIENTIFIC CURRICULUM) */}
      <AstronautAcademy />

      {/* 🔭 SECTION 6 — NASA IMAGE & VIDEO LIBRARY MULTIMEDIA EXPLORER */}
      <NasaMediaExplorer
        onAskAstra={(question) => handleOpenAstra(question)}
      />

      {/* 🚀 SECTION 7 — ROCKET BUILDER & PROPULSION ENGINEERING LAB */}
      <RocketBuilder />

      {/* 🧬 SECTION 8 — NASA OSDR SPACE BIOLOGY & CSA NUTRITION LAB */}
      <SpaceBiologyLab />

      {/* 🌱 SECTION 9 — SPACE AGRICULTURE & BIO-REGENERATIVE LIFE SUPPORT */}
      <SpaceAgriculture />

      {/* 🏗️ MARTIAN HABITATION CITY BUILDER SANDBOX */}
      <div id="hab-builder">
        <HabBaseBuilder />
      </div>

      {/* LIVE JPL METEOROLOGY & WEATHER STATION */}
      <div id="meteorology">
        <MarsWeatherStation />
      </div>

      {/* 🛰️ SECTION 9 — NASA SCIENTIFIC RESOURCES (EXOPLANETS, APOD, EYES, GIBS) */}
      <NasaScientificResources />

      {/* SECTION 10 — THE THREE PILLARS OF SURVIVAL */}
      <PillarsSection />

      {/* HARDWARE BLUEPRINT: EXPEDITIONARY ROVER FLEET */}
      <div id="rover-fleet">
        <RoverExplorer />
      </div>

      {/* 🏆 CADET PROGRESSION, XP & FLIGHT BADGES VAULT */}
      <CadetBadges
        onOpenCertificate={handleOpenCertificate}
      />

      {/* SECTION 11 — THE MISSION EXPERIENCE & TELEMETRY DECK */}
      <MissionDashboardPreview
        onOpenSimulator={handleLaunchSimulator}
      />

      {/* SECTION 12 — HOW IT WORKS & SYLLABUS */}
      <HowItWorksSection
        onStartMission={handleLaunchSimulator}
      />

      {/* SECTION 13 — DISCOVER MARS (PLANETARY ARCHIVES) */}
      <DiscoverMarsSection />

      {/* SECTION 14 — FINAL CALL TO ACTION */}
      <CtaSection
        onEnterMissionControl={handleLaunchSimulator}
      />

      {/* FOOTER */}
      <Footer
        onOpenSimulator={handleLaunchSimulator}
        onOpenCertificate={handleOpenCertificate}
      />

      {/* FLOATING ACTION PILL: ASTRA AI copilot shortcut */}
      <div className="fixed bottom-5 right-5 z-40">
        <button
          onClick={() => handleOpenAstra()}
          aria-label="Open ASTRA AI"
          className="group px-4 py-3 rounded-full bg-[#101827]/95 hover:bg-[#182338] border border-[#38BDF8]/50 shadow-[0_0_25px_rgba(56,189,248,0.35)] text-white font-mono text-xs font-bold flex items-center space-x-2 transition-all hover:scale-105 active:scale-95 cursor-pointer"
        >
          <div className="relative">
            <Bot className="w-4 h-4 text-[#38BDF8]" />
            <span className="w-1.5 h-1.5 rounded-full bg-[#34D399] absolute -top-0.5 -right-0.5 animate-pulse" />
          </div>
          <span className="hidden sm:inline">ASTRA AI [A]</span>
        </button>
      </div>

      {/* COMPLETE INTERACTIVE MISSION FLIGHT SIMULATOR */}
      <MissionSimulatorModal
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
      />

      {/* BUILT-IN PITCH DECK & PRESENTATION MODE */}
      <PresentationModal
        isOpen={isPresentationOpen}
        onClose={() => setIsPresentationOpen(false)}
      />

      {/* OFFICIAL FLIGHT WINGS PRINTABLE CERTIFICATE MODAL */}
      <CertificateModal
        isOpen={isCertificateOpen}
        onClose={() => setIsCertificateOpen(false)}
      />

      {/* ASTRONAUT FLIGHT AUTHORIZATION & CADET LOGIN MODAL */}
      <CadetAuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onOpenLogin={handleOpenLogin}
      />

      {/* ASTRA AI EDUCATIONAL COPILOT DRAWER */}
      <AstraAssistant
        isOpen={isAstraOpen}
        onClose={() => setIsAstraOpen(false)}
        initialPrompt={astraPrompt}
        onNavigateSection={handleNavigateSection}
      />

      {/* JUDGES HACKATHON GUIDED DEMO MODE */}
      <HackathonDemoTour
        isOpen={isDemoTourOpen}
        onClose={() => setIsDemoTourOpen(false)}
        onLaunchSimulator={handleLaunchSimulator}
        onOpenCertificate={handleOpenCertificate}
        onNavigateSection={handleNavigateSection}
      />
    </div>
  );
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('NASA Telemetry Boundary Caught Error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#080B12] text-white flex flex-col items-center justify-center p-6 text-center font-mono">
          <div className="w-16 h-16 rounded-full bg-red-950/60 border border-red-500/50 flex items-center justify-center text-red-400 text-2xl mb-4">
            ⚠️
          </div>
          <h1 className="font-display text-2xl font-bold mb-2">TELEMETRY ANOMALY DETECTED</h1>
          <p className="text-sm text-[#94A3B8] max-w-md mb-6">
            A subsystem encounter interrupted rendering. Click below to re-initialize the mission platform.
          </p>
          <button
            onClick={() => {
              this.setState({ hasError: false });
              window.location.hash = '';
              window.location.reload();
            }}
            className="px-6 py-3 rounded-full bg-[#3B82F6] hover:bg-[#2563EB] text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg"
          >
            Re-Initialize Flight Deck
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <ProgressProvider>
        <AppContent />
      </ProgressProvider>
    </ErrorBoundary>
  );
}
