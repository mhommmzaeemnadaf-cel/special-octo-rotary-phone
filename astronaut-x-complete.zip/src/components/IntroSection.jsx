import React, { useState } from 'react';
import { Eye, Wind, Thermometer, ShieldAlert, Sun, ArrowUpRight } from 'lucide-react';
import { soundManager } from '../utils/audio';

export default function IntroSection() {
  const [activeTab, setActiveTab] = useState('environment');

  const handleTabClick = (tab) => {
    soundManager.playClick();
    setActiveTab(tab);
  };

  return (
    <section id="introduction" className="relative py-28 md:py-36 bg-transparent border-t border-white/5 overflow-hidden">
      {/* Subtle atmospheric glow background */}
      <div className="absolute top-1/4 -right-40 w-96 h-96 rounded-full bg-[#C65B43]/10 blur-[140px] pointer-events-none" />
      <div className="absolute bottom-10 -left-40 w-96 h-96 rounded-full bg-[#38BDF8]/10 blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Editorial Subheading & Index */}
        <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#C65B43] uppercase mb-4">
          <span>02 / SECTION</span>
          <span className="w-8 h-[1px] bg-[#C65B43]/50" />
          <span>EDITORIAL MISSION BRIEFING</span>
        </div>

        {/* Section Heading */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end mb-16">
          <div className="lg:col-span-8">
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-[#F5F1E8] uppercase leading-[1.05]">
              A NEW WORLD.
              <span className="block text-[#C65B43]">A NEW CHALLENGE.</span>
            </h2>
          </div>
          <div className="lg:col-span-4">
            <p className="text-sm md:text-base text-[#9298A3] leading-relaxed font-light">
              “Mars represents humanity’s next great frontier. But survival beyond Earth requires preparation, intelligence and courage.”
            </p>
          </div>
        </div>

        {/* Cinematic Mars Landscape Visual Container */}
        <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-[#101827] shadow-2xl mb-16 group">
          {/* Simulated High-Res Mars Landscape Canvas/SVG */}
          <div className="relative h-[360px] md:h-[480px] w-full overflow-hidden bg-gradient-to-b from-[#2B110B] via-[#652416] to-[#0A070B] flex items-center justify-center">
            {/* Ambient Martian dust storm clouds effect */}
            <div className="absolute inset-0 opacity-40 bg-[radial-gradient(circle_at_30%_20%,_rgba(255,140,105,0.4),transparent_60%)]" />
            <div className="absolute inset-0 opacity-30 bg-[radial-gradient(circle_at_75%_65%,_rgba(198,91,67,0.5),transparent_50%)]" />

            {/* Distant Martian Crater Ridge silhouettes */}
            <svg
              className="absolute bottom-0 w-full h-full preserve-3d opacity-90"
              viewBox="0 0 1440 600"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Back mountain ridge */}
              <path
                d="M0 450 Q 220 380 440 430 T 880 390 T 1300 420 L 1440 440 L 1440 600 L 0 600 Z"
                fill="#421811"
                opacity="0.85"
              />
              {/* Mid crater rim */}
              <path
                d="M0 490 Q 300 420 620 480 T 1150 440 L 1440 490 L 1440 600 L 0 600 Z"
                fill="#2E0F0A"
                opacity="0.95"
              />
              {/* Foreground dunes and rocky terrain */}
              <path
                d="M0 540 Q 240 500 500 535 T 1000 515 L 1440 540 L 1440 600 L 0 600 Z"
                fill="#180705"
              />
              {/* Atmospheric orange horizon line */}
              <line x1="0" y1="410" x2="1440" y2="410" stroke="#C65B43" strokeWidth="0.8" opacity="0.3" />
            </svg>

            {/* Astronaut & Hab Telemetry Pins in the Scene */}
            <div className="absolute top-1/3 left-1/4 -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center">
              <div className="relative group/pin cursor-pointer">
                <span className="w-4 h-4 rounded-full bg-[#C65B43] flex items-center justify-center border-2 border-white animate-pulse">
                  <span className="w-1.5 h-1.5 rounded-full bg-white" />
                </span>
                {/* Floating tooltip */}
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-[#080B12]/90 border border-white/10 px-3 py-1.5 rounded-lg text-[10px] font-mono text-[#F5F1E8] whitespace-nowrap backdrop-blur-md opacity-0 group-hover/pin:opacity-100 transition-opacity">
                  HABITATION ALPHA SECTOR (JEZERO DELTA)
                </div>
              </div>
              <span className="text-[10px] font-mono text-[#F5F1E8]/70 mt-1">HAB ALPHA</span>
            </div>

            <div className="absolute top-1/2 right-1/3 -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center">
              <div className="relative group/pin cursor-pointer">
                <span className="w-3.5 h-3.5 rounded-full bg-[#38BDF8] flex items-center justify-center border-2 border-white animate-pulse">
                  <span className="w-1 h-1 rounded-full bg-white" />
                </span>
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-[#080B12]/90 border border-white/10 px-3 py-1.5 rounded-lg text-[10px] font-mono text-[#F5F1E8] whitespace-nowrap backdrop-blur-md opacity-0 group-hover/pin:opacity-100 transition-opacity">
                  SUB-SURFACE REGOLITH ICE EXTRACTION SITE
                </div>
              </div>
              <span className="text-[10px] font-mono text-[#38BDF8]/80 mt-1">H2O DRILL SITE</span>
            </div>

            {/* Overlay Grid lines & Film Grain */}
            <div className="absolute inset-0 telemetry-grid opacity-30 pointer-events-none" />

            {/* Bottom HUD bar on landscape */}
            <div className="absolute bottom-0 inset-x-0 p-6 bg-gradient-to-t from-[#080B12] via-[#080B12]/80 to-transparent flex flex-wrap items-center justify-between text-xs font-mono text-[#F5F1E8] gap-4">
              <div className="flex items-center space-x-3">
                <span className="w-2 h-2 rounded-full bg-[#34D399]" />
                <span>JEZERO CRATER COMPOSITE MOSAIC (MASTCAM-Z SPECTRAL OVERLAY)</span>
              </div>
              <div className="text-[#9298A3] text-[11px]">
                SOL 1042 • 18.38° N, 77.58° E • ELEVATION -2,560 M
              </div>
            </div>
          </div>
        </div>

        {/* Scientific Telemetry Cards (NASA Authenticity - Dribbble Bento Style) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Card 1: Atmospheric Density */}
          <div className="glass-panel-card p-6 rounded-3xl transition-all duration-300 group">
            <div className="flex items-center justify-between mb-4">
              <Wind size={20} className="text-[#C65B43]" />
              <span className="text-[10px] font-mono text-[#94A3B8] tracking-widest uppercase">ATMOSPHERIC PRESSURE</span>
            </div>
            <div className="font-mono text-3xl font-bold text-white mb-1">
              6.1 <span className="text-sm font-normal text-[#94A3B8]">mbar</span>
            </div>
            <p className="text-xs text-[#94A3B8] leading-relaxed">
              Less than 1% of Earth's atmospheric density. 95.3% CO₂, demanding closed-loop life support and MOXIE extraction.
            </p>
          </div>

          {/* Card 2: Surface Temperature */}
          <div className="glass-panel-card p-6 rounded-3xl transition-all duration-300 group">
            <div className="flex items-center justify-between mb-4">
              <Thermometer size={20} className="text-[#38BDF8]" />
              <span className="text-[10px] font-mono text-[#94A3B8] tracking-widest uppercase">MEAN TEMPERATURE</span>
            </div>
            <div className="font-mono text-3xl font-bold text-white mb-1">
              -63°C <span className="text-sm font-normal text-[#94A3B8]">AVG</span>
            </div>
            <p className="text-xs text-[#94A3B8] leading-relaxed">
              Swings from +20°C at noon to -125°C at the poles. Extreme thermal cycling tests habitat insulation materials.
            </p>
          </div>

          {/* Card 3: Surface Gravity */}
          <div className="glass-panel-card p-6 rounded-3xl transition-all duration-300 group">
            <div className="flex items-center justify-between mb-4">
              <Sun size={20} className="text-[#FBBF24]" />
              <span className="text-[10px] font-mono text-[#94A3B8] tracking-widest uppercase">SURFACE GRAVITY</span>
            </div>
            <div className="font-mono text-3xl font-bold text-white mb-1">
              0.38 <span className="text-sm font-normal text-[#94A3B8]">g</span>
            </div>
            <p className="text-xs text-[#94A3B8] leading-relaxed">
              38% of Earth's gravitational pull. Requires daily resistance training counter-measures to preserve bone density.
            </p>
          </div>

          {/* Card 4: Radiation Environment */}
          <div className="glass-panel-card p-6 rounded-3xl transition-all duration-300 group">
            <div className="flex items-center justify-between mb-4">
              <ShieldAlert size={20} className="text-[#F87171]" />
              <span className="text-[10px] font-mono text-[#94A3B8] tracking-widest uppercase">COSMIC RADIATION</span>
            </div>
            <div className="font-mono text-3xl font-bold text-white mb-1">
              300 <span className="text-sm font-normal text-[#94A3B8]">mSv/yr</span>
            </div>
            <p className="text-xs text-[#94A3B8] leading-relaxed">
              No global magnetosphere. Crew must utilize regolith shielding berms and subterranean lava tubes during solar proton events.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
