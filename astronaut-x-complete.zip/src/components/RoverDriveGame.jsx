import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, Battery, Sparkles, Navigation, Award, AlertCircle, Compass, Zap } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../utils/audio';

const GAME_WIDTH = 760;
const GAME_HEIGHT = 440;

const INITIAL_SAMPLES = [
  { id: 1, x: 160, y: 120, name: 'Sedimentary Mudstone', collected: false },
  { id: 2, x: 580, y: 110, name: 'Olivine Basalt', collected: false },
  { id: 3, x: 380, y: 220, name: 'Clay Delta Matrix', collected: false },
  { id: 4, x: 190, y: 340, name: 'Igneous Crust Core', collected: false },
  { id: 5, x: 620, y: 320, name: 'Ancient Biosignature', collected: false },
];

const BOULDERS = [
  { x: 260, y: 160, r: 24 },
  { x: 480, y: 180, r: 30 },
  { x: 320, y: 320, r: 26 },
  { x: 500, y: 340, r: 22 },
  { x: 120, y: 240, r: 28 },
];

export default function RoverDriveGame() {
  const canvasRef = useRef(null);
  const [gameState, setGameState] = useState('ready'); // ready, playing, won, dead
  const [score, setScore] = useState(0);
  const [battery, setBattery] = useState(100);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [helicopterActive, setHelicopterActive] = useState(false);

  // Rover physics state refs to avoid re-renders on every animation frame
  const roverRef = useRef({
    x: 80,
    y: 220,
    angle: 0,
    speed: 0,
    maxSpeed: 3.2,
    accel: 0.14,
    friction: 0.94,
    steerSpeed: 0.055,
  });

  const keysRef = useRef({
    up: false,
    down: false,
    left: false,
    right: false,
  });

  const samplesRef = useRef(JSON.parse(JSON.stringify(INITIAL_SAMPLES)));
  const helicopterRef = useRef({ x: -100, y: -100, active: false });

  // Key listeners
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (['ArrowUp', 'KeyW'].includes(e.code)) keysRef.current.up = true;
      if (['ArrowDown', 'KeyS'].includes(e.code)) keysRef.current.down = true;
      if (['ArrowLeft', 'KeyA'].includes(e.code)) keysRef.current.left = true;
      if (['ArrowRight', 'KeyD'].includes(e.code)) keysRef.current.right = true;
      if (e.code === 'KeyH') deployHelicopter();
    };

    const handleKeyUp = (e) => {
      if (['ArrowUp', 'KeyW'].includes(e.code)) keysRef.current.up = false;
      if (['ArrowDown', 'KeyS'].includes(e.code)) keysRef.current.down = false;
      if (['ArrowLeft', 'KeyA'].includes(e.code)) keysRef.current.left = false;
      if (['ArrowRight', 'KeyD'].includes(e.code)) keysRef.current.right = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState]);

  // Game loop
  useEffect(() => {
    if (gameState !== 'playing') return;

    let animId;
    let lastTime = performance.now();

    const loop = (time) => {
      const dt = (time - lastTime) / 1000;
      lastTime = time;

      const rover = roverRef.current;
      const keys = keysRef.current;

      // Steering
      if (keys.left) rover.angle -= rover.steerSpeed;
      if (keys.right) rover.angle += rover.steerSpeed;

      // Acceleration
      if (keys.up) {
        rover.speed = Math.min(rover.maxSpeed, rover.speed + rover.accel);
        setBattery((b) => Math.max(0, b - 0.035));
      } else if (keys.down) {
        rover.speed = Math.max(-rover.maxSpeed * 0.5, rover.speed - rover.accel);
        setBattery((b) => Math.max(0, b - 0.02));
      } else {
        rover.speed *= rover.friction;
      }

      // Update position
      rover.x += Math.cos(rover.angle) * rover.speed;
      rover.y += Math.sin(rover.angle) * rover.speed;

      // Screen boundary clamp
      rover.x = Math.max(25, Math.min(GAME_WIDTH - 25, rover.x));
      rover.y = Math.max(25, Math.min(GAME_HEIGHT - 25, rover.y));

      // Boulder collisions
      BOULDERS.forEach((b) => {
        const dx = rover.x - b.x;
        const dy = rover.y - b.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < b.r + 18) {
          // Bounce off boulder
          rover.speed = -rover.speed * 0.6;
          rover.x += (dx / dist) * 4;
          rover.y += (dy / dist) * 4;
          soundManager.playClick();
        }
      });

      // Sample collection detection
      samplesRef.current.forEach((sample) => {
        if (!sample.collected) {
          const dx = rover.x - sample.x;
          const dy = rover.y - sample.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 26) {
            sample.collected = true;
            soundManager.playRadarPing();
            setScore((s) => {
              const newScore = s + 1;
              if (newScore === 5) {
                // Victory!
                setGameState('won');
                soundManager.playSuccess();
                try {
                  confetti({
                    particleCount: 90,
                    spread: 70,
                    origin: { y: 0.6 },
                    colors: ['#C65B43', '#38BDF8', '#34D399', '#FBBF24'],
                  });
                } catch (e) {}
              }
              return newScore;
            });
          }
        }
      });

      // Battery death check
      setBattery((b) => {
        if (b <= 0 && gameState === 'playing') {
          setGameState('dead');
          soundManager.playWarning();
          return 0;
        }
        return b;
      });

      // Draw frame
      renderFrame();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);

    // Timer
    const timerInterval = setInterval(() => {
      setElapsedTime((t) => t + 1);
    }, 1000);

    return () => {
      cancelAnimationFrame(animId);
      clearInterval(timerInterval);
    };
  }, [gameState]);

  // Render Canvas
  const renderFrame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const rover = roverRef.current;

    // Draw Jezero Crater Terrain Background
    ctx.fillStyle = '#110C0B';
    ctx.fillRect(0, 0, GAME_WIDTH, GAME_HEIGHT);

    // Crater sandy ridges & dunes
    ctx.fillStyle = 'rgba(198, 91, 67, 0.08)';
    ctx.beginPath();
    ctx.ellipse(380, 220, 320, 160, 0.1, 0, Math.PI * 2);
    ctx.fill();

    // Subtle Grid Overlay
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 1;
    for (let x = 0; x < GAME_WIDTH; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, GAME_HEIGHT);
      ctx.stroke();
    }
    for (let y = 0; y < GAME_HEIGHT; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(GAME_WIDTH, y);
      ctx.stroke();
    }

    // Draw Boulders (Obstacles)
    BOULDERS.forEach((b) => {
      ctx.fillStyle = '#221512';
      ctx.strokeStyle = '#4A2A22';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Boulder highlight rim
      ctx.strokeStyle = 'rgba(245, 185, 165, 0.2)';
      ctx.beginPath();
      ctx.arc(b.x - b.r * 0.2, b.y - b.r * 0.2, b.r * 0.6, 0, Math.PI);
      ctx.stroke();
    });

    // Draw Geological Rock Core Samples (Collectibles)
    samplesRef.current.forEach((s) => {
      if (!s.collected) {
        // Glowing aura
        ctx.fillStyle = 'rgba(56, 189, 248, 0.15)';
        ctx.beginPath();
        ctx.arc(s.x, s.y, 16, 0, Math.PI * 2);
        ctx.fill();

        // Core jewel
        ctx.fillStyle = '#38BDF8';
        ctx.shadowColor = '#38BDF8';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.arc(s.x, s.y, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        // Label
        ctx.fillStyle = '#9298A3';
        ctx.font = '9px JetBrains Mono, monospace';
        ctx.fillText(s.name, s.x - 30, s.y - 10);
      }
    });

    // Draw Rover Tracks behind rover
    ctx.fillStyle = 'rgba(198, 91, 67, 0.25)';
    ctx.beginPath();
    ctx.arc(rover.x - Math.cos(rover.angle) * 16, rover.y - Math.sin(rover.angle) * 16, 3, 0, Math.PI * 2);
    ctx.fill();

    // Draw Perseverance Rover
    ctx.save();
    ctx.translate(rover.x, rover.y);
    ctx.rotate(rover.angle);

    // Rover Body (Rectangular Chassis)
    ctx.fillStyle = '#1E293B';
    ctx.strokeStyle = '#C65B43';
    ctx.lineWidth = 2;
    ctx.fillRect(-18, -12, 36, 24);
    ctx.strokeRect(-18, -12, 36, 24);

    // Mastcam Turret Front Dot
    ctx.fillStyle = '#38BDF8';
    ctx.beginPath();
    ctx.arc(12, 0, 4, 0, Math.PI * 2);
    ctx.fill();

    // 6 Wheels (Rocker Bogie)
    ctx.fillStyle = '#0F172A';
    ctx.fillRect(-16, -16, 10, 4);
    ctx.fillRect(6, -16, 10, 4);
    ctx.fillRect(-16, 12, 10, 4);
    ctx.fillRect(6, 12, 10, 4);

    // MMRTG Nuclear Generator rear
    ctx.fillStyle = '#FBBF24';
    ctx.fillRect(-18, -4, 4, 8);

    ctx.restore();

    // Draw Ingenuity Helicopter if active
    if (helicopterRef.current.active) {
      const h = helicopterRef.current;
      h.x += 3.5;
      h.y -= 1.2;
      ctx.fillStyle = '#34D399';
      ctx.beginPath();
      ctx.arc(h.x, h.y, 6, 0, Math.PI * 2);
      ctx.fill();
      // Rotor blur
      ctx.strokeStyle = 'rgba(52, 211, 153, 0.6)';
      ctx.beginPath();
      ctx.ellipse(h.x, h.y, 18, 4, 0, 0, Math.PI * 2);
      ctx.stroke();
      if (h.x > GAME_WIDTH + 50) {
        helicopterRef.current.active = false;
        setHelicopterActive(false);
      }
    }
  };

  const startGame = () => {
    soundManager.playLaunch();
    samplesRef.current = JSON.parse(JSON.stringify(INITIAL_SAMPLES));
    roverRef.current = {
      x: 80,
      y: 220,
      angle: 0,
      speed: 0,
      maxSpeed: 3.2,
      accel: 0.14,
      friction: 0.94,
      steerSpeed: 0.055,
    };
    setScore(0);
    setBattery(100);
    setElapsedTime(0);
    setGameState('playing');
  };

  const deployHelicopter = () => {
    if (helicopterActive || gameState !== 'playing') return;
    soundManager.playQuindar(true);
    setHelicopterActive(true);
    helicopterRef.current = {
      x: roverRef.current.x,
      y: roverRef.current.y,
      active: true,
    };
  };

  return (
    <section className="py-24 bg-[#080B12] border-t border-white/5 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#34D399] uppercase mb-3">
              <span className="w-2 h-2 rounded-full bg-[#34D399] animate-pulse" />
              <span>INTERACTIVE ARCADE SIMULATOR // CADET MISSION 02</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#F5F1E8] uppercase">
              JEZERO DELTA ROVER EXPEDITION
            </h2>
          </div>
          <p className="max-w-md text-sm text-[#9298A3] font-light leading-relaxed">
            Drive the Perseverance rover across the Jezero delta. Collect all 5 geological core samples before battery depletion. Deploy Ingenuity Helicopter for aerial reconnaissance!
          </p>
        </div>

        {/* Game Canvas Container */}
        <div className="p-6 sm:p-8 rounded-3xl bg-[#101827] border border-white/10 shadow-2xl relative overflow-hidden">
          {/* Top Game HUD Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4 font-mono text-xs">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-2">
                <span className="text-[#9298A3]">CORES CACHED:</span>
                <span className="text-xl font-bold text-[#38BDF8]">{score} / 5</span>
              </div>
              <div className="flex items-center space-x-2">
                <Battery size={15} className={battery > 25 ? 'text-[#34D399]' : 'text-[#F87171] animate-bounce'} />
                <span className="text-[#9298A3]">BATTERY:</span>
                <span className={`text-xl font-bold ${battery > 25 ? 'text-[#34D399]' : 'text-[#F87171]'}`}>
                  {Math.round(battery)}%
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-[#9298A3]">SOL ELAPSED:</span>
                <span className="text-xl font-bold text-[#F5F1E8]">{elapsedTime}s</span>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center space-x-3">
              <button
                onClick={deployHelicopter}
                disabled={helicopterActive || gameState !== 'playing'}
                className="px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 disabled:opacity-30 border border-white/10 text-xs text-[#34D399] font-mono flex items-center space-x-1.5 transition-all"
              >
                <span>🚁</span>
                <span>DEPLOY INGENUITY [H]</span>
              </button>

              <button
                onClick={startGame}
                className="px-4 py-1.5 rounded-xl bg-[#C65B43] hover:bg-[#b04a34] text-xs text-white font-mono font-bold flex items-center space-x-1.5 shadow-[0_0_15px_rgba(198,91,67,0.4)] transition-all"
              >
                <RotateCcw size={13} />
                <span>{gameState === 'ready' ? 'START MISSION' : 'RESTART'}</span>
              </button>
            </div>
          </div>

          {/* Main 2D Canvas Area */}
          <div className="relative w-full h-[360px] sm:h-[440px] bg-[#110C0B] rounded-2xl border border-white/10 overflow-hidden flex items-center justify-center">
            <canvas
              ref={canvasRef}
              width={GAME_WIDTH}
              height={GAME_HEIGHT}
              className="w-full h-full"
            />

            {/* Start Screen Overlay */}
            {gameState === 'ready' && (
              <div className="absolute inset-0 bg-black/75 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
                <div className="w-14 h-14 rounded-2xl bg-[#C65B43]/20 border border-[#C65B43]/50 flex items-center justify-center text-2xl mb-4">
                  🏎️
                </div>
                <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F1E8] mb-2 uppercase">
                  READY TO PILOT THE PERSEVERANCE ROVER?
                </h3>
                <p className="text-xs text-[#9298A3] max-w-md mb-6 leading-relaxed font-light">
                  Use your Arrow Keys or [W, A, S, D] to steer and accelerate. Avoid dark basalt boulders and navigate to all 5 glowing rock sample sites before battery runs out.
                </p>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-full bg-[#C65B43] hover:bg-[#b04a34] text-white font-mono text-xs font-bold tracking-wider transition-all shadow-[0_0_25px_rgba(198,91,67,0.5)] flex items-center space-x-2"
                >
                  <Play size={14} className="fill-current" />
                  <span>COMMENCE SURFACE EXPEDITION</span>
                </button>
              </div>
            )}

            {/* Victory Overlay */}
            {gameState === 'won' && (
              <div className="absolute inset-0 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in zoom-in-95">
                <div className="w-16 h-16 rounded-full bg-[#34D399]/20 border border-[#34D399]/50 flex items-center justify-center text-3xl mb-4">
                  🏆
                </div>
                <h3 className="font-display text-3xl sm:text-4xl font-bold text-[#F5F1E8] mb-2 uppercase">
                  EXPEDITION SUCCESS: 5/5 CORES SEALED!
                </h3>
                <p className="text-xs text-[#9298A3] max-w-md mb-6 leading-relaxed font-light">
                  Outstanding driving, Cadet! All 5 biosignature core samples have been hermetically sealed inside titanium tubes for the Mars Sample Return mission. Time: {elapsedTime}s.
                </p>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-full bg-[#34D399] hover:bg-[#2bb882] text-black font-mono text-xs font-bold tracking-wider transition-all shadow-[0_0_25px_rgba(52,211,153,0.5)] flex items-center space-x-2"
                >
                  <RotateCcw size={14} />
                  <span>PLAY AGAIN / IMPROVE TIME</span>
                </button>
              </div>
            )}

            {/* Battery Depleted Overlay */}
            {gameState === 'dead' && (
              <div className="absolute inset-0 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
                <div className="w-14 h-14 rounded-2xl bg-[#F87171]/20 border border-[#F87171]/50 flex items-center justify-center text-2xl mb-4">
                  ⚠️
                </div>
                <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#F87171] mb-2 uppercase">
                  BATTERY DEPLETED IN JEZERO BASIN
                </h3>
                <p className="text-xs text-[#9298A3] max-w-md mb-6 leading-relaxed font-light">
                  The MMRTG nuclear batteries could not maintain propulsion before all samples were cached. Optimize your traverse path to conserve energy.
                </p>
                <button
                  onClick={startGame}
                  className="px-8 py-3 rounded-full bg-[#C65B43] hover:bg-[#b04a34] text-white font-mono text-xs font-bold tracking-wider transition-all shadow-[0_0_20px_rgba(198,91,67,0.4)] flex items-center space-x-2"
                >
                  <RotateCcw size={14} />
                  <span>RETRY ROVER EXPEDITION</span>
                </button>
              </div>
            )}
          </div>

          {/* On-Screen Touch D-Pad for Mobile & Accessibility */}
          <div className="mt-6 flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/5">
            <div className="text-xs font-mono text-[#9298A3]">
              CONTROLS: <strong className="text-white">[W / ↑] ACCEL</strong> • <strong className="text-white">[S / ↓] REVERSE</strong> • <strong className="text-white">[A / D / ← / →] STEER</strong> • <strong className="text-[#34D399]">[H] HELICOPTER</strong>
            </div>

            {/* Tactile Touch Buttons */}
            <div className="flex items-center space-x-2">
              <button
                onMouseDown={() => (keysRef.current.left = true)}
                onMouseUp={() => (keysRef.current.left = false)}
                onTouchStart={() => (keysRef.current.left = true)}
                onTouchEnd={() => (keysRef.current.left = false)}
                className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 active:bg-[#C65B43] flex items-center justify-center font-bold text-sm"
              >
                ◀
              </button>
              <button
                onMouseDown={() => (keysRef.current.up = true)}
                onMouseUp={() => (keysRef.current.up = false)}
                onTouchStart={() => (keysRef.current.up = true)}
                onTouchEnd={() => (keysRef.current.up = false)}
                className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 active:bg-[#C65B43] flex items-center justify-center font-bold text-sm"
              >
                ▲
              </button>
              <button
                onMouseDown={() => (keysRef.current.down = true)}
                onMouseUp={() => (keysRef.current.down = false)}
                onTouchStart={() => (keysRef.current.down = true)}
                onTouchEnd={() => (keysRef.current.down = false)}
                className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 active:bg-[#C65B43] flex items-center justify-center font-bold text-sm"
              >
                ▼
              </button>
              <button
                onMouseDown={() => (keysRef.current.right = true)}
                onMouseUp={() => (keysRef.current.right = false)}
                onTouchStart={() => (keysRef.current.right = true)}
                onTouchEnd={() => (keysRef.current.right = false)}
                className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 active:bg-[#C65B43] flex items-center justify-center font-bold text-sm"
              >
                ▶
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
