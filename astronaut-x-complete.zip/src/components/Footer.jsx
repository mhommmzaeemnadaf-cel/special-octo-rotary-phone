import React from 'react';
import { ArrowUp, Orbit, Radio, Globe, ShieldAlert, Award } from 'lucide-react';
import { soundManager } from '../utils/audio';
import { NASA_DISCLAIMER_TEXT } from './NasaAttribution';

export default function Footer({ onOpenSimulator, onOpenCertificate }) {
  const scrollToTop = () => {
    soundManager.playClick();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-transparent border-t border-white/10 pt-16 pb-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-white/10">
          {/* Brand & Project Info */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#C65B43] to-[#8F3724] border border-white/20 flex items-center justify-center font-display font-black text-white text-base shadow-[0_0_20px_rgba(198,91,67,0.4)]">
                AX
              </div>
              <span className="font-display font-extrabold tracking-widest text-lg text-white">
                ASTRONAUT-X
              </span>
            </div>

            <p className="text-xs text-[#94A3B8] leading-relaxed max-w-sm font-normal">
              THE NEXT GENERATION OF SPACE EXPLORERS STARTS HERE. TRAIN. EXPLORE. DISCOVER. BECOME A COMMANDER.
              Synthesizing primary NASA research, orbital physics models, and authentic multimedia exploration.
            </p>

            <div className="p-4 rounded-2xl glass-panel-card text-[11px] text-[#94A3B8] leading-relaxed flex items-start space-x-2.5">
              <ShieldAlert className="w-4 h-4 text-[#FBBF24] shrink-0 mt-0.5" />
              <p>{NASA_DISCLAIMER_TEXT}</p>
            </div>
          </div>

          {/* Core Modules Links */}
          <div className="md:col-span-3">
            <h4 className="font-mono text-xs text-white tracking-widest uppercase mb-4 font-bold">
              PLATFORM HUBS
            </h4>
            <ul className="space-y-2 text-xs font-mono text-[#94A3B8]">
              <li>
                <a href="#solar-system-explorer" className="hover:text-white transition-colors">
                  • Keplerian Solar System Orrery
                </a>
              </li>
              <li>
                <a href="#space-games-arcade" className="hover:text-white transition-colors">
                  • 6-in-1 Space Simulations Arcade
                </a>
              </li>
              <li>
                <a href="#space-biology-lab" className="hover:text-white transition-colors">
                  • NASA OSDR Space Biology & CSA Food
                </a>
              </li>
              <li>
                <a href="#astronaut-academy" className="hover:text-white transition-colors">
                  • Astronaut Academy (10-Step Lessons)
                </a>
              </li>
              <li>
                <a href="#nasa-media-explorer" className="hover:text-white transition-colors">
                  • NASA Image & Video Library
                </a>
              </li>
              <li>
                <a href="#rocket-builder" className="hover:text-white transition-colors">
                  • Rocket Propulsion Engineering
                </a>
              </li>
              <li>
                <a href="#scientific-resources" className="hover:text-white transition-colors">
                  • DONKI Space Weather & Mars Trek
                </a>
              </li>
            </ul>
          </div>

          {/* NASA Data Telemetry Attribution */}
          <div className="md:col-span-3">
            <h4 className="font-mono text-xs text-white tracking-widest uppercase mb-4 font-bold">
              PRIMARY DATA SOURCES
            </h4>
            <div className="space-y-2 text-xs font-mono text-[#94A3B8]">
              <div className="flex justify-between">
                <span>IMAGE & VIDEO:</span>
                <span className="text-[#38BDF8]">images-api.nasa.gov</span>
              </div>
              <div className="flex justify-between">
                <span>SPACE WEATHER:</span>
                <span className="text-[#FBBF24]">NASA DONKI (CCMC)</span>
              </div>
              <div className="flex justify-between">
                <span>SPACE BIOLOGY:</span>
                <span className="text-[#EC4899]">NASA OSDR & RadLab</span>
              </div>
              <div className="flex justify-between">
                <span>TOPOGRAPHY:</span>
                <span className="text-[#34D399]">NASA Mars Trek</span>
              </div>
              <div className="flex justify-between">
                <span>PARTNER TOOLKIT:</span>
                <span className="text-white">Canadian Space Agency</span>
              </div>
            </div>
          </div>

          {/* Back to top button */}
          <div className="md:col-span-1 flex flex-col items-start md:items-end justify-between">
            <button
              onClick={scrollToTop}
              className="p-3.5 rounded-full glass-panel border border-white/10 hover:border-[#C65B43] text-[#94A3B8] hover:text-white transition-all group cursor-pointer shadow-lg"
              title="Return to Top"
            >
              <ArrowUp size={16} className="group-hover:-translate-y-0.5 transition-transform text-[#38BDF8]" />
            </button>
          </div>
        </div>

        {/* Bottom copyright line */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs font-mono text-[#9298A3] gap-4">
          <div>
            © 2026 ASTRONAUT-X • All NASA media is credited to respective missions and archival centers.
          </div>
          <div className="flex items-center space-x-4">
            <button
              onClick={scrollToTop}
              className="hover:text-white transition-colors cursor-pointer"
            >
              TOP
            </button>
            <span>•</span>
            <span className="text-[#38BDF8]">MISSION STATUS: NOMINAL</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
