import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, Activity, ArrowUpRight, Sparkles, Scale, Gauge, Compass } from 'lucide-react';
import { soundManager } from '../utils/audio';

const WORLDS = [
  { id: 'earth', name: 'Planet Earth', g: 9.81, color: '#38BDF8', desc: 'Standard 1.00g terrestrial gravity.' },
  { id: 'mars', name: 'Planet Mars', g: 3.72, color: '#C65B43', desc: '0.38g gravity. You jump 2.6× higher!' },
  { id: 'moon', name: 'The Moon', g: 1.62, color: '#FBBF24', desc: '0.16g gravity. Bounding lunar strides.' },
  { id: 'jupiter', name: 'Planet Jupiter', g: 24.79, color: '#A855F7', desc: '2.53g crushing gravity. Intense weight.' },
];

const OBJECTS = [
  { id: 'jump', name: 'Astronaut Jump', defaultVel: 5.5, defaultAngle: 85, icon: '🧑‍🚀' },
  { id: 'basketball', name: 'Basketball Shot', defaultVel: 9.0, defaultAngle: 55, icon: '🏀' },
  { id: 'baseball', name: 'Baseball Pitch', defaultVel: 35.0, defaultAngle: 35, icon: '⚾' },
  { id: 'rocket', name: 'Mini Model Rocket', defaultVel: 45.0, defaultAngle: 75, icon: '🚀' },
];

export default function GravityPlayground() {
  const canvasRef = useRef(null);
  const [selectedWorldId, setSelectedWorldId] = useState('mars');
  const [selectedObjectId, setSelectedObjectId] = useState('jump');
  const [velocity, setVelocity] = useState(5.5); // m/s
  const [angle, setAngle] = useState(85); // degrees
  const [isSimulating, setIsSimulating] = useState(false);
  const [simResults, setSimResults] = useState(null);

  const world = WORLDS.find((w) => w.id === selectedWorldId) || WORLDS[1];
  const obj = OBJECTS.find((o) => o.id === selectedObjectId) || OBJECTS[0];

  // Physics Calculations
  const angleRad = (angle * Math.PI) / 180;
  const vx = velocity * Math.cos(angleRad);
  const vy = velocity * Math.sin(angleRad);
  const flightTime = (2 * vy) / world.g;
  const maxHeight = (vy * vy) / (2 * world.g);
  const maxDistance = vx * flightTime;

  // Earth comparison for instant learning
  const earthMaxHeight = (vy * vy) / (2 * 9.81);
  const heightMultiplier = (maxHeight / Math.max(0.01, earthMaxHeight)).toFixed(1);

  // Animation Loop on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Draw background grid & terrain
    ctx.clearRect(0, 0, width, height);

    // Floor ground line
    const groundY = height - 40;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, groundY);
    ctx.lineTo(width, groundY);
    ctx.stroke();

    // Scale calculation to fit canvas:
    // We want max distance + 20% margin to fit within canvas width
    const scaleX = Math.min(25, (width - 100) / Math.max(12, maxDistance * 1.3));
    const scaleY = Math.min(25, (height - 80) / Math.max(8, maxHeight * 1.4));
    const startX = 50;

    // Draw Earth trajectory comparison in faint grey if not currently on Earth
    if (world.id !== 'earth') {
      const eFlightTime = (2 * vy) / 9.81;
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      for (let t = 0; t <= eFlightTime; t += 0.05) {
        const x = startX + vx * t * scaleX;
        const y = groundY - (vy * t - 0.5 * 9.81 * t * t) * scaleY;
        if (t === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Draw Active World Trajectory Arc
    ctx.beginPath();
    ctx.strokeStyle = world.color;
    ctx.lineWidth = 3;
    ctx.shadowColor = world.color;
    ctx.shadowBlur = 10;

    const points = [];
    for (let t = 0; t <= flightTime; t += 0.04) {
      const x = startX + vx * t * scaleX;
      const y = groundY - (vy * t - 0.5 * world.g * t * t) * scaleY;
      points.push({ x, y, t });
      if (t === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    // Final point at impact
    const finalX = startX + maxDistance * scaleX;
    points.push({ x: finalX, y: groundY, t: flightTime });
    ctx.lineTo(finalX, groundY);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Draw Peak Apex Point Marker
    const apexX = startX + (vx * (vy / world.g)) * scaleX;
    const apexY = groundY - maxHeight * scaleY;
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(apexX, apexY, 5, 0, Math.PI * 2);
    ctx.fill();

    // Apex height label
    ctx.fillStyle = world.color;
    ctx.font = '10px JetBrains Mono, monospace';
    ctx.fillText(`${maxHeight.toFixed(2)}m PEAK`, apexX - 25, apexY - 12);

    // Landing marker
    ctx.fillStyle = '#34D399';
    ctx.beginPath();
    ctx.arc(finalX, groundY, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillText(`${maxDistance.toFixed(1)}m`, finalX - 10, groundY + 22);

    // Launch origin marker
    ctx.fillStyle = '#FFFFFF';
    ctx.fillText(obj.icon, startX - 12, groundY - 12);

  }, [world, obj, velocity, angle, maxHeight, maxDistance, flightTime]);

  const handleLaunch = () => {
    soundManager.playThruster();
    setIsSimulating(true);
    setSimResults({
      time: flightTime.toFixed(2),
      height: maxHeight.toFixed(2),
      dist: maxDistance.toFixed(2),
      multiplier: heightMultiplier,
    });
    setTimeout(() => setIsSimulating(false), 800);
  };

  const handleSelectObject = (o) => {
    soundManager.playClick();
    setSelectedObjectId(o.id);
    setVelocity(o.defaultVel);
    setAngle(o.defaultAngle);
  };

  return (
    <section className="py-24 bg-[#080B12] border-t border-white/5 relative overflow-hidden">
      {/* Background Subtle Gradient */}
      <div className="absolute top-1/3 right-1/4 w-[500px] h-[300px] bg-[#C65B43]/10 blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#C65B43] uppercase mb-3">
              <span className="w-2 h-2 rounded-full bg-[#C65B43] animate-ping" />
              <span>INTERACTIVE PHYSICS PLAYGROUND // 0.38g EXPERIMENT</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#F5F1E8] uppercase">
              MARTIAN GRAVITY SIMULATOR
            </h2>
          </div>
          <p className="max-w-md text-sm text-[#9298A3] font-light leading-relaxed">
            How high can you jump on Mars? Adjust launch speed, launch angle, and switch planetary gravities to visualize real ballistic trajectories!
          </p>
        </div>

        {/* Main Simulator Canvas & Controls Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Canvas Display: 7 Cols */}
          <div className="lg:col-span-8 p-6 sm:p-8 rounded-3xl bg-[#101827] border border-white/10 shadow-2xl relative overflow-hidden flex flex-col justify-between">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4 font-mono text-xs">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: world.color }} />
                <span className="font-bold text-[#F5F1E8]">{world.name.toUpperCase()} (g = {world.g} m/s²)</span>
              </div>
              <div className="text-[#9298A3] flex items-center space-x-4">
                <span>DASHED LINE: <strong className="text-white/60">EARTH (1.0g)</strong></span>
                <span>SOLID LINE: <strong style={{ color: world.color }}>{world.name.split(' ')[1]}</strong></span>
              </div>
            </div>

            {/* Ballistics Canvas */}
            <div className="w-full h-[320px] sm:h-[380px] bg-[#080B12] rounded-2xl border border-white/5 relative overflow-hidden flex items-center justify-center mb-6">
              <canvas
                ref={canvasRef}
                width={760}
                height={380}
                className="w-full h-full"
              />
              <div className="absolute top-4 left-4 text-[10px] font-mono text-[#9298A3]/70">
                TRAJECTORY INTEGRATION // PARABOLIC DISPLACEMENT
              </div>
            </div>

            {/* Real-Time Physics Telemetry Readouts */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-mono">
              <div className="p-3.5 rounded-xl bg-[#080B12]/80 border border-white/5">
                <div className="text-[10px] text-[#9298A3] mb-1">MAX HEIGHT</div>
                <div className="text-xl font-bold text-[#F5F1E8]">{maxHeight.toFixed(2)} m</div>
                <div className="text-[10px] text-[#34D399] mt-0.5">{heightMultiplier}× Earth Height</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#080B12]/80 border border-white/5">
                <div className="text-[10px] text-[#9298A3] mb-1">HANG TIME</div>
                <div className="text-xl font-bold text-[#FBBF24]">{flightTime.toFixed(2)} s</div>
                <div className="text-[10px] text-[#9298A3] mt-0.5">Airborne Duration</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#080B12]/80 border border-white/5">
                <div className="text-[10px] text-[#9298A3] mb-1">DISTANCE</div>
                <div className="text-xl font-bold text-[#38BDF8]">{maxDistance.toFixed(2)} m</div>
                <div className="text-[10px] text-[#9298A3] mt-0.5">Ground Traverse</div>
              </div>

              <div className="p-3.5 rounded-xl bg-[#080B12]/80 border border-white/5">
                <div className="text-[10px] text-[#9298A3] mb-1">GRAVITY FORCE</div>
                <div className="text-xl font-bold" style={{ color: world.color }}>{world.g} m/s²</div>
                <div className="text-[10px] text-[#9298A3] mt-0.5">{(world.g / 9.81).toFixed(2)}g Earth Rel</div>
              </div>
            </div>
          </div>

          {/* Right Controls Panel: 5 Cols */}
          <div className="lg:col-span-4 p-6 sm:p-8 rounded-3xl bg-[#101827] border border-white/10 shadow-2xl flex flex-col justify-between space-y-6">
            <div>
              <span className="text-[10px] font-mono tracking-widest text-[#C65B43] uppercase mb-2 block">
                LAB CONTROLS
              </span>
              <h3 className="font-display text-2xl font-bold text-[#F5F1E8] mb-4">
                EXPERIMENT CONFIG
              </h3>

              {/* 1. Choose Object */}
              <div className="mb-6">
                <label className="text-xs font-mono text-[#9298A3] uppercase mb-2 block">
                  1. SELECT SIMULATION OBJECT:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {OBJECTS.map((o) => (
                    <button
                      key={o.id}
                      onClick={() => handleSelectObject(o)}
                      className={`p-2.5 rounded-xl border text-left text-xs font-mono transition-all flex items-center space-x-2 ${
                        selectedObjectId === o.id
                          ? 'bg-[#C65B43] border-white text-white font-bold'
                          : 'bg-white/5 border-white/5 text-[#9298A3] hover:text-white'
                      }`}
                    >
                      <span className="text-base">{o.icon}</span>
                      <span className="truncate">{o.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Choose Planetary Gravity */}
              <div className="mb-6">
                <label className="text-xs font-mono text-[#9298A3] uppercase mb-2 block">
                  2. SELECT GRAVITATIONAL ENVIRONMENT:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {WORLDS.map((w) => (
                    <button
                      key={w.id}
                      onClick={() => {
                        soundManager.playClick();
                        setSelectedWorldId(w.id);
                      }}
                      className={`p-2.5 rounded-xl border text-left text-xs font-mono transition-all ${
                        selectedWorldId === w.id
                          ? 'border-white font-bold text-white'
                          : 'bg-white/5 border-white/5 text-[#9298A3] hover:text-white'
                      }`}
                      style={{
                        backgroundColor: selectedWorldId === w.id ? w.color : undefined,
                      }}
                    >
                      <div>{w.name}</div>
                      <div className="text-[10px] opacity-80">{w.g} m/s²</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. Launch Velocity Slider */}
              <div className="mb-4">
                <div className="flex justify-between text-xs font-mono mb-1.5">
                  <span className="text-[#9298A3]">LAUNCH SPEED (v₀)</span>
                  <span className="text-[#F5F1E8] font-bold">{velocity} m/s</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="60"
                  step="0.5"
                  value={velocity}
                  onChange={(e) => setVelocity(Number(e.target.value))}
                  className="w-full accent-[#C65B43] bg-white/10 h-2 rounded-lg cursor-pointer"
                />
              </div>

              {/* 4. Launch Angle Slider */}
              <div className="mb-6">
                <div className="flex justify-between text-xs font-mono mb-1.5">
                  <span className="text-[#9298A3]">LAUNCH ANGLE (θ)</span>
                  <span className="text-[#F5F1E8] font-bold">{angle}°</span>
                </div>
                <input
                  type="range"
                  min="15"
                  max="90"
                  step="1"
                  value={angle}
                  onChange={(e) => setAngle(Number(e.target.value))}
                  className="w-full accent-[#38BDF8] bg-white/10 h-2 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono text-[#9298A3] mt-1">
                  <span>15° (FLAT)</span>
                  <span className="text-[#34D399]">45° (MAX RANGE)</span>
                  <span>90° (VERTICAL)</span>
                </div>
              </div>
            </div>

            {/* Launch Trigger Button */}
            <button
              onClick={handleLaunch}
              disabled={isSimulating}
              className="w-full py-3.5 rounded-2xl bg-[#C65B43] hover:bg-[#b04a34] text-white font-mono text-xs font-bold tracking-wider transition-all shadow-[0_0_25px_rgba(198,91,67,0.4)] flex items-center justify-center space-x-2 active:scale-95 cursor-pointer"
            >
              <Play size={15} className="fill-current" />
              <span>LAUNCH PHYSICS TRAJECTORY</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
