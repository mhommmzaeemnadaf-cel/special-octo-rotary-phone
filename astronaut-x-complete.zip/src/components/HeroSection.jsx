import React from 'react';
import {
  ArrowRight, Compass, ChevronDown, Radio, Activity, Globe, Sparkles,
  Bot, BookOpen, Orbit, Gamepad2, Shield, Dna, Play, Award, Zap, Rocket
} from 'lucide-react';
import MarsCanvas from './MarsCanvas';
import { soundManager } from '../utils/audio';
import { useProgress } from '../context/ProgressContext';

export default function HeroSection({
  onStartMission,
  onExploreUniverse,
  onOpenAcademy,
  onOpenAstra,
  onOpenSolarSystem,
  onOpenGames,
  onOpenLogin,
}) {
  const { progress, rank } = useProgress();

  const handleStartMission = () => {
    soundManager.playLaunch();
    onStartMission();
  };

  const handleExploreUniverse = () => {
    soundManager.playClick();
    onExploreUniverse();
  };

  return (
    <section className="relative w-full min-h-screen flex flex-col justify-between overflow-hidden bg-[#030712] pt-24 sm:pt-28 pb-8 select-none">
      {/* 3D Interactive Mars Canvas in the Background */}
      <div className="absolute inset-0 z-0">
        <MarsCanvas interactive={true} />
      </div>

      {/* Atmospheric Vignette & Gradients (Dribbble Cinematic Lighting) */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-t from-[#030712] via-transparent to-[#030712]/90 z-10" />
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-r from-[#030712]/95 via-transparent to-[#030712]/95 z-10" />
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[#C65B43]/10 rounded-full blur-[140px] pointer-events-none z-10" />
      <div className="absolute bottom-10 right-10 w-[450px] h-[450px] bg-[#38BDF8]/10 rounded-full blur-[120px] pointer-events-none z-10" />

      {/* Top Floating Telemetry Status HUD */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4 backdrop-blur-sm">
          <div className="flex items-center space-x-3">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#34D399] opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#34D399]" />
            </span>
            <span className="font-mono text-xs tracking-widest text-[#F8FAFC] uppercase font-bold">
              SOLAR SYSTEM TELEMETRY: <span className="text-[#34D399]">ONLINE // 100% NOMINAL</span>
            </span>
          </div>

          <div className="hidden lg:flex items-center space-x-6 text-xs font-mono text-[#94A3B8]">
            <div className="flex items-center space-x-2">
              <Orbit size={13} className="text-[#FBBF24]" />
              <span>ORBITAL BODIES: 8 PLANETS + SUN</span>
            </div>
            <span className="text-white/20">•</span>
            <div className="flex items-center space-x-2">
              <Radio size={13} className="text-[#C65B43]" />
              <span>EARTH-MARS RANGE: 225,482,000 KM</span>
            </div>
            <span className="text-white/20">•</span>
            <div className="flex items-center space-x-2">
              <Activity size={13} className="text-[#38BDF8]" />
              <span>LIGHT SPEED DELAY: 14M 22S</span>
            </div>
          </div>
        </div>
      </div>

      {/* Center Hero Content with Floating Dribbble Bento HUD Cards */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full my-auto py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Main Hero Column (Left / Center) */}
          <div className="lg:col-span-8 space-y-6">
            {/* Top Mission Tag Pill */}
            <div className="inline-flex items-center space-x-2.5 px-3.5 py-1.5 rounded-full bg-white/[0.04] border border-white/15 backdrop-blur-xl shadow-lg">
              <span className="w-2 h-2 rounded-full bg-[#38BDF8] animate-pulse" />
              <span className="text-xs font-mono tracking-widest text-[#38BDF8] uppercase font-bold">
                EXPEDITION 2026 // NASA SPACE SCIENCE PLATFORM
              </span>
            </div>

            {/* Cinematic Main Headline */}
            <h1 className="font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight text-white uppercase leading-[0.92] drop-shadow-2xl">
              EXPLORE THE UNIVERSE
              <span className="block text-gradient-mars text-2xl sm:text-4xl md:text-5xl font-extrabold mt-3 tracking-normal normal-case">
                Powered by Authentic NASA Scientific Data.
              </span>
            </h1>

            {/* Slogan Badges */}
            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm font-mono text-[#FBBF24] tracking-widest uppercase font-bold">
              <span>TRAIN.</span>
              <span className="text-white/30">•</span>
              <span>EXPLORE.</span>
              <span className="text-white/30">•</span>
              <span>DISCOVER.</span>
              <span className="text-white/30">•</span>
              <span className="text-[#38BDF8]">BECOME A COMMANDER.</span>
            </div>

            {/* Supporting Description */}
            <p className="text-sm sm:text-base md:text-lg text-[#94A3B8] leading-relaxed max-w-2xl font-normal">
              Journey through an interactive Keplerian Solar System Orrery, pilot 6 real-world aerospace physics simulations (DART, Slingshot, Docking, CME Shield), investigate published NASA OSDR space biology, and explore 140,000+ official NASA multimedia assets.
            </p>

            {/* Action Buttons Cluster */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              {/* Primary Launch CTA */}
              <button
                onClick={handleStartMission}
                className="group relative px-7 py-4 rounded-full bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#C65B43] hover:brightness-110 text-white font-mono text-xs tracking-wider font-bold transition-all duration-300 shadow-[0_0_35px_rgba(198,91,67,0.5)] hover:shadow-[0_0_50px_rgba(198,91,67,0.8)] flex items-center justify-center space-x-2.5 active:scale-95 cursor-pointer"
              >
                <span>ENTER FLIGHT DECK</span>
                <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Solar System Orrery Shortcut */}
              {onOpenSolarSystem && (
                <button
                  onClick={onOpenSolarSystem}
                  className="px-5 py-3.5 rounded-full bg-white/[0.04] hover:bg-white/[0.08] border border-white/15 text-white font-mono text-xs tracking-wider transition-all backdrop-blur-xl flex items-center justify-center space-x-2 active:scale-95 cursor-pointer font-bold hover:border-[#38BDF8] hover:text-[#38BDF8]"
                >
                  <Orbit size={15} className="text-[#38BDF8]" />
                  <span>SOLAR SYSTEM</span>
                </button>
              )}

              {/* Space Games Arcade Shortcut */}
              {onOpenGames && (
                <button
                  onClick={onOpenGames}
                  className="px-5 py-3.5 rounded-full bg-white/[0.04] hover:bg-white/[0.08] border border-white/15 text-white font-mono text-xs tracking-wider transition-all backdrop-blur-xl flex items-center justify-center space-x-2 active:scale-95 cursor-pointer font-bold hover:border-[#34D399] hover:text-[#34D399]"
                >
                  <Gamepad2 size={15} className="text-[#34D399]" />
                  <span>6-GAME ARCADE</span>
                </button>
              )}

              {/* EVA Operations Hub Shortcut */}
              <a
                href="#eva-operations-hub"
                className="px-5 py-3.5 rounded-full bg-[#16181D]/90 hover:bg-[#16181D] border border-[#5B9BFF]/50 text-white font-mono text-xs tracking-wider transition-all backdrop-blur-xl flex items-center justify-center space-x-2 active:scale-95 cursor-pointer font-bold shadow-[0_0_15px_rgba(91,155,255,0.25)] hover:border-[#5B9BFF] hover:text-[#5B9BFF]"
              >
                <Compass size={15} className="text-[#5B9BFF]" />
                <span>EVA OPERATIONS</span>
              </a>

              {/* COSMOS Mission Control Center Shortcut */}
              <a
                href="#cosmos-mission-control"
                className="px-5 py-3.5 rounded-full bg-[#121624] hover:bg-[#1D4ED8]/25 border border-[#2563EB]/60 text-white font-mono text-xs tracking-wider transition-all backdrop-blur-xl flex items-center justify-center space-x-2 active:scale-95 cursor-pointer font-bold shadow-[0_0_20px_rgba(37,99,235,0.3)] hover:border-[#60A5FA] hover:text-[#60A5FA]"
              >
                <Rocket size={15} className="text-[#3B82F6]" />
                <span>COSMOS MCC</span>
              </a>

              {/* Space Biology Lab Shortcut */}
              <a
                href="#space-biology-lab"
                className="px-5 py-3.5 rounded-full bg-white/[0.04] hover:bg-white/[0.08] border border-white/15 text-white font-mono text-xs tracking-wider transition-all backdrop-blur-xl flex items-center justify-center space-x-2 active:scale-95 cursor-pointer font-bold hover:border-[#EC4899] hover:text-[#EC4899]"
              >
                <Dna size={15} className="text-[#EC4899]" />
                <span>SPACE BIOLOGY</span>
              </a>

              {/* Student Login Portal Button */}
              {onOpenLogin && (
                <button
                  onClick={onOpenLogin}
                  className="px-5 py-3.5 rounded-full bg-gradient-to-r from-[#38BDF8]/20 via-[#6366F1]/20 to-[#A855F7]/20 hover:from-[#38BDF8]/30 hover:to-[#A855F7]/30 border border-[#38BDF8]/60 text-white font-mono text-xs tracking-wider transition-all backdrop-blur-xl flex items-center justify-center space-x-2 active:scale-95 cursor-pointer font-bold shadow-[0_0_20px_rgba(56,189,248,0.3)] hover:shadow-[0_0_30px_rgba(56,189,248,0.6)]"
                >
                  <Shield size={15} className="text-[#38BDF8]" />
                  <span>STUDENT LOGIN</span>
                </button>
              )}
            </div>
          </div>

          {/* Right Floating Bento Cards (Dribbble NASA HUD Aesthetic) */}
          <div className="lg:col-span-4 hidden lg:flex flex-col space-y-4">
            {/* Card 1: Live Orbital Telemetry */}
            <div className="glass-panel-card rounded-3xl p-5 space-y-3">
              <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                <div className="flex items-center space-x-2">
                  <Activity size={14} className="text-[#38BDF8]" />
                  <span className="text-[11px] font-mono text-white font-bold uppercase tracking-wider">
                    FLIGHT TELEMETRY HUD
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-[#34D399]/20 text-[#34D399] text-[9px] font-mono font-bold">
                  LIVE
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="bg-white/5 p-2.5 rounded-2xl border border-white/5">
                  <span className="text-[9px] text-[#94A3B8] block">ORBITAL VELOCITY</span>
                  <span className="text-sm font-bold text-white">24,119 km/h</span>
                </div>
                <div className="bg-white/5 p-2.5 rounded-2xl border border-white/5">
                  <span className="text-[9px] text-[#94A3B8] block">ALTITUDE (PERIGEE)</span>
                  <span className="text-sm font-bold text-[#38BDF8]">418.5 km</span>
                </div>
                <div className="bg-white/5 p-2.5 rounded-2xl border border-white/5">
                  <span className="text-[9px] text-[#94A3B8] block">COSMIC FLUX</span>
                  <span className="text-sm font-bold text-[#34D399]">0.28 mGy/d</span>
                </div>
                <div className="bg-white/5 p-2.5 rounded-2xl border border-white/5">
                  <span className="text-[9px] text-[#94A3B8] block">MISSION SOL</span>
                  <span className="text-sm font-bold text-[#FBBF24]">Sol 1,422</span>
                </div>
              </div>

              {/* Real-time wave visualizer */}
              <div className="h-6 flex items-end justify-between space-x-1 pt-1 opacity-80">
                {[40, 65, 30, 85, 45, 95, 60, 35, 75, 50, 90, 40, 70, 85, 30, 95].map((h, i) => (
                  <span
                    key={i}
                    className="w-1 bg-gradient-to-t from-[#38BDF8] to-[#818CF8] rounded-full"
                    style={{ height: `${h}%` }}
                  />
                ))}
              </div>
            </div>

            {/* Card 2: Cadet Flight Status & XP */}
            <div className="glass-panel-card rounded-3xl p-5 space-y-3">
              <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                <div className="flex items-center space-x-2">
                  <Award size={14} className="text-[#FBBF24]" />
                  <span className="text-[11px] font-mono text-white font-bold uppercase tracking-wider">
                    COMMANDER PROFILE
                  </span>
                </div>
                <span className="text-[10px] font-mono text-[#FBBF24] font-bold">
                  {progress.callsign}
                </span>
              </div>

              <div className="space-y-1.5 font-mono text-xs">
                <div className="flex justify-between">
                  <span className="text-[#94A3B8]">Rank Progression:</span>
                  <span className="text-white font-bold">{rank.title}</span>
                </div>
                <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#34D399] h-full"
                    style={{ width: `${Math.min(100, (progress.xp / 3000) * 100)}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-[#94A3B8]">
                  <span>{progress.xp} XP Earned</span>
                  <span className="text-[#34D399]">{progress.unlockedAchievements?.length || 18} Badges Certified</span>
                </div>

                {onOpenLogin && (
                  <button
                    onClick={onOpenLogin}
                    className="w-full mt-2 py-2 rounded-xl bg-white/5 hover:bg-[#38BDF8]/20 border border-white/10 hover:border-[#38BDF8]/40 text-[#38BDF8] text-[11px] font-mono font-bold flex items-center justify-center space-x-1.5 transition-all cursor-pointer"
                  >
                    <Shield size={12} />
                    <span>STUDENT ID SIGN IN</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Mission Metric Marquee / Bento Bar (Dribbble Signature Strip) */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          {[
            {
              label: '08 CELESTIAL WORLDS',
              value: 'Keplerian Orrery',
              desc: 'Sun & planets with real telemetry & radio audio',
              color: '#38BDF8',
              icon: Orbit,
            },
            {
              label: '06 FLIGHT SIMULATIONS',
              value: 'Space Physics Arcade',
              desc: 'DART, Slingshot, Docking, CME Shield, Rover',
              color: '#34D399',
              icon: Gamepad2,
            },
            {
              label: '140K+ NASA ASSETS',
              value: 'Multimedia Explorer',
              desc: 'Official images-api.nasa.gov search & manifests',
              color: '#FBBF24',
              icon: Globe,
            },
            {
              label: '100% OFFLINE READY',
              value: 'Zero API Dependency',
              desc: 'Built-in verified datasets & graceful fallback',
              color: '#EC4899',
              icon: Zap,
            },
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="glass-panel-card rounded-2xl sm:rounded-3xl p-4 sm:p-5 flex flex-col justify-between transition-all"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] sm:text-[11px] font-mono tracking-widest text-[#94A3B8] uppercase">
                    {item.label}
                  </span>
                  <Icon size={16} style={{ color: item.color }} />
                </div>
                <div>
                  <div className="font-display font-extrabold text-base sm:text-xl text-white">
                    {item.value}
                  </div>
                  <div className="text-[11px] text-[#94A3B8] font-mono mt-0.5 leading-snug">
                    {item.desc}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
