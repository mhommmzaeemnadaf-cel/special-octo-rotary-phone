import React, { useState, useEffect } from 'react';
import { Wind, Thermometer, Radio, Compass, Sun, ShieldAlert, Activity, RefreshCw, Send, Check } from 'lucide-react';
import { soundManager } from '../utils/audio';

export default function MarsWeatherStation() {
  // Live ticking Martian Sol Time
  const [marsTime, setMarsTime] = useState({ sol: 1042, hour: 14, min: 28, sec: 10 });
  const [earthDistanceKm, setEarthDistanceKm] = useState(225482140);
  const [pingState, setPingState] = useState('idle'); // idle, transmitting, received

  useEffect(() => {
    const timer = setInterval(() => {
      setMarsTime((prev) => {
        let sec = prev.sec + 1;
        let min = prev.min;
        let hour = prev.hour;
        let sol = prev.sol;

        if (sec >= 60) {
          sec = 0;
          min += 1;
        }
        if (min >= 60) {
          min = 0;
          hour += 1;
        }
        if (hour >= 24) {
          hour = 0;
          sol += 1;
        }
        return { sol, hour, min, sec };
      });

      // Realistic minute orbital drift
      setEarthDistanceKm((prev) => prev + Math.floor((Math.random() - 0.45) * 8));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const speedOfLightSec = (earthDistanceKm / 299792).toFixed(1);
  const speedOfLightMin = Math.floor(speedOfLightSec / 60);
  const speedOfLightRemSec = Math.floor(speedOfLightSec % 60);

  const handleSendPing = () => {
    soundManager.playRadarPing();
    setPingState('transmitting');
    setTimeout(() => {
      soundManager.playQuindar(true);
      setPingState('received');
      setTimeout(() => setPingState('idle'), 3500);
    }, 1800);
  };

  return (
    <section className="py-20 bg-[#080B12] border-t border-white/5 relative overflow-hidden">
      {/* Background Subtle Orange Atmospheric Haze */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[600px] h-[350px] bg-[#C65B43]/10 blur-[130px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#C65B43] uppercase mb-3">
              <span className="w-2 h-2 rounded-full bg-[#34D399] animate-pulse" />
              <span>LIVE JPL PERSEVERANCE MEDA TELEMETRY</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#F5F1E8] uppercase">
              JEZERO CRATER METEOROLOGY
            </h2>
          </div>
          <div className="text-right">
            <div className="text-xs font-mono text-[#9298A3]">
              LOCAL MARS SOLAR TIME (LMST):
            </div>
            <div className="font-mono text-2xl font-bold text-[#F5F1E8]">
              SOL {marsTime.sol} • {String(marsTime.hour).padStart(2, '0')}:
              {String(marsTime.min).padStart(2, '0')}:
              {String(marsTime.sec).padStart(2, '0')}
            </div>
          </div>
        </div>

        {/* 6 Grid Telemetry Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* 1. Atmospheric Pressure */}
          <div className="p-6 rounded-2xl bg-[#101827]/70 border border-white/10 backdrop-blur-md relative overflow-hidden group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-[#9298A3] uppercase">SURFACE PRESSURE</span>
              <Wind size={18} className="text-[#38BDF8]" />
            </div>
            <div className="font-mono text-4xl font-bold text-[#F5F1E8] mb-1">
              738 <span className="text-sm font-normal text-[#9298A3]">Pa</span>
            </div>
            <div className="text-xs text-[#38BDF8] font-mono mb-3">
              7.38 mbar (0.72% of Earth sea level)
            </div>
            <p className="text-xs text-[#9298A3] leading-relaxed">
              Diurnal pressure oscillation driven by seasonal CO₂ sublimation cycles across polar ice caps.
            </p>
          </div>

          {/* 2. Air & Ground Temperature */}
          <div className="p-6 rounded-2xl bg-[#101827]/70 border border-white/10 backdrop-blur-md relative overflow-hidden group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-[#9298A3] uppercase">AIR & GROUND TEMP</span>
              <Thermometer size={18} className="text-[#FBBF24]" />
            </div>
            <div className="flex items-baseline space-x-3 mb-1">
              <span className="font-mono text-4xl font-bold text-[#F5F1E8]">-18°C</span>
              <span className="text-xs font-mono text-[#9298A3]">HIGH</span>
              <span className="text-white/20">/</span>
              <span className="font-mono text-2xl font-bold text-[#38BDF8]">-84°C</span>
              <span className="text-xs font-mono text-[#9298A3]">LOW</span>
            </div>
            <div className="text-xs text-[#FBBF24] font-mono mb-3">
              Regolith Surface Peak: +4°C at 13:00 LMST
            </div>
            <p className="text-xs text-[#9298A3] leading-relaxed">
              Thin Martian atmosphere cannot retain daytime solar heat, creating severe 100°C diurnal swings.
            </p>
          </div>

          {/* 3. Wind Velocity & Direction */}
          <div className="p-6 rounded-2xl bg-[#101827]/70 border border-white/10 backdrop-blur-md relative overflow-hidden group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-[#9298A3] uppercase">WIND SPEED & VECTOR</span>
              <Compass size={18} className="text-[#34D399]" />
            </div>
            <div className="font-mono text-4xl font-bold text-[#F5F1E8] mb-1">
              7.2 <span className="text-sm font-normal text-[#9298A3]">m/s</span>
            </div>
            <div className="text-xs text-[#34D399] font-mono mb-3">
              DIRECTION: 118° ESE • GUSTS UP TO 18.4 m/s
            </div>
            <p className="text-xs text-[#9298A3] leading-relaxed">
              Thermal updrafts from Jezero delta scarp driving localized convective dust vortexes (dust devils).
            </p>
          </div>

          {/* 4. Atmospheric Dust Opacity */}
          <div className="p-6 rounded-2xl bg-[#101827]/70 border border-white/10 backdrop-blur-md relative overflow-hidden group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-[#9298A3] uppercase">DUST OPACITY (TAU)</span>
              <Sun size={18} className="text-[#C65B43]" />
            </div>
            <div className="font-mono text-4xl font-bold text-[#F5F1E8] mb-1">
              0.42 <span className="text-sm font-normal text-[#9298A3]">τ</span>
            </div>
            <div className="text-xs text-[#34D399] font-mono mb-3">
              ATMOSPHERIC STATUS: CLEAR / NOMINAL
            </div>
            <p className="text-xs text-[#9298A3] leading-relaxed">
              Low optical depth enables 96% solar array efficiency. Global dust storm threshold begins at τ &gt; 2.5.
            </p>
          </div>

          {/* 5. UV Radiation Environment */}
          <div className="p-6 rounded-2xl bg-[#101827]/70 border border-white/10 backdrop-blur-md relative overflow-hidden group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-[#9298A3] uppercase">SOLAR UV FLUX</span>
              <ShieldAlert size={18} className="text-[#F87171]" />
            </div>
            <div className="font-mono text-4xl font-bold text-[#F5F1E8] mb-1">
              1.8 <span className="text-sm font-normal text-[#9298A3]">W/m²</span>
            </div>
            <div className="text-xs text-[#F87171] font-mono mb-3">
              LETHAL WITHOUT EXTRAVEHICULAR SUIT
            </div>
            <p className="text-xs text-[#9298A3] leading-relaxed">
              Complete absence of stratospheric ozone allows sterilizing UV-C rays to penetrate directly to regolith.
            </p>
          </div>

          {/* 6. Real-Time Earth-Mars Link & Ping */}
          <div className="p-6 rounded-2xl bg-[#101827]/70 border border-white/10 backdrop-blur-md relative overflow-hidden group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono text-[#9298A3] uppercase">EARTH-MARS ORBITAL LAG</span>
              <Radio size={18} className="text-[#38BDF8]" />
            </div>
            <div className="font-mono text-3xl font-bold text-[#F5F1E8] mb-1">
              {speedOfLightMin}m {speedOfLightRemSec}s
            </div>
            <div className="text-xs text-[#38BDF8] font-mono mb-3">
              DISTANCE: {earthDistanceKm.toLocaleString()} KM (1.507 AU)
            </div>
            <div className="pt-2">
              <button
                onClick={handleSendPing}
                disabled={pingState !== 'idle'}
                className="w-full py-2 px-3 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-[#F5F1E8] flex items-center justify-center space-x-2 transition-all"
              >
                {pingState === 'idle' && (
                  <>
                    <Send size={13} className="text-[#38BDF8]" />
                    <span>PING MARS TRANSCEIVER</span>
                  </>
                )}
                {pingState === 'transmitting' && (
                  <>
                    <RefreshCw size={13} className="animate-spin text-[#FBBF24]" />
                    <span>SIGNAL PROPAGATING ACROSS VOID...</span>
                  </>
                )}
                {pingState === 'received' && (
                  <>
                    <Check size={13} className="text-[#34D399]" />
                    <span>TELEMETRY PACKET ACKNOWLEDGED</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
