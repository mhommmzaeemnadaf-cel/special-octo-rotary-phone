import React, { useState } from 'react';
import { Wind, Thermometer, Droplets, Mountain, Compass, Rocket, Globe, ChevronRight } from 'lucide-react';
import { soundManager } from '../utils/audio';

const DISCOVER_TOPICS = [
  {
    id: 'atmosphere',
    title: 'Mars Atmosphere',
    category: 'ATMOSPHERIC SCIENCE',
    icon: Wind,
    stat: '610 Pa',
    statLabel: 'SURFACE PRESSURE (0.6% OF EARTH)',
    quote: 'The Martian atmosphere is unbreathable but rich in raw resources for MOXIE chemical extraction.',
    facts: [
      { label: 'Composition', val: '95.32% CO₂, 2.6% N₂, 1.9% Ar, 0.16% O₂' },
      { label: 'Scale Height', val: '11.1 km (compared to 8.5 km on Earth)' },
      { label: 'Dust Storms', val: 'Global planet-encircling storms every 3–4 Martian years' },
      { label: 'Dust Devils', val: 'Vortices towering up to 8,000 meters into the troposphere' },
    ],
  },
  {
    id: 'surface',
    title: 'Surface Conditions',
    category: 'GEOPHYSICS & REGOLITH',
    icon: Thermometer,
    stat: '-63°C',
    statLabel: 'MEAN GLOBAL TEMPERATURE',
    quote: 'An unforgiving desert world shaped by billions of years of volcanic eruptions and meteorite bombardments.',
    facts: [
      { label: 'Extreme Range', val: '+20°C (noon at equator) down to -125°C (polar winter)' },
      { label: 'Surface Gravity', val: '3.72 m/s² (0.376 g — jump 2.6× higher than on Earth)' },
      { label: 'Soil Chemistry', val: 'Iron(III) oxide (rust) with 0.5–1% hazardous perchlorate salts' },
      { label: 'Solar Day (Sol)', val: '24 hours, 39 minutes, 35.244 seconds' },
    ],
  },
  {
    id: 'water',
    title: 'Water Ice Reserves',
    category: 'HYDROLOGY & GLACIOLOGY',
    icon: Droplets,
    stat: '5M+ km³',
    statLabel: 'ESTIMATED WATER ICE VOLUME',
    quote: 'Liquid water flowed billions of years ago. Today, vast frozen oceans sleep beneath the red dust.',
    facts: [
      { label: 'Utopia Planitia', val: 'Subsurface ice sheet containing as much water as Lake Superior' },
      { label: 'Polar Ice Caps', val: 'Permanent water ice caps capped by seasonal frozen dry ice (CO₂)' },
      { label: 'Hab Survival', val: 'Automated thermal rods melt subsurface permafrost for drinking & fuel' },
      { label: 'Hydrated Minerals', val: 'Clays and sulfates preserving ancient microbial biosignatures' },
    ],
  },
  {
    id: 'geography',
    title: 'Martian Geography',
    category: 'PLANETARY TOPOGRAPHY',
    icon: Mountain,
    stat: '21.9 km',
    statLabel: 'OLYMPUS MONS PEAK ELEVATION',
    quote: 'Home to the deepest canyons and tallest volcanoes in the known Solar System.',
    facts: [
      { label: 'Olympus Mons', val: 'Shield volcano 2.5× the height of Everest; base spans width of France' },
      { label: 'Valles Marineris', val: 'Canyon system 4,000 km long, 200 km wide, and 7 km deep' },
      { label: 'Jezero Crater', val: '45 km ancient impact basin holding river delta lake deposits' },
      { label: 'Hellas Planitia', val: 'Massive 2,300 km impact basin 7 km deep below datum' },
    ],
  },
  {
    id: 'missions',
    title: 'Exploration Missions',
    category: 'NASA & JPL HISTORY',
    icon: Rocket,
    stat: '1976–2026',
    statLabel: '50 YEARS OF ROBOTIC RECONNAISSANCE',
    quote: 'From Viking’s first robotic steps to Perseverance and Ingenuity taking flight.',
    facts: [
      { label: 'Viking 1 & 2 (1976)', val: 'First successful landers to operate on the Martian surface' },
      { label: 'Curiosity (2012)', val: 'Nuclear rover proving ancient Mars could have supported life' },
      { label: 'Perseverance (2021)', val: 'Caching samples at Jezero Crater for Earth return transit' },
      { label: 'Ingenuity Helicopter', val: '72 historic powered aerodynamic flights in Mars thin atmosphere' },
    ],
  },
];

export default function DiscoverMarsSection() {
  const [activeTopicId, setActiveTopicId] = useState('atmosphere');
  const activeTopic = DISCOVER_TOPICS.find((t) => t.id === activeTopicId) || DISCOVER_TOPICS[0];

  const handleTopicClick = (id) => {
    soundManager.playClick();
    setActiveTopicId(id);
  };

  return (
    <section id="discover-mars" className="py-28 md:py-36 bg-[#080B12] border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#C65B43] uppercase mb-4">
              <span>06 / SECTION</span>
              <span className="w-8 h-[1px] bg-[#C65B43]/50" />
              <span>PLANETARY ARCHIVES</span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-[#F5F1E8] uppercase">
              DISCOVER MARS
            </h2>
          </div>
          <p className="max-w-md text-sm text-[#9298A3] font-light leading-relaxed">
            Authentic scientific telemetry compiled from NASA JPL, Mars Reconnaissance Orbiter (MRO), and the Planetary Data System.
          </p>
        </div>

        {/* 5 Topic Tabs Selector */}
        <div className="flex flex-wrap items-center gap-3 mb-10 pb-4 border-b border-white/10">
          {DISCOVER_TOPICS.map((topic) => {
            const Icon = topic.icon;
            const isSelected = activeTopicId === topic.id;
            return (
              <button
                key={topic.id}
                onClick={() => handleTopicClick(topic.id)}
                className={`px-5 py-3 rounded-xl font-mono text-xs tracking-wider transition-all duration-300 flex items-center space-x-2.5 ${
                  isSelected
                    ? 'bg-[#C65B43] text-white shadow-[0_0_20px_rgba(198,91,67,0.35)]'
                    : 'bg-[#101827] text-[#9298A3] hover:text-[#F5F1E8] hover:bg-[#101827]/80 border border-white/5'
                }`}
              >
                <Icon size={14} className={isSelected ? 'text-white' : 'text-[#C65B43]'} />
                <span>{topic.title}</span>
              </button>
            );
          })}
        </div>

        {/* Selected Topic Showcase Panel */}
        <div className="p-8 md:p-12 rounded-3xl bg-[#101827] border border-white/10 shadow-2xl relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Left Column: Big Metric & Narrative */}
            <div className="lg:col-span-5">
              <span className="text-[10px] font-mono tracking-widest px-3 py-1 rounded-full bg-white/5 text-[#C65B43] border border-[#C65B43]/20 mb-4 inline-block">
                {activeTopic.category}
              </span>
              <h3 className="font-display text-3xl sm:text-4xl font-bold text-[#F5F1E8] mb-4">
                {activeTopic.title}
              </h3>
              <p className="text-sm text-[#9298A3] italic mb-8 font-light leading-relaxed">
                “{activeTopic.quote}”
              </p>

              {/* Big Stat Box */}
              <div className="p-6 rounded-2xl bg-[#080B12]/80 border border-white/10">
                <div className="font-mono text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#F5F1E8] mb-2">
                  {activeTopic.stat}
                </div>
                <div className="text-[10px] font-mono tracking-widest text-[#9298A3]">
                  {activeTopic.statLabel}
                </div>
              </div>
            </div>

            {/* Right Column: Detailed Scientific Specs */}
            <div className="lg:col-span-7 flex flex-col space-y-4">
              <div className="text-xs font-mono tracking-widest text-[#9298A3] uppercase mb-1">
                VERIFIED PLANETARY DATA LOG
              </div>

              {activeTopic.facts.map((fact, idx) => (
                <div
                  key={idx}
                  className="p-5 rounded-2xl bg-[#080B12]/60 border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <span className="text-xs font-mono text-[#9298A3]">{fact.label}</span>
                  <span className="text-xs font-semibold text-[#F5F1E8] sm:text-right max-w-sm">
                    {fact.val}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Earth vs Mars Comparative Analysis Matrix */}
        <div className="mt-16 p-8 rounded-3xl bg-[#080B12] border border-white/10">
          <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#9298A3] uppercase mb-6">
            <Globe size={16} className="text-[#C65B43]" />
            <span>INTERACTIVE PLANETARY COMPARISON MATRIX</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="border-b border-white/10 text-[#9298A3]">
                  <th className="py-3 px-4 font-normal">PARAMETER</th>
                  <th className="py-3 px-4 font-normal text-[#38BDF8]">PLANET EARTH</th>
                  <th className="py-3 px-4 font-normal text-[#C65B43]">PLANET MARS</th>
                  <th className="py-3 px-4 font-normal text-[#F5F1E8]">EXPEDITIONARY IMPACT</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-[#F5F1E8]/90">
                <tr>
                  <td className="py-3.5 px-4 text-[#9298A3]">Surface Gravity</td>
                  <td className="py-3.5 px-4 text-[#38BDF8]">9.81 m/s² (1.00 g)</td>
                  <td className="py-3.5 px-4 text-[#C65B43]">3.72 m/s² (0.38 g)</td>
                  <td className="py-3.5 px-4">Daily 2.5 hr resistance exercise protocol required</td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 text-[#9298A3]">Day Duration</td>
                  <td className="py-3.5 px-4 text-[#38BDF8]">24 hr 00 min</td>
                  <td className="py-3.5 px-4 text-[#C65B43]">24 hr 39 min 35 sec</td>
                  <td className="py-3.5 px-4">Circadian rhythm shifts by ~40 min every Sol</td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 text-[#9298A3]">Atmospheric Pressure</td>
                  <td className="py-3.5 px-4 text-[#38BDF8]">101,325 Pa (1.0 atm)</td>
                  <td className="py-3.5 px-4 text-[#C65B43]">610 Pa (0.006 atm)</td>
                  <td className="py-3.5 px-4">Instant vaporization of liquids without pressurized suit</td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 text-[#9298A3]">Avg Surface Temp</td>
                  <td className="py-3.5 px-4 text-[#38BDF8]">+15°C (59°F)</td>
                  <td className="py-3.5 px-4 text-[#C65B43]">-63°C (-81°F)</td>
                  <td className="py-3.5 px-4">Cryogenic suit heating loops & thermal Hab aerogels</td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 text-[#9298A3]">Natural Moons</td>
                  <td className="py-3.5 px-4 text-[#38BDF8]">1 (The Moon)</td>
                  <td className="py-3.5 px-4 text-[#C65B43]">2 (Phobos & Deimos)</td>
                  <td className="py-3.5 px-4">Fast orbital passes; potential deep space staging outposts</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
