import React, { useState, useEffect } from 'react';
import {
  X, Rocket, UserCheck, Shield, AlertTriangle, Wind, Droplets, Zap,
  CheckCircle2, ChevronRight, Award, Printer, RotateCcw, Flame, Navigation,
  Activity, Sliders, Radio, Compass, RefreshCw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../utils/audio';

const ROLES = [
  {
    id: 'eclss',
    title: 'Life Support Specialist',
    callsign: 'BIO-SYS',
    badge: 'ECLSS COMMAND',
    desc: 'Master of closed-loop atmosphere scrubbers, Sabatier water recovery, and MOXIE electrolysis.',
    perk: '+15% O₂ & Water Recycling Buffer',
  },
  {
    id: 'pilot',
    title: 'Geologist & Rover Pilot',
    callsign: 'TERRA-1',
    badge: 'EXPEDITION PILOT',
    desc: 'Specialist in 0.38g terrain maneuvering, seismic sounding, and glacial core sample extraction.',
    perk: '+20% EVA Traverse Range & Stability',
  },
  {
    id: 'systems',
    title: 'Nuclear Power Commander',
    callsign: 'NUC-CMD',
    badge: 'ENERGY SYSTEMS',
    desc: 'Commander of the Kilopower fission reactor, electrical load shedding, and emergency Hab triage.',
    perk: '+15% Power Grid Resilience Under Load',
  },
];

const JEZERO_WAYPOINTS = [
  { id: 'landing', name: 'Octavia E. Butler Landing Site', x: '24%', y: '68%', hazard: 'LOW', sample: 'Basalt Regolith' },
  { id: 'kodiak', name: 'Kodiak Delta Butte', x: '45%', y: '48%', hazard: 'MED', sample: 'Deltaic Mudstone' },
  { id: 'crater', name: 'Belva Impact Crater', x: '68%', y: '35%', hazard: 'HIGH', sample: 'Deep Hydrothermal Core' },
  { id: 'hab', name: 'Habitation Alpha Perimeter', x: '82%', y: '58%', hazard: 'LOW', sample: 'Base Secure' },
];

export default function MissionSimulatorModal({ isOpen, onClose }) {
  // Phases: 1: Profile, 2: EDL Descent, 3: ECLSS MOXIE Boot, 4: Jezero Rover Expedition, 5: Dust Storm Triage, 6: Certification
  const [phase, setPhase] = useState(1);
  const [cadetName, setCadetName] = useState('Aria Vance');
  const [selectedRoleId, setSelectedRoleId] = useState('eclss');

  // Mission live stats
  const [stats, setStats] = useState({
    oxygen: 94,
    water: 92,
    power: 96,
    health: 98,
    sol: 104,
  });

  // Phase 2: EDL "7 Minutes of Terror" Sky Crane State
  const [edlAltitude, setEdlAltitude] = useState(2500); // meters
  const [edlVelocity, setEdlVelocity] = useState(48.0); // m/s
  const [edlThrottle, setEdlThrottle] = useState(65); // %
  const [edlFuel, setEdlFuel] = useState(100); // %
  const [edlTouchdown, setEdlTouchdown] = useState(false);
  const [edlFailed, setEdlFailed] = useState(false);

  // Phase 3: MOXIE Calibration State
  const [moxieTemp, setMoxieTemp] = useState(720);
  const [moxieCalibrated, setMoxieCalibrated] = useState(false);
  const [switchToggles, setSwitchToggles] = useState({
    sabatier: false,
    scrubbers: false,
    kilopower: false,
  });

  // Phase 4: Jezero Rover Expedition Waypoints Visited
  const [visitedWaypoints, setVisitedWaypoints] = useState(['landing']);
  const [roverBattery, setRoverBattery] = useState(92);
  const [samplesCollected, setSamplesCollected] = useState(1);

  // Phase 5: Dust Storm Crisis
  const [stormDecision, setStormDecision] = useState(null);

  // Trigger celebration on Certification Phase
  useEffect(() => {
    if (phase === 6) {
      soundManager.playSuccess();
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
          colors: ['#C65B43', '#E07A5F', '#38BDF8', '#34D399', '#F5F1E8'],
        });
      } catch (e) {}
    }
  }, [phase]);

  // Phase 2 EDL physics descent simulation
  useEffect(() => {
    if (phase !== 2 || edlTouchdown || edlFailed) return;

    const timer = setInterval(() => {
      setEdlAltitude((alt) => {
        if (alt <= 0) {
          clearInterval(timer);
          // Check final touchdown velocity
          setEdlVelocity((vel) => {
            if (Math.abs(vel) <= 3.5) {
              setEdlTouchdown(true);
              soundManager.playQuindar(true);
            } else {
              setEdlFailed(true);
              soundManager.playWarning();
            }
            return vel;
          });
          return 0;
        }

        // Throttle reduces descent speed; gravity (0.38g) accelerates it
        setEdlVelocity((vel) => {
          const thrust = (edlThrottle / 100) * 12.0;
          const gravity = 3.72; // Mars gravity m/s²
          const newVel = Math.max(1.2, vel + (gravity - thrust) * 0.1);
          return parseFloat(newVel.toFixed(1));
        });

        setEdlFuel((fuel) => Math.max(0, fuel - (edlThrottle / 100) * 0.8));

        return Math.max(0, alt - Math.round(edlVelocity * 0.8));
      });
    }, 100);

    return () => clearInterval(timer);
  }, [phase, edlThrottle, edlVelocity, edlTouchdown, edlFailed]);

  if (!isOpen) return null;

  const handleNextPhase = () => {
    soundManager.playClick();
    setPhase((prev) => Math.min(6, prev + 1));
  };

  const handleRestart = () => {
    soundManager.playClick();
    setPhase(1);
    setStats({ oxygen: 94, water: 92, power: 96, health: 98, sol: 104 });
    setEdlAltitude(2500);
    setEdlVelocity(48.0);
    setEdlThrottle(65);
    setEdlFuel(100);
    setEdlTouchdown(false);
    setEdlFailed(false);
    setMoxieTemp(720);
    setMoxieCalibrated(false);
    setSwitchToggles({ sabatier: false, scrubbers: false, kilopower: false });
    setVisitedWaypoints(['landing']);
    setRoverBattery(92);
    setSamplesCollected(1);
    setStormDecision(null);
  };

  const handleWaypointClick = (wp) => {
    if (visitedWaypoints.includes(wp.id)) return;
    soundManager.playRadarPing();
    setVisitedWaypoints((prev) => [...prev, wp.id]);
    setRoverBattery((b) => Math.max(15, b - 18));
    setSamplesCollected((s) => s + 1);
  };

  const handleStormChoice = (choice) => {
    setStormDecision(choice);
    soundManager.playWarning();
    if (choice === 'shed') {
      setStats((prev) => ({
        ...prev,
        power: prev.power - 14,
        oxygen: prev.oxygen - 4,
        health: prev.health + 1,
      }));
    } else if (choice === 'overclock') {
      setStats((prev) => ({
        ...prev,
        power: Math.min(100, prev.power + 4),
        oxygen: prev.oxygen - 6,
        health: prev.health - 5,
      }));
    } else if (choice === 'eva') {
      setStats((prev) => ({
        ...prev,
        power: prev.power - 6,
        health: prev.health - 18,
      }));
    }
  };

  const selectedRole = ROLES.find((r) => r.id === selectedRoleId) || ROLES[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl bg-[#080B12] border border-[#C65B43]/60 shadow-[0_0_80px_rgba(198,91,67,0.35)] overflow-hidden">
        {/* Top Header Bar */}
        <div className="px-6 py-4 bg-[#101827] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#C65B43] animate-pulse" />
            <span className="font-mono text-xs tracking-widest text-[#F5F1E8] font-bold">
              HABITATION ALPHA // FLIGHT DECK SIMULATOR
            </span>
            <span className="text-white/20 hidden sm:inline">•</span>
            <span className="text-[11px] font-mono text-[#38BDF8] hidden sm:inline">
              STAGE {phase} OF 6
            </span>
          </div>

          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-[#9298A3] hover:text-white transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Telemetry HUD Strip */}
        <div className="px-6 py-2.5 bg-[#080B12] border-b border-white/5 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <div className="flex items-center space-x-4">
            <span className="text-[#9298A3]">CADET: <strong className="text-[#F5F1E8]">{cadetName || 'UNASSIGNED'}</strong></span>
            <span className="text-[#9298A3]">ROLE: <strong className="text-[#C65B43]">{selectedRole.callsign}</strong></span>
          </div>

          <div className="flex items-center space-x-5">
            <span className="flex items-center space-x-1.5">
              <Wind size={13} className="text-[#38BDF8]" />
              <span className="text-[#9298A3]">O₂:</span>
              <span className="text-[#F5F1E8] font-bold">{stats.oxygen}%</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <Droplets size={13} className="text-[#38BDF8]" />
              <span className="text-[#9298A3]">H₂O:</span>
              <span className="text-[#F5F1E8] font-bold">{stats.water}%</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <Zap size={13} className="text-[#FBBF24]" />
              <span className="text-[#9298A3]">PWR:</span>
              <span className="text-[#F5F1E8] font-bold">{stats.power}%</span>
            </span>
            <span className="flex items-center space-x-1.5">
              <Shield size={13} className="text-[#34D399]" />
              <span className="text-[#9298A3]">BIO:</span>
              <span className="text-[#34D399] font-bold">{stats.health}%</span>
            </span>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-10">
          {/* PHASE 1: CADET PROFILE & SPECIALIZATION */}
          {phase === 1 && (
            <div className="animate-in fade-in duration-300">
              <div className="inline-block text-[10px] font-mono tracking-widest text-[#C65B43] uppercase mb-2">
                MISSION INDUCTION // STEP 01
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F1E8] mb-2">
                CREATE YOUR JUNIOR ASTRONAUT PROFILE
              </h3>
              <p className="text-xs text-[#9298A3] leading-relaxed mb-8 font-light">
                Welcome to the NASA Space Apps Mars Expedition Trainer. Input your official flight identifier and assign your specialty role for the Jezero Crater landing.
              </p>

              <div className="mb-8">
                <label className="block text-xs font-mono text-[#9298A3] uppercase mb-2">
                  CADET CALLSIGN / FULL NAME:
                </label>
                <input
                  type="text"
                  value={cadetName}
                  onChange={(e) => setCadetName(e.target.value)}
                  placeholder="Enter your callsign..."
                  className="w-full max-w-md px-4 py-3 rounded-xl bg-[#101827] border border-white/15 focus:border-[#C65B43] text-[#F5F1E8] font-mono text-sm outline-none transition-colors"
                />
              </div>

              <div className="mb-8">
                <label className="block text-xs font-mono text-[#9298A3] uppercase mb-3">
                  SELECT EXPEDITIONARY ROLE:
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {ROLES.map((role) => (
                    <div
                      key={role.id}
                      onClick={() => {
                        soundManager.playClick();
                        setSelectedRoleId(role.id);
                      }}
                      className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                        selectedRoleId === role.id
                          ? 'bg-[#101827] border-[#C65B43] shadow-[0_0_25px_rgba(198,91,67,0.35)]'
                          : 'bg-[#101827]/40 border-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-mono text-xs text-[#C65B43] font-bold">
                          {role.badge}
                        </span>
                        {selectedRoleId === role.id && (
                          <CheckCircle2 size={16} className="text-[#34D399]" />
                        )}
                      </div>
                      <h4 className="font-semibold text-sm text-[#F5F1E8] mb-1">
                        {role.title}
                      </h4>
                      <p className="text-xs text-[#9298A3] leading-relaxed mb-3 font-light">
                        {role.desc}
                      </p>
                      <span className="inline-block text-[10px] font-mono text-[#38BDF8] bg-[#38BDF8]/10 px-2 py-0.5 rounded">
                        {role.perk}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t border-white/10">
                <button
                  onClick={handleNextPhase}
                  disabled={!cadetName.trim()}
                  className="px-6 py-3 rounded-full bg-[#C65B43] hover:bg-[#b04a34] disabled:opacity-50 text-white font-mono text-xs font-semibold tracking-wider transition-all shadow-[0_0_20px_rgba(198,91,67,0.4)] flex items-center space-x-2"
                >
                  <span>COMMENCE STAGE 02: EDL DESCENT</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}

          {/* PHASE 2: "7 MINUTES OF TERROR" SKY CRANE EDL DESCENT */}
          {phase === 2 && (
            <div className="animate-in fade-in duration-300">
              <div className="inline-block text-[10px] font-mono tracking-widest text-[#FBBF24] uppercase mb-2">
                ENTRY, DESCENT & LANDING // STEP 02
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F1E8] mb-2 flex items-center space-x-3">
                <span>"7 MINUTES OF TERROR" — SKY CRANE TOUCHDOWN</span>
                <Flame size={24} className="text-[#FBBF24] animate-pulse" />
              </h3>
              <p className="text-xs text-[#9298A3] leading-relaxed mb-6 font-light">
                Atmospheric entry completed at Mach 20. The supersonic parachute has separated. You now control the Sky Crane descent retro-thrusters. Maintain final touchdown speed under <strong>3.5 m/s</strong> to land softly on the Jezero delta without crashing!
              </p>

              {/* Descent Flight Display Gauge */}
              <div className="p-8 rounded-3xl bg-[#101827] border border-white/10 mb-8 max-w-xl mx-auto shadow-2xl">
                <div className="grid grid-cols-3 gap-4 text-center mb-6 border-b border-white/10 pb-6 font-mono">
                  <div>
                    <div className="text-[10px] text-[#9298A3]">RADAR ALTITUDE</div>
                    <div className="text-3xl font-bold text-[#F5F1E8]">{edlAltitude} m</div>
                  </div>
                  <div>
                    <div className="text-[10px] text-[#9298A3]">DESCENT VELOCITY</div>
                    <div className={`text-3xl font-bold ${edlVelocity <= 3.5 ? 'text-[#34D399]' : 'text-[#F87171]'}`}>
                      {edlVelocity} m/s
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-[#9298A3]">HYDRAZINE FUEL</div>
                    <div className="text-3xl font-bold text-[#FBBF24]">{Math.round(edlFuel)}%</div>
                  </div>
                </div>

                {/* Altitude Visualizer Bar */}
                <div className="mb-6">
                  <div className="flex justify-between text-xs font-mono text-[#9298A3] mb-1">
                    <span>ATMOSPHERIC DESCENT PROFILE</span>
                    <span>{edlAltitude > 0 ? 'DESCENT IN PROGRESS' : 'SURFACE CONTACT'}</span>
                  </div>
                  <div className="w-full bg-[#080B12] h-3 rounded-full overflow-hidden p-0.5 border border-white/10">
                    <div
                      className="bg-gradient-to-r from-[#C65B43] via-[#FBBF24] to-[#34D399] h-full rounded-full transition-all duration-100"
                      style={{ width: `${Math.min(100, (edlAltitude / 2500) * 100)}%` }}
                    />
                  </div>
                </div>

                {/* Interactive Retro-Rocket Throttle Slider */}
                <div className="mb-6">
                  <div className="flex justify-between items-center text-xs font-mono mb-2">
                    <span className="text-[#9298A3]">RETRO-ROCKET THROTTLE CONTROL</span>
                    <span className="text-[#C65B43] font-bold">{edlThrottle}%</span>
                  </div>
                  <input
                    type="range"
                    min="30"
                    max="100"
                    value={edlThrottle}
                    onChange={(e) => {
                      setEdlThrottle(Number(e.target.value));
                      soundManager.playThruster();
                    }}
                    disabled={edlTouchdown || edlFailed}
                    className="w-full accent-[#C65B43] bg-white/10 h-2.5 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] font-mono text-[#9298A3] mt-2">
                    <span>LOW THRUST (FAST DESCENT)</span>
                    <span className="text-[#34D399]">OPTIMAL TOUCHDOWN: 75-85%</span>
                    <span>MAX THRUST</span>
                  </div>
                </div>

                {/* Status Message */}
                {edlTouchdown && (
                  <div className="p-4 rounded-xl bg-[#34D399]/10 border border-[#34D399]/40 text-[#34D399] text-xs font-mono flex items-center justify-center space-x-2">
                    <CheckCircle2 size={16} />
                    <span>TOUCHDOWN CONFIRMED: SKY CRANE HAS BRIDLED DOWN SAFELY IN JEZERO CRATER!</span>
                  </div>
                )}

                {edlFailed && (
                  <div className="p-4 rounded-xl bg-[#F87171]/10 border border-[#F87171]/40 text-[#F87171] text-xs font-mono flex items-center justify-between">
                    <span>IMPACT VELOCITY EXCEEDED HARDWARE LIMITS ({edlVelocity} m/s)</span>
                    <button
                      onClick={() => {
                        setEdlAltitude(2500);
                        setEdlVelocity(48.0);
                        setEdlThrottle(75);
                        setEdlFuel(100);
                        setEdlFailed(false);
                      }}
                      className="px-3 py-1 rounded bg-white/10 text-white font-bold"
                    >
                      RETRY EDL
                    </button>
                  </div>
                )}
              </div>

              <div className="flex justify-end pt-4 border-t border-white/10">
                <button
                  onClick={handleNextPhase}
                  disabled={!edlTouchdown}
                  className="px-6 py-3 rounded-full bg-[#C65B43] hover:bg-[#b04a34] disabled:opacity-50 text-white font-mono text-xs font-semibold tracking-wider transition-all shadow-[0_0_20px_rgba(198,91,67,0.4)] flex items-center space-x-2"
                >
                  <span>ADVANCE TO HABITATION ALPHA ECLSS BOOT</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}

          {/* PHASE 3: HABITATION ALPHA ECLSS BOOT & MOXIE CALIBRATION */}
          {phase === 3 && (
            <div className="animate-in fade-in duration-300">
              <div className="inline-block text-[10px] font-mono tracking-widest text-[#38BDF8] uppercase mb-2">
                LIFE SUPPORT INITIALIZATION // STEP 03
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F1E8] mb-2">
                HABITATION ALPHA ECLSS & MOXIE BOOT
              </h3>
              <p className="text-xs text-[#9298A3] leading-relaxed mb-6 font-light">
                Initialize the primary life-support systems: engage the Sabatier water reclamation loops, boot CO₂ scrubbers, and bring MOXIE solid-oxide electrolysis to the 800°C target temperature.
              </p>

              {/* Hardware Toggle Switches */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div
                  onClick={() => {
                    soundManager.playClick();
                    setSwitchToggles((prev) => ({ ...prev, sabatier: !prev.sabatier }));
                  }}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                    switchToggles.sabatier
                      ? 'bg-[#101827] border-[#38BDF8] shadow-[0_0_20px_rgba(56,189,248,0.3)]'
                      : 'bg-[#101827]/40 border-white/10'
                  }`}
                >
                  <div className="flex justify-between items-center mb-2">
                    <Droplets size={18} className="text-[#38BDF8]" />
                    <span className="font-mono text-[10px] text-[#34D399]">
                      {switchToggles.sabatier ? 'ONLINE' : 'OFFLINE'}
                    </span>
                  </div>
                  <h4 className="font-semibold text-sm text-[#F5F1E8]">Sabatier Loop</h4>
                  <p className="text-[11px] text-[#9298A3]">Recycles 98.4% crew moisture into potable H₂O.</p>
                </div>

                <div
                  onClick={() => {
                    soundManager.playClick();
                    setSwitchToggles((prev) => ({ ...prev, scrubbers: !prev.scrubbers }));
                  }}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                    switchToggles.scrubbers
                      ? 'bg-[#101827] border-[#34D399] shadow-[0_0_20px_rgba(52,211,153,0.3)]'
                      : 'bg-[#101827]/40 border-white/10'
                  }`}
                >
                  <div className="flex justify-between items-center mb-2">
                    <Wind size={18} className="text-[#34D399]" />
                    <span className="font-mono text-[10px] text-[#34D399]">
                      {switchToggles.scrubbers ? 'ONLINE' : 'OFFLINE'}
                    </span>
                  </div>
                  <h4 className="font-semibold text-sm text-[#F5F1E8]">CO₂ Amine Beds</h4>
                  <p className="text-[11px] text-[#9298A3]">Filters atmospheric carbon dioxide from Hab air.</p>
                </div>

                <div
                  onClick={() => {
                    soundManager.playClick();
                    setSwitchToggles((prev) => ({ ...prev, kilopower: !prev.kilopower }));
                  }}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                    switchToggles.kilopower
                      ? 'bg-[#101827] border-[#FBBF24] shadow-[0_0_20px_rgba(251,191,36,0.3)]'
                      : 'bg-[#101827]/40 border-white/10'
                  }`}
                >
                  <div className="flex justify-between items-center mb-2">
                    <Zap size={18} className="text-[#FBBF24]" />
                    <span className="font-mono text-[10px] text-[#34D399]">
                      {switchToggles.kilopower ? 'ONLINE' : 'OFFLINE'}
                    </span>
                  </div>
                  <h4 className="font-semibold text-sm text-[#F5F1E8]">Kilopower Reactor</h4>
                  <p className="text-[11px] text-[#9298A3]">10 kW nuclear Stirling engine for base power.</p>
                </div>
              </div>

              {/* MOXIE Thermal Slider */}
              <div className="p-6 rounded-2xl bg-[#101827] border border-white/10 mb-8 max-w-xl mx-auto text-center">
                <div className="text-xs font-mono text-[#9298A3] uppercase mb-2">
                  MOXIE SOLID-OXIDE TEMPERATURE TARGET
                </div>
                <div className="font-mono text-4xl font-bold mb-4">
                  <span className={Math.abs(moxieTemp - 800) < 15 ? 'text-[#34D399]' : 'text-[#FBBF24]'}>
                    {moxieTemp}°C
                  </span>
                </div>

                <input
                  type="range"
                  min="600"
                  max="1000"
                  value={moxieTemp}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setMoxieTemp(val);
                    if (Math.abs(val - 800) < 15) {
                      setMoxieCalibrated(true);
                      soundManager.playClick();
                    }
                  }}
                  className="w-full accent-[#C65B43] bg-white/10 h-2 rounded-lg cursor-pointer mb-3"
                />

                <div className="flex justify-between text-[10px] font-mono text-[#9298A3]">
                  <span>600°C</span>
                  <span className="text-[#34D399]">TARGET: 800°C</span>
                  <span>1000°C</span>
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t border-white/10">
                <button
                  onClick={handleNextPhase}
                  disabled={!switchToggles.sabatier || !switchToggles.scrubbers || !switchToggles.kilopower || !moxieCalibrated}
                  className="px-6 py-3 rounded-full bg-[#C65B43] hover:bg-[#b04a34] disabled:opacity-50 text-white font-mono text-xs font-semibold tracking-wider transition-all shadow-[0_0_20px_rgba(198,91,67,0.4)] flex items-center space-x-2"
                >
                  <span>ENGAGE SYSTEMS & LAUNCH ROVER EXPEDITION</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}

          {/* PHASE 4: JEZERO DELTA TACTICAL ROVER EXPEDITION */}
          {phase === 4 && (
            <div className="animate-in fade-in duration-300">
              <div className="inline-block text-[10px] font-mono tracking-widest text-[#34D399] uppercase mb-2">
                TACTICAL TRAVERSE // STEP 04
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F1E8] mb-2">
                JEZERO DELTA RECONNAISSANCE MAP
              </h3>
              <p className="text-xs text-[#9298A3] leading-relaxed mb-6 font-light">
                Plot waypoints across the ancient Jezero river delta to extract scientific core samples. Click each uncharted sector to deploy the coring drill while monitoring battery energy.
              </p>

              {/* Interactive Radar Vector Map */}
              <div className="relative h-[320px] rounded-3xl bg-[#101827] border border-white/10 mb-8 overflow-hidden p-6 flex items-center justify-center shadow-2xl">
                <div className="absolute inset-0 telemetry-grid opacity-30 pointer-events-none" />

                {/* Radar Sweep Circle */}
                <div className="absolute w-[280px] h-[280px] rounded-full border border-white/10 pointer-events-none" />
                <div className="absolute w-[180px] h-[180px] rounded-full border border-white/5 pointer-events-none" />

                {/* Jezero Delta River Basin Outline */}
                <svg className="absolute inset-0 w-full h-full opacity-40 pointer-events-none" viewBox="0 0 600 320">
                  <path d="M 0 160 Q 180 140 280 180 T 450 120 T 600 150" stroke="#38BDF8" strokeWidth="2" fill="none" strokeDasharray="4 4" />
                  <path d="M 280 180 Q 320 220 380 250" stroke="#38BDF8" strokeWidth="1.5" fill="none" strokeDasharray="3 3" />
                </svg>

                {/* Interactive Waypoints */}
                {JEZERO_WAYPOINTS.map((wp) => {
                  const isVisited = visitedWaypoints.includes(wp.id);
                  return (
                    <button
                      key={wp.id}
                      onClick={() => handleWaypointClick(wp)}
                      style={{ top: wp.y, left: wp.x }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 p-3 rounded-full border transition-all z-20 group ${
                        isVisited
                          ? 'bg-[#34D399] border-white scale-110 shadow-[0_0_20px_#34D399]'
                          : 'bg-[#101827] border-[#C65B43] hover:scale-125 hover:border-white'
                      }`}
                    >
                      <Navigation size={14} className={isVisited ? 'text-black font-bold' : 'text-[#C65B43]'} />
                      <div className="absolute bottom-9 left-1/2 -translate-x-1/2 bg-[#080B12]/90 border border-white/10 px-2.5 py-1 rounded text-[10px] font-mono text-white whitespace-nowrap backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity">
                        {wp.name} ({wp.sample})
                      </div>
                    </button>
                  );
                })}

                <div className="absolute bottom-4 left-6 text-xs font-mono text-[#9298A3]">
                  ROVER BATTERY: <strong className="text-[#FBBF24]">{roverBattery}%</strong> • SAMPLES SEALED: <strong className="text-[#34D399]">{samplesCollected} OF 4</strong>
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t border-white/10">
                <button
                  onClick={handleNextPhase}
                  disabled={visitedWaypoints.length < 3}
                  className="px-6 py-3 rounded-full bg-[#C65B43] hover:bg-[#b04a34] disabled:opacity-50 text-white font-mono text-xs font-semibold tracking-wider transition-all shadow-[0_0_20px_rgba(198,91,67,0.4)] flex items-center space-x-2"
                >
                  <span>RETURN TO BASE & PREPARE FOR CRISIS TRIAGE</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}

          {/* PHASE 5: DUST STORM CRISIS */}
          {phase === 5 && (
            <div className="animate-in fade-in duration-300">
              <div className="inline-block text-[10px] font-mono tracking-widest text-[#F87171] uppercase mb-2">
                CRITICAL TRIAGE // STEP 05
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F1E8] mb-2 flex items-center space-x-3">
                <span>PLANET-ENCIRCLING DUST STORM ANOMALY</span>
                <AlertTriangle size={24} className="text-[#F87171] animate-bounce" />
              </h3>
              <p className="text-xs text-[#9298A3] leading-relaxed mb-6 font-light">
                Atmospheric opacity has spiked to tau 4.8. Photovoltaic solar generation has plummeted 75%. Radio delay to Houston is 14 minutes. As Junior Commander, select your survival protocol immediately.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
                <div
                  onClick={() => handleStormChoice('shed')}
                  className={`p-6 rounded-2xl border cursor-pointer transition-all ${
                    stormDecision === 'shed'
                      ? 'bg-[#101827] border-[#38BDF8] shadow-[0_0_25px_rgba(56,189,248,0.3)]'
                      : 'bg-[#101827]/50 border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="text-xs font-mono text-[#38BDF8] font-bold mb-2">
                    OPTION A: PROTOCOL EPS-1
                  </div>
                  <h4 className="font-semibold text-sm text-[#F5F1E8] mb-2">Shed Scientific Labs</h4>
                  <p className="text-xs text-[#9298A3] leading-relaxed mb-4 font-light">
                    Channel remaining battery reserves exclusively to crew thermal suits and Sabatier life support.
                  </p>
                  <div className="text-[10px] font-mono text-[#34D399]">
                    PRESERVES CREW VITALS • SAFE CONSERVATIVE TRIAGE
                  </div>
                </div>

                <div
                  onClick={() => handleStormChoice('overclock')}
                  className={`p-6 rounded-2xl border cursor-pointer transition-all ${
                    stormDecision === 'overclock'
                      ? 'bg-[#101827] border-[#FBBF24] shadow-[0_0_25px_rgba(251,191,36,0.3)]'
                      : 'bg-[#101827]/50 border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="text-xs font-mono text-[#FBBF24] font-bold mb-2">
                    OPTION B: PROTOCOL NUC-X
                  </div>
                  <h4 className="font-semibold text-sm text-[#F5F1E8] mb-2">Overclock Fission Core</h4>
                  <p className="text-xs text-[#9298A3] leading-relaxed mb-4 font-light">
                    Push Stirling heat exchangers to 125% output. Retains base systems but introduces thermal loop stress.
                  </p>
                  <div className="text-[10px] font-mono text-[#FBBF24]">
                    HIGH POWER SURPLUS • MODERATE WEAR HAZARD
                  </div>
                </div>

                <div
                  onClick={() => handleStormChoice('eva')}
                  className={`p-6 rounded-2xl border cursor-pointer transition-all ${
                    stormDecision === 'eva'
                      ? 'bg-[#101827] border-[#F87171] shadow-[0_0_25px_rgba(248,113,113,0.3)]'
                      : 'bg-[#101827]/50 border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="text-xs font-mono text-[#F87171] font-bold mb-2">
                    OPTION C: PROTOCOL EVA-HAZARD
                  </div>
                  <h4 className="font-semibold text-sm text-[#F5F1E8] mb-2">Emergency EVA Sweep</h4>
                  <p className="text-xs text-[#9298A3] leading-relaxed mb-4 font-light">
                    Crew ventures outside into 90 km/h winds with electrostatic brooms to clear the solar panels.
                  </p>
                  <div className="text-[10px] font-mono text-[#F87171]">
                    HIGH RISK: PERCHLORATE DUST & SUIT DAMAGE
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-4 border-t border-white/10">
                <button
                  onClick={handleNextPhase}
                  disabled={!stormDecision}
                  className="px-6 py-3 rounded-full bg-[#C65B43] hover:bg-[#b04a34] disabled:opacity-50 text-white font-mono text-xs font-semibold tracking-wider transition-all shadow-[0_0_20px_rgba(198,91,67,0.4)] flex items-center space-x-2"
                >
                  <span>SURVIVE DUST STORM & CONCLUDE MISSION</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}

          {/* PHASE 6: OFFICIAL CERTIFICATION & DEBRIEF */}
          {phase === 6 && (
            <div className="animate-in fade-in zoom-in-95 duration-500 text-center">
              <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-[#34D399]/10 border border-[#34D399]/30 text-[#34D399] text-xs font-mono uppercase mb-4">
                <Award size={15} />
                <span>EXPEDITION COMPLETED WITH DISTINCTION</span>
              </div>

              <h3 className="font-display text-3xl sm:text-4xl font-bold text-[#F5F1E8] mb-2">
                MISSION ACCOMPLISHED, COMMANDER {cadetName.toUpperCase()}!
              </h3>
              <p className="text-xs text-[#9298A3] max-w-lg mx-auto mb-8 font-light leading-relaxed">
                You successfully mastered the 7 Minutes of Terror Sky Crane landing, calibrated ECLSS life support, conducted the Jezero river delta reconnaissance, and protected Habitation Alpha through planetary dust storm hazards.
              </p>

              {/* Official Museum-Grade NASA Space Apps Certificate */}
              <div
                id="printable-certificate"
                className="p-8 sm:p-12 rounded-3xl bg-gradient-to-b from-[#101827] via-[#0E1524] to-[#080B12] border-2 border-[#C65B43]/70 max-w-2xl mx-auto shadow-2xl relative overflow-hidden mb-8 text-left"
              >
                {/* Background Watermark */}
                <div className="absolute right-4 bottom-4 w-56 h-56 rounded-full border border-white/5 pointer-events-none flex items-center justify-center opacity-10">
                  <span className="font-display font-bold text-8xl text-white">MARS</span>
                </div>

                <div className="flex justify-between items-start mb-6 border-b border-white/10 pb-4">
                  <div>
                    <div className="font-display font-bold text-lg text-[#F5F1E8] tracking-widest">
                      MARS — JUNIOR ASTRONAUT TRAINER
                    </div>
                    <div className="text-[10px] font-mono text-[#C65B43] tracking-widest uppercase">
                      NASA SPACE APPS CHALLENGE 2026 • OFFICIAL FLIGHT CREDENTIAL
                    </div>
                  </div>
                  <div className="w-12 h-12 rounded-xl bg-[#C65B43]/20 border border-[#C65B43]/50 flex items-center justify-center text-[#C65B43]">
                    <Rocket size={24} />
                  </div>
                </div>

                <p className="text-xs font-mono text-[#9298A3] mb-1">THIS CERTIFIES THAT</p>
                <div className="font-display text-3xl sm:text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#F5F1E8] via-[#E07A5F] to-[#C65B43] mb-4">
                  {cadetName || 'Aria Vance'}
                </div>

                <p className="text-xs text-[#F5F1E8]/85 leading-relaxed mb-6 font-light">
                  Has demonstrated superior aerospace intelligence, cognitive triage, and life-support operational acumen during the simulated expedition to Jezero Crater, Mars. Formally qualified as a certified Junior Astronaut Candidate.
                </p>

                <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/10 font-mono text-[11px]">
                  <div>
                    <span className="text-[#9298A3] block">ASSIGNED ROLE:</span>
                    <strong className="text-[#F5F1E8]">{selectedRole.title}</strong>
                  </div>
                  <div>
                    <span className="text-[#9298A3] block">MISSION RATING:</span>
                    <strong className="text-[#34D399]">99.2% (EXEMPLARY)</strong>
                  </div>
                  <div>
                    <span className="text-[#9298A3] block">SECTOR:</span>
                    <strong className="text-[#38BDF8]">JEZERO DELTA</strong>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-4">
                <button
                  onClick={() => window.print()}
                  className="px-6 py-3 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-[#F5F1E8] font-mono text-xs font-semibold tracking-wider transition-all flex items-center space-x-2"
                >
                  <Printer size={14} />
                  <span>PRINT OFFICIAL CERTIFICATE</span>
                </button>

                <button
                  onClick={handleRestart}
                  className="px-6 py-3 rounded-full bg-[#C65B43] hover:bg-[#b04a34] text-white font-mono text-xs font-semibold tracking-wider transition-all shadow-[0_0_20px_rgba(198,91,67,0.4)] flex items-center space-x-2"
                >
                  <RotateCcw size={14} />
                  <span>REPLAY MISSION SIMULATION</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
