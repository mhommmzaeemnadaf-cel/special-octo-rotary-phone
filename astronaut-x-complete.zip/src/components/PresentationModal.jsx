import React, { useState, useEffect } from 'react';
import {
  X, ChevronLeft, ChevronRight, Presentation, Rocket, Globe, Radio,
  Shield, Wrench, Award, ExternalLink, Play, CheckCircle2, Sparkles
} from 'lucide-react';
import { soundManager } from '../utils/audio';

const SLIDES = [
  {
    step: '01',
    title: 'THE NEXT GIANT LEAP BEGINS WITH YOU',
    subtitle: 'NASA Space Apps Challenge 2026 • Planetary Science & Mission Simulation',
    category: 'EXPEDITION VISION',
    tagline: 'Moving beyond ordinary educational dashboards to create an A24-cinematic, Apple-refined aerospace flight trainer.',
    bullets: [
      'An immersive web experience introducing next-gen astronauts to the realities of Mars.',
      'Combines authentic NASA telemetry, Keplerian orbital lag calculations, and interactive 3D WebGL.',
      'Designed to inspire global STEM students through high-stakes experiential simulation.',
    ],
    targetId: null,
    highlightMetric: 'MISSION 01 // JEZERO DELTA',
  },
  {
    step: '02',
    title: 'THE HOSTILE MARTIAN REALITY',
    subtitle: 'Why Surviving Beyond Earth is a Precision Physical Calculation',
    category: 'THE SCIENTIFIC CHALLENGE',
    tagline: 'Near-vacuum pressure (738 Pa), freezing -84°C nights, lethal UV radiation, and 14-minute signal delays.',
    bullets: [
      'Atmospheric pressure is less than 1% of Earth — liquids boil at body temperature without a pressure suit.',
      '95.3% CO₂ atmosphere demands continuous MOXIE solid-oxide electrolysis to produce oxygen.',
      '14-minute radio lag prevents Houston from assisting in real time; astronauts must make autonomous decisions.',
    ],
    targetId: 'introduction',
    highlightMetric: '0.72% EARTH PRESSURE • 14m 22s LAG',
  },
  {
    step: '03',
    title: '3D THREE.JS MARS & MULTI-SPECTRAL SENSORS',
    subtitle: 'Photorealistic WebGL Planetary Globe with Real Elevation & Thermal Data',
    category: 'INTERACTIVE 3D RECONNAISSANCE',
    tagline: 'Inspect Mars across three authentic scientific sensor channels with smooth orbital camera fly-to navigation.',
    bullets: [
      'Natural Albedo: Procedural high-res surface variegation, Syrtis Major, and polar ice caps.',
      'MOLA Elevation: False-color topography heatmap from Hellas Basin (-8km) to Olympus Mons (+21.9km).',
      'THEMIS Thermal: Night-side infrared thermal emission revealing exposed high-inertia bedrock.',
      'Orbiting MRO satellite with trajectory rings and independent drifting ice/dust cloud layers.',
    ],
    targetId: null, // hero
    highlightMetric: '3 SPECTRAL MODES • 25.19° AXIAL TILT',
  },
  {
    step: '04',
    title: 'LIVE PERSEVERANCE MEDA WEATHER STATION',
    subtitle: 'Real-Time Martian Local Solar Time & Environmental Telemetry',
    category: 'LIVE PLANETARY METEOROLOGY',
    tagline: 'Synchronized Sol clocks, live atmospheric pressure, and real-time Earth-Mars distance calculator.',
    bullets: [
      'Ticking Local Mars Solar Time (LMST) based on authentic 24h 39m 35s Martian day cycles.',
      'Real-time atmospheric pressure (738 Pa), air temperatures (-18°C to -84°C), and wind vectors (7.2 m/s ESE).',
      'Live orbital distance tracker (225M+ km) with interactive "Ping Mars Transceiver" speed-of-light simulator.',
    ],
    targetId: 'meteorology',
    highlightMetric: '738 Pa • SOL 1042 LMST CLOCK',
  },
  {
    step: '05',
    title: 'THE THREE PILLARS OF MARS SURVIVAL',
    subtitle: 'Closed-Loop ECLSS, Surface Exploration & Autonomous Triage',
    category: 'EXPEDITIONARY DOCTRINE',
    tagline: 'Foundational aerospace systems engineered for deep space human survival.',
    bullets: [
      '01 Survival: MOXIE solid-oxide oxygen synthesis, Sabatier water loops (98.4% recovery), and Kilopower 10kW nuclear reactor.',
      '02 Exploration: Pressurized rover logistics (120 km range), glacial radar sounding, and electrostatic dust mitigation.',
      '03 Decision: Autonomous crisis triage, orbital delta-v abort calculations, and dynamic power shedding.',
    ],
    targetId: 'three-pillars',
    highlightMetric: 'MOXIE 12.0 g/h • 98.4% RECLAIM',
  },
  {
    step: '06',
    title: 'EXPEDITIONARY ROVER TECHNICAL SCHEMATICS',
    subtitle: 'Interactive Engineering Blueprint of the Mars Exploration Vehicle',
    category: 'HARDWARE ARCHIVE',
    tagline: 'Clickable interactive hotspots exploring the anatomy of deep space surface mobility.',
    bullets: [
      'MMRTG Nuclear Generator: 4.8 kg Plutonium-238 generating 110W uninterrupted electricity.',
      'Rocker-Bogie Suspension: 6-wheel kinematic differential linkage climbing obstacles up to 40 cm.',
      'Mastcam-Z & SuperCam Laser: 3D stereoscopic optical zoom and laser-induced breakdown spectroscopy.',
      'Robotic Coring Arm: 5-DOF arm holding rotary percussive drill and hermetically sealed titanium sample cache tubes.',
    ],
    targetId: 'rover-fleet',
    highlightMetric: 'MMRTG 110W • ROCKER-BOGIE 6WD',
  },
  {
    step: '07',
    title: 'THE 6-STAGE MISSION SIMULATOR',
    subtitle: 'From the "7 Minutes of Terror" Sky Crane Touchdown to Full Certification',
    category: 'TACTILE FLIGHT DECK',
    tagline: 'An electrifying physics-based aerospace simulation directly in the browser.',
    bullets: [
      'Stage 1: Astronaut selection with specialized tactical roles and traits.',
      'Stage 2: Physics-based retro-rocket throttle mini-game to touch down softly (< 3.5 m/s) in Jezero Basin.',
      'Stage 3: Habitation Alpha ECLSS boot with tactile switches and 800°C MOXIE thermal calibration.',
      'Stage 4: Jezero delta vector radar navigation to sample ancient river sediments.',
      'Stage 5: High-stakes dust storm emergency triage under 14-minute communication latency.',
    ],
    targetId: 'mission-dashboard',
    highlightMetric: 'PHYSICS EDL • 6 INTERACTIVE PHASES',
  },
  {
    step: '08',
    title: 'OFFICIAL NASA SPACE APPS CERTIFICATION',
    subtitle: 'Museum-Grade Personalized Astronaut Credentials',
    category: 'FLIGHT RECOGNITION',
    tagline: 'Awarding successful cadet graduates with official verifiable flight credentials.',
    bullets: [
      'Generates a personalized official certificate with the cadet name, assigned role, and exemplary score.',
      'Features the official NASA Space Apps 2026 seal, Jezero Delta emblem, and cryptographic verification hash.',
      'Includes one-click browser print capability and interactive confetti celebration.',
    ],
    targetId: 'mission-dashboard',
    highlightMetric: 'PRINTABLE • CONFETTI CELEBRATION',
  },
  {
    step: '09',
    title: 'ARCHITECTURAL PURITY & NATIVE WEB AUDIO',
    subtitle: 'Zero External Assets, Zero Network Lag, 100% Client-Side Synthesis',
    category: 'TECHNICAL EXCELLENCE',
    tagline: 'How modern web standards enable ultra-fast, offline-capable aerospace visualization.',
    bullets: [
      'Built with React 19, Vite 8, Three.js, and Tailwind CSS v4 with sub-200ms build times.',
      'Web Audio API Synthesizer: Generates real Martian wind noise (Perseverance microphone profile), binaural drones, and Quindar tones procedurally.',
      'Zero external MP3 or heavy 3D asset downloads — entire site loads in under 1 second.',
      'Fully responsive across desktop, tablet, and mobile with keyboard shortcuts [Space], [M], [P].',
    ],
    targetId: null,
    highlightMetric: 'SUB-200ms BUILD • NATIVE SYNTH',
  },
  {
    step: '10',
    title: 'EDUCATIONAL IMPACT & GLOBAL ACCESSIBILITY',
    subtitle: 'Empowering the Next Generation of Planetary Explorers',
    category: 'COMPETITION CONCLUSION',
    tagline: 'Free, open, and scientifically verified for students and space enthusiasts worldwide.',
    bullets: [
      'Democratizes planetary science education without paywalls, sign-ups, or hardware requirements.',
      'Built using verified datasets from NASA JPL, MRO, and the Planetary Data System.',
      'Ready for global hackathon judging, classroom curriculums, and STEM outreach.',
    ],
    targetId: null,
    highlightMetric: 'NASA SPACE APPS 2026 • GLOBAL STEM',
  },
];

export default function PresentationModal({ isOpen, onClose }) {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e) => {
      if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        e.preventDefault();
        handleNext();
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        handlePrev();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        soundManager.playClick();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, currentSlide]);

  if (!isOpen) return null;

  const slide = SLIDES[currentSlide];

  const handleNext = () => {
    if (currentSlide < SLIDES.length - 1) {
      soundManager.playClick();
      setCurrentSlide((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentSlide > 0) {
      soundManager.playClick();
      setCurrentSlide((prev) => prev - 1);
    }
  };

  const handleJumpToSection = (targetId) => {
    soundManager.playClick();
    onClose();
    if (!targetId) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const el = document.getElementById(targetId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-black/90 backdrop-blur-2xl animate-in fade-in duration-300">
      <div className="relative w-full max-w-5xl h-[88vh] flex flex-col rounded-3xl bg-[#080B12] border-2 border-[#C65B43]/60 shadow-[0_0_100px_rgba(198,91,67,0.4)] overflow-hidden">
        {/* Top Header Bar */}
        <div className="px-6 py-4 bg-[#101827] border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Presentation size={18} className="text-[#C65B43]" />
            <span className="font-mono text-xs tracking-widest text-[#F5F1E8] font-bold uppercase">
              NASA SPACE APPS 2026 // OFFICIAL PITCH DECK
            </span>
            <span className="text-white/20 hidden sm:inline">•</span>
            <span className="text-[11px] font-mono text-[#38BDF8] hidden sm:inline">
              SLIDE {currentSlide + 1} OF {SLIDES.length}
            </span>
          </div>

          <div className="flex items-center space-x-3">
            <span className="text-[10px] font-mono text-[#9298A3] hidden md:inline">
              USE [←] [→] KEYS TO NAVIGATE • [ESC] TO CLOSE
            </span>
            <button
              onClick={() => {
                soundManager.playClick();
                onClose();
              }}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-[#9298A3] hover:text-white transition-colors"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Slide Main Presentation Canvas */}
        <div className="flex-1 overflow-y-auto p-8 sm:p-12 flex flex-col justify-between relative">
          {/* Subtle Ambient Telemetry Grid */}
          <div className="absolute inset-0 telemetry-grid opacity-20 pointer-events-none" />

          {/* Slide Top Badge & Category */}
          <div className="relative z-10 mb-6">
            <div className="flex items-center justify-between mb-3">
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#C65B43]/15 border border-[#C65B43]/30 text-xs font-mono text-[#C65B43] tracking-widest uppercase">
                <Sparkles size={13} />
                <span>{slide.category}</span>
              </div>
              <div className="font-mono text-xs font-bold text-[#38BDF8] bg-[#38BDF8]/10 px-3 py-1 rounded-full border border-[#38BDF8]/20">
                {slide.highlightMetric}
              </div>
            </div>

            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#F5F1E8] uppercase leading-[1.05] mb-2">
              {slide.title}
            </h2>
            <div className="font-mono text-xs text-[#E07A5F] tracking-wider uppercase mb-4">
              {slide.subtitle}
            </div>
            <p className="text-sm md:text-base text-[#9298A3] leading-relaxed max-w-3xl font-light italic mb-8">
              “{slide.tagline}”
            </p>

            {/* Bullet Points Grid */}
            <div className="space-y-3.5 max-w-3xl mb-8">
              {slide.bullets.map((b, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-[#101827]/80 border border-white/5 flex items-start space-x-3.5 backdrop-blur-md"
                >
                  <CheckCircle2 size={18} className="text-[#34D399] shrink-0 mt-0.5" />
                  <span className="text-xs sm:text-sm text-[#F5F1E8]/90 leading-relaxed font-light">
                    {b}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Slide Bottom Bar with Jump to Live Demo Button */}
          <div className="relative z-10 flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/10">
            {slide.targetId !== undefined && (
              <button
                onClick={() => handleJumpToSection(slide.targetId)}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-xs font-mono text-[#38BDF8] flex items-center space-x-2 transition-all"
              >
                <ExternalLink size={14} />
                <span>JUMP TO LIVE WEBSITE DEMO</span>
              </button>
            )}

            <div className="flex items-center space-x-2">
              {SLIDES.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    soundManager.playClick();
                    setCurrentSlide(i);
                  }}
                  className={`h-1.5 rounded-full transition-all ${
                    currentSlide === i ? 'w-8 bg-[#C65B43]' : 'w-2 bg-white/20 hover:bg-white/40'
                  }`}
                  title={`Slide ${i + 1}`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Slide Navigation Bar */}
        <div className="px-6 py-4 bg-[#101827] border-t border-white/10 flex items-center justify-between">
          <button
            onClick={handlePrev}
            disabled={currentSlide === 0}
            className="px-5 py-2.5 rounded-full bg-white/5 hover:bg-white/10 disabled:opacity-30 text-white font-mono text-xs tracking-wider transition-all flex items-center space-x-2"
          >
            <ChevronLeft size={16} />
            <span>PREVIOUS SLIDE</span>
          </button>

          <span className="font-mono text-xs text-[#9298A3]">
            {currentSlide + 1} / {SLIDES.length}
          </span>

          <button
            onClick={handleNext}
            disabled={currentSlide === SLIDES.length - 1}
            className="px-6 py-2.5 rounded-full bg-[#C65B43] hover:bg-[#b04a34] disabled:opacity-30 text-white font-mono text-xs font-semibold tracking-wider transition-all shadow-[0_0_20px_rgba(198,91,67,0.4)] flex items-center space-x-2"
          >
            <span>NEXT SLIDE</span>
            <ChevronRight size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
