import React, { useState } from 'react';
import { Shield, Zap, Wind, Droplets, Utensils, Users, Plus, Trash2, Award, RotateCcw, AlertTriangle, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../utils/audio';

const MODULE_TYPES = [
  {
    type: 'solar',
    name: 'Solar PV Array',
    icon: '☀️',
    cost: 10,
    power: +20,
    o2: 0,
    water: 0,
    food: 0,
    crew: 0,
    desc: 'Provides +20 kW clean solar energy during daytime Sol.',
  },
  {
    type: 'nuclear',
    name: 'Kilopower Fission Core',
    icon: '⚛️',
    cost: 30,
    power: +55,
    o2: 0,
    water: 0,
    food: 0,
    crew: 0,
    desc: 'Heavy-duty 10kW Stirling fission reactor for night & dust storm baseline.',
  },
  {
    type: 'moxie',
    name: 'MOXIE Oxygen Dome',
    icon: '💨',
    cost: 20,
    power: -12,
    o2: +60,
    water: 0,
    food: 0,
    crew: 0,
    desc: 'Solid-oxide CO2 electrolysis producing +60 L breathable O2/day.',
  },
  {
    type: 'water',
    name: 'Sabatier Recycler',
    icon: '💧',
    cost: 18,
    power: -10,
    o2: 0,
    water: +50,
    food: 0,
    crew: 0,
    desc: 'Catalytic reduction closed-loop recycling +50 L potable H2O/day.',
  },
  {
    type: 'greenhouse',
    name: 'Aeroponic Greenhouse',
    icon: '🌱',
    cost: 22,
    power: -16,
    o2: +15,
    water: -20,
    food: +150,
    crew: 0,
    desc: 'LED vertical farming producing +150 kcal food rations from washed regolith.',
  },
  {
    type: 'hab',
    name: 'Pressurized Crew Hab',
    icon: '🏠',
    cost: 25,
    power: -18,
    o2: -35,
    water: -30,
    food: -120,
    crew: +4,
    desc: 'Radiation-shielded living quarters accommodating 4 astronauts.',
  },
];

const INITIAL_GRID = Array(12).fill(null);

export default function HabBaseBuilder() {
  const [grid, setGrid] = useState(INITIAL_GRID);
  const [selectedModuleType, setSelectedModuleType] = useState('solar');
  const [credits, setCredits] = useState(150);
  const [celebrated, setCelebrated] = useState(false);

  // Compute live resource balance
  let powerBalance = 0;
  let o2Balance = 0;
  let waterBalance = 0;
  let foodBalance = 0;
  let totalCrew = 0;

  grid.forEach((slot) => {
    if (slot) {
      const mod = MODULE_TYPES.find((m) => m.type === slot.type);
      if (mod) {
        powerBalance += mod.power;
        o2Balance += mod.o2;
        waterBalance += mod.water;
        foodBalance += mod.food;
        totalCrew += mod.crew;
      }
    }
  });

  const isSelfSustaining =
    totalCrew >= 8 &&
    powerBalance >= 0 &&
    o2Balance >= 0 &&
    waterBalance >= 0 &&
    foodBalance >= 0;

  const handlePlaceModule = (index) => {
    soundManager.playClick();
    const mod = MODULE_TYPES.find((m) => m.type === selectedModuleType);
    if (!mod) return;

    // Check if slot occupied
    if (grid[index]) {
      // Remove module and refund
      const existing = MODULE_TYPES.find((m) => m.type === grid[index].type);
      setCredits((c) => c + existing.cost);
      const newGrid = [...grid];
      newGrid[index] = null;
      setGrid(newGrid);
      return;
    }

    // Check credits
    if (credits < mod.cost) {
      soundManager.playWarning();
      return;
    }

    setCredits((c) => c - mod.cost);
    const newGrid = [...grid];
    newGrid[index] = { type: mod.type, name: mod.name, icon: mod.icon };
    setGrid(newGrid);

    // Check victory
    if (!celebrated && totalCrew + mod.crew >= 8) {
      soundManager.playSuccess();
      setCelebrated(true);
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#34D399', '#38BDF8', '#C65B43', '#FBBF24'],
        });
      } catch (e) {}
    }
  };

  const handleReset = () => {
    soundManager.playClick();
    setGrid(INITIAL_GRID);
    setCredits(150);
    setCelebrated(false);
  };

  return (
    <section className="py-24 bg-[#080B12] border-t border-white/5 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#FBBF24] uppercase mb-3">
              <span className="w-2 h-2 rounded-full bg-[#FBBF24] animate-pulse" />
              <span>COLONY ARCHITECT SANDBOX // STRATEGIC SIMULATION</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#F5F1E8] uppercase">
              MARTIAN HABITATION BUILDER
            </h2>
          </div>
          <p className="max-w-md text-sm text-[#9298A3] font-light leading-relaxed">
            Construct Habitation Alpha at Jezero Basin. Place solar arrays, MOXIE domes, and greenhouse farms to achieve a 100% self-sustaining astronaut base!
          </p>
        </div>

        {/* Builder Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: 4x3 Colony Surface Plot Grid (7 Cols) */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl bg-[#101827] border border-white/10 shadow-2xl relative">
            <div className="flex justify-between items-center mb-6 font-mono text-xs">
              <div>
                <span className="text-[#9298A3]">SECTOR: </span>
                <span className="text-white font-bold">JEZERO DELTA FOUNDATION PLOT</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-[#9298A3]">CREDITS:</span>
                <span className="text-xl font-bold text-[#FBBF24]">{credits} M$</span>
              </div>
            </div>

            {/* 4x3 Plot Grid */}
            <div className="grid grid-cols-4 gap-3 sm:gap-4 mb-6">
              {grid.map((slot, idx) => (
                <div
                  key={idx}
                  onClick={() => handlePlaceModule(idx)}
                  className={`h-24 sm:h-28 rounded-2xl border-2 transition-all flex flex-col items-center justify-center p-2 cursor-pointer relative group ${
                    slot
                      ? 'bg-[#080B12] border-[#C65B43] shadow-[0_0_20px_rgba(198,91,67,0.3)] hover:border-[#F87171]'
                      : 'bg-white/5 border-dashed border-white/15 hover:border-[#C65B43] hover:bg-white/10'
                  }`}
                >
                  {slot ? (
                    <>
                      <span className="text-2xl sm:text-3xl mb-1">{slot.icon}</span>
                      <span className="font-mono text-[9px] text-[#F5F1E8] text-center leading-tight truncate w-full">
                        {slot.name}
                      </span>
                      <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity p-1 text-[#F87171]">
                        <Trash2 size={12} />
                      </div>
                    </>
                  ) : (
                    <>
                      <Plus size={18} className="text-[#9298A3] group-hover:text-white mb-1" />
                      <span className="font-mono text-[9px] text-[#9298A3]">PLOT {idx + 1}</span>
                    </>
                  )}
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center text-xs font-mono text-[#9298A3] pt-4 border-t border-white/5">
              <span>TIP: Click an empty plot to place. Click an occupied plot to dismantle & refund.</span>
              <button
                onClick={handleReset}
                className="text-[#C65B43] hover:text-white flex items-center space-x-1"
              >
                <RotateCcw size={12} />
                <span>CLEAR BASE</span>
              </button>
            </div>
          </div>

          {/* Right: Modules & Resource Balances (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col space-y-6">
            {/* Live Resource Balances Panel */}
            <div className="p-6 rounded-3xl bg-[#101827] border border-white/10 shadow-2xl">
              <div className="flex justify-between items-center mb-4">
                <span className="text-[10px] font-mono tracking-widest text-[#9298A3] uppercase">
                  LIFELINE RESOURCE BUDGET
                </span>
                <span
                  className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold ${
                    isSelfSustaining
                      ? 'bg-[#34D399]/20 text-[#34D399] border border-[#34D399]/40'
                      : 'bg-[#FBBF24]/20 text-[#FBBF24] border border-[#FBBF24]/40'
                  }`}
                >
                  {isSelfSustaining ? '100% SELF-SUSTAINING COLONY' : 'SUBSYSTEM DEFICIT'}
                </span>
              </div>

              <div className="space-y-3 font-mono text-xs mb-4">
                {/* Power */}
                <div className="flex justify-between items-center p-2.5 rounded-xl bg-[#080B12]">
                  <span className="flex items-center space-x-2 text-[#9298A3]">
                    <Zap size={14} className="text-[#FBBF24]" />
                    <span>POWER GRID:</span>
                  </span>
                  <span className={`font-bold ${powerBalance >= 0 ? 'text-[#34D399]' : 'text-[#F87171]'}`}>
                    {powerBalance >= 0 ? `+${powerBalance}` : powerBalance} kW
                  </span>
                </div>

                {/* Oxygen */}
                <div className="flex justify-between items-center p-2.5 rounded-xl bg-[#080B12]">
                  <span className="flex items-center space-x-2 text-[#9298A3]">
                    <Wind size={14} className="text-[#38BDF8]" />
                    <span>OXYGEN SYNTHESIS:</span>
                  </span>
                  <span className={`font-bold ${o2Balance >= 0 ? 'text-[#34D399]' : 'text-[#F87171]'}`}>
                    {o2Balance >= 0 ? `+${o2Balance}` : o2Balance} L/day
                  </span>
                </div>

                {/* Water */}
                <div className="flex justify-between items-center p-2.5 rounded-xl bg-[#080B12]">
                  <span className="flex items-center space-x-2 text-[#9298A3]">
                    <Droplets size={14} className="text-[#38BDF8]" />
                    <span>WATER RECLAMATION:</span>
                  </span>
                  <span className={`font-bold ${waterBalance >= 0 ? 'text-[#34D399]' : 'text-[#F87171]'}`}>
                    {waterBalance >= 0 ? `+${waterBalance}` : waterBalance} L/day
                  </span>
                </div>

                {/* Food */}
                <div className="flex justify-between items-center p-2.5 rounded-xl bg-[#080B12]">
                  <span className="flex items-center space-x-2 text-[#9298A3]">
                    <Utensils size={14} className="text-[#34D399]" />
                    <span>CALORIC CROPS:</span>
                  </span>
                  <span className={`font-bold ${foodBalance >= 0 ? 'text-[#34D399]' : 'text-[#F87171]'}`}>
                    {foodBalance >= 0 ? `+${foodBalance}` : foodBalance} kcal/day
                  </span>
                </div>

                {/* Crew */}
                <div className="flex justify-between items-center p-2.5 rounded-xl bg-[#080B12]">
                  <span className="flex items-center space-x-2 text-[#9298A3]">
                    <Users size={14} className="text-[#C65B43]" />
                    <span>ASTRONAUTS HOUSED:</span>
                  </span>
                  <span className="font-bold text-[#F5F1E8]">
                    {totalCrew} / 8 Target
                  </span>
                </div>
              </div>
            </div>

            {/* Available Module Selector */}
            <div className="p-6 rounded-3xl bg-[#101827] border border-white/10 shadow-2xl">
              <span className="text-[10px] font-mono tracking-widest text-[#C65B43] uppercase mb-3 block">
                SELECT MODULE TO CONSTRUCT
              </span>

              <div className="space-y-2">
                {MODULE_TYPES.map((mod) => (
                  <div
                    key={mod.type}
                    onClick={() => {
                      soundManager.playClick();
                      setSelectedModuleType(mod.type);
                    }}
                    className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                      selectedModuleType === mod.type
                        ? 'bg-[#C65B43]/20 border-[#C65B43] shadow-[0_0_15px_rgba(198,91,67,0.3)]'
                        : 'bg-white/5 border-white/5 hover:border-white/15'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-xl">{mod.icon}</span>
                      <div>
                        <div className="font-semibold text-xs text-[#F5F1E8]">{mod.name}</div>
                        <div className="text-[10px] text-[#9298A3]">{mod.desc}</div>
                      </div>
                    </div>
                    <div className="text-right font-mono text-xs">
                      <div className="font-bold text-[#FBBF24]">{mod.cost} M$</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
