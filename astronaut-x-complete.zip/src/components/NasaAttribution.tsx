import React from 'react';
import { ExternalLink, ShieldAlert, Camera, Building2, Calendar, FileText } from 'lucide-react';

interface NasaAttributionProps {
  nasaId?: string;
  nasaUrl?: string;
  photographer?: string;
  nasaCenter?: string;
  dateCreated?: string;
  compact?: boolean;
  showDisclaimer?: boolean;
  className?: string;
}

export const NASA_DISCLAIMER_TEXT =
  "ASTRONAUT-X is an independent educational project. It is not affiliated with, endorsed by, or operated by NASA. NASA media is credited to its respective sources.";

export default function NasaAttribution({
  nasaId,
  nasaUrl,
  photographer,
  nasaCenter = 'NASA',
  dateCreated,
  compact = false,
  showDisclaimer = true,
  className = ''
}: NasaAttributionProps) {
  const formattedDate = dateCreated
    ? new Date(dateCreated).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })
    : null;

  const targetUrl = nasaUrl || (nasaId ? `https://images.nasa.gov/details/${encodeURIComponent(nasaId)}` : 'https://images.nasa.gov');

  if (compact) {
    return (
      <div className={`flex items-center justify-between text-[11px] text-[#9298A3] border-t border-white/5 pt-2 ${className}`}>
        <div className="flex items-center space-x-2 truncate">
          <span className="font-mono text-[10px] uppercase tracking-wider text-[#38BDF8]">
            Source: NASA {nasaCenter ? `(${nasaCenter})` : ''}
          </span>
          {photographer && (
            <span className="truncate text-white/70 max-w-[140px]" title={photographer}>
              • {photographer}
            </span>
          )}
        </div>
        <a
          href={targetUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center space-x-1 text-[#C65B43] hover:text-[#FF7B59] transition-colors ml-2 font-mono text-[10px] shrink-0"
          title="Open original record in NASA Image and Video Library"
        >
          <span>View original media</span>
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>
    );
  }

  return (
    <div className={`p-4 rounded-xl bg-white/[0.03] border border-white/10 text-xs text-[#9298A3] space-y-3 ${className}`}>
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2.5">
        <div className="flex items-center space-x-2">
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold tracking-wider uppercase bg-[#38BDF8]/15 text-[#38BDF8] border border-[#38BDF8]/30">
            Official Source: NASA
          </span>
          {nasaCenter && (
            <span className="flex items-center space-x-1 text-white/80 font-mono text-[11px]">
              <Building2 className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span>Center: {nasaCenter}</span>
            </span>
          )}
        </div>

        <a
          href={targetUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center space-x-1 px-2.5 py-1 rounded bg-[#C65B43]/15 text-[#FF7B59] hover:bg-[#C65B43]/30 transition-all font-mono text-[11px] border border-[#C65B43]/30"
        >
          <span>View original media</span>
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
        {nasaId && (
          <div className="flex items-center space-x-1.5 font-mono">
            <FileText className="w-3.5 h-3.5 text-[#9298A3]" />
            <span className="text-white/60">NASA ID:</span>
            <span className="text-white font-medium truncate">{nasaId}</span>
          </div>
        )}
        {photographer && (
          <div className="flex items-center space-x-1.5 font-mono">
            <Camera className="w-3.5 h-3.5 text-[#9298A3]" />
            <span className="text-white/60">Credit:</span>
            <span className="text-white font-medium truncate" title={photographer}>
              {photographer}
            </span>
          </div>
        )}
        {formattedDate && (
          <div className="flex items-center space-x-1.5 font-mono">
            <Calendar className="w-3.5 h-3.5 text-[#9298A3]" />
            <span className="text-white/60">Recorded:</span>
            <span className="text-white font-medium">{formattedDate}</span>
          </div>
        )}
      </div>

      {showDisclaimer && (
        <div className="flex items-start space-x-2 pt-2 border-t border-white/5 text-[11px] text-white/50 leading-relaxed font-sans">
          <ShieldAlert className="w-4 h-4 text-[#FBBF24] shrink-0 mt-0.5" />
          <p>{NASA_DISCLAIMER_TEXT}</p>
        </div>
      )}
    </div>
  );
}
