import React, { useState } from 'react';
import { Shield, BatteryCharging, Droplets, Wind, Heart, Activity, AlertOctagon, RefreshCw, Play, UserCheck, Flame } from 'lucide-react';
import { soundManager } from '../utils/audio';

export default function MissionDashboardPreview({ onOpenSimulator }) {
  // Simulated telemetry state
  const [telemetry, setTelemetry] = useState({
    oxygen: 94.2,
    water: 89.6,
    power: 92.4,
    health: 96.0,
    sol: 142,
    habIntegrity: 98.8,
    heartRate: 68,
    activeAlert: null,
  });

  const [activeSimulation, setActiveSimulation] = useState('nominal');

  // Interactive anomaly scenarios
  const handleSimulateDustStorm = () => {
    soundManager.playWarning();
    setActiveSimulation('dust_storm');
    setTelemetry({
      oxygen: 91.0,
      water: 87.2,
      power: 64.5, // Solar arrays covered by dust!
      health: 92.0,
      sol: 142,
      habIntegrity: 94.1,
      heartRate: 84,
      activeAlert: 'WARNING: DUST STORM INCOMING. PHOTOVOLTAIC DEGRADATION (-35%). KILOPOWER BACKUP ENGAGED.',
    });
  };

  const handleSimulateOxygenOverload = () => {
    soundManager.playWarning();
    setActiveSimulation('moxie_overload');
    setTelemetry({
      oxygen: 82.4, // Compressor throttling
      water: 89.0,
      power: 88.0,
      health: 89.0,
      sol: 142,
      habIntegrity: 97.5,
      heartRate: 92,
      activeAlert: 'CAUTION: MOXIE CATHODE COMPRESSOR HEAT SURGE. CLOSED-LOOP BACKUP RESERVES COMMITTED.',
    });
  };

  const handleResetNominal = () => {
    soundManager.playSuccess();
    setActiveSimulation('nominal');
    setTelemetry({
      oxygen: 94.2,
      water: 89.6,
      power: 92.4,
      health: 96.0,
      sol: 142,
      habIntegrity: 98.8,
      heartRate: 68,
      activeAlert: null,
    });
  };

  return (
    <section id="mission-dashboard" className="py-28 md:py-36 bg-[#080B12] border-t border-white/5 relative overflow-hidden">
      {/* Background glow elements */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[500px] bg-[#101827] blur-[140px] pointer-events-none opacity-50" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#C65B43] uppercase mb-4">
              <span>04 / SECTION</span>
              <span className="w-8 h-[1px] bg-[#C65B43]/50" />
              <span>TELEMETRY & FLIGHT DECK</span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-[#F5F1E8] uppercase">
              THE MISSION EXPERIENCE
            </h2>
          </div>
          <p className="max-w-md text-sm text-[#9298A3] font-light leading-relaxed">
            Live simulation preview of the Mars Habitation Alpha flight deck. Test real-time anomalies and observe autonomous life-support triage.
          </p>
        </div>

        {/* Interactive Scenario Injector Toolbar */}
        <div className="mb-6 p-4 rounded-2xl bg-[#101827]/70 border border-white/10 backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-2 text-xs font-mono text-[#9298A3]">
            <span className="w-2 h-2 rounded-full bg-[#C65B43] animate-pulse" />
            <span>TEST SIMULATED CRISIS ANOMALIES:</span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleSimulateDustStorm}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center space-x-1.5 ${
                activeSimulation === 'dust_storm'
                  ? 'bg-[#FBBF24]/20 border border-[#FBBF24] text-[#FBBF24]'
                  : 'bg-white/5 hover:bg-white/10 text-[#9298A3] border border-white/5'
              }`}
            >
              <Wind size={13} />
              <span>DUST STORM (SOLAR DROP)</span>
            </button>

            <button
              onClick={handleSimulateOxygenOverload}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center space-x-1.5 ${
                activeSimulation === 'moxie_overload'
                  ? 'bg-[#F87171]/20 border border-[#F87171] text-[#F87171]'
                  : 'bg-white/5 hover:bg-white/10 text-[#9298A3] border border-white/5'
              }`}
            >
              <AlertOctagon size={13} />
              <span>MOXIE O₂ COMPRESSOR GLITCH</span>
            </button>

            <button
              onClick={handleResetNominal}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center space-x-1.5 ${
                activeSimulation === 'nominal'
                  ? 'bg-[#34D399]/20 border border-[#34D399] text-[#34D399]'
                  : 'bg-white/5 hover:bg-white/10 text-[#9298A3] border border-white/5'
              }`}
            >
              <RefreshCw size={13} />
              <span>RESTORE ALL NOMINAL</span>
            </button>
          </div>
        </div>

        {/* Active Alert Banner */}
        {telemetry.activeAlert && (
          <div className="mb-6 p-4 rounded-xl bg-[#F87171]/10 border border-[#F87171]/40 flex items-center space-x-3 text-xs font-mono text-[#F87171] animate-in fade-in duration-300">
            <AlertOctagon size={18} className="shrink-0 animate-bounce" />
            <span className="font-semibold">{telemetry.activeAlert}</span>
          </div>
        )}

        {/* Main Telemetry Dashboard Grid */}
        <div className="p-8 md:p-10 rounded-3xl bg-[#101827] border border-white/10 shadow-2xl relative">
          {/* Subtle Corner HUD Marks */}
          <div className="hud-corner absolute inset-0 pointer-events-none rounded-3xl" />

          {/* Top Bar: Astronaut Profile & Mission Progress */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pb-8 border-b border-white/10 items-center">
            {/* Astronaut Profile Badge */}
            <div className="flex items-center space-x-4">
              <div className="relative w-14 h-14 rounded-2xl bg-[#080B12] border border-[#C65B43]/50 flex items-center justify-center">
                <UserCheck size={28} className="text-[#C65B43]" />
                <span className="absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full bg-[#34D399] border-2 border-[#101827]" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-semibold text-sm text-[#F5F1E8]">CADET ARIA VANCE</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#C65B43]/20 text-[#C65B43] border border-[#C65B43]/30">
                    CDR
                  </span>
                </div>
                <div className="text-xs font-mono text-[#9298A3]">
                  SPECIALIZATION: ECLSS & SYSTEMS
                </div>
                <div className="text-[10px] font-mono text-[#34D399]">
                  FLIGHT STATUS: CLEARED FOR EVA
                </div>
              </div>
            </div>

            {/* Mission Progress Indicator */}
            <div className="flex flex-col">
              <div className="flex justify-between text-xs font-mono mb-2">
                <span className="text-[#9298A3]">MISSION DURATION</span>
                <span className="text-[#F5F1E8] font-bold">SOL {telemetry.sol} OF 500</span>
              </div>
              <div className="w-full bg-[#080B12] h-2.5 rounded-full overflow-hidden p-0.5 border border-white/10">
                <div
                  className="bg-gradient-to-r from-[#C65B43] to-[#E07A5F] h-full rounded-full transition-all duration-500"
                  style={{ width: `${(telemetry.sol / 500) * 100}%` }}
                />
              </div>
              <div className="flex justify-between text-[10px] font-mono text-[#9298A3]/70 mt-1">
                <span>HAB ALPHA INSERTION</span>
                <span>RETURN TRANSIT: 28.4%</span>
              </div>
            </div>

            {/* Hab Integrity & Latency */}
            <div className="flex items-center justify-end space-x-6 text-right">
              <div>
                <div className="text-[10px] font-mono text-[#9298A3]">HAB INTEGRITY</div>
                <div className="font-mono text-xl font-bold text-[#F5F1E8]">
                  {telemetry.habIntegrity}%
                </div>
              </div>
              <div className="h-8 w-[1px] bg-white/10" />
              <div>
                <div className="text-[10px] font-mono text-[#9298A3]">RADIO LATENCY</div>
                <div className="font-mono text-xl font-bold text-[#38BDF8]">
                  14m 22s
                </div>
              </div>
            </div>
          </div>

          {/* 4 Core Telemetry Gauges */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 py-8">
            {/* 1. Oxygen Supply */}
            <div className="p-6 rounded-2xl bg-[#080B12]/80 border border-white/5 relative overflow-hidden group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono text-[#9298A3] uppercase">OXYGEN SUPPLY</span>
                <Wind size={18} className="text-[#38BDF8]" />
              </div>
              <div className="font-mono text-4xl font-bold text-[#F5F1E8] mb-3">
                {telemetry.oxygen}%
              </div>
              <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden mb-3">
                <div
                  className="bg-[#38BDF8] h-full rounded-full transition-all duration-500"
                  style={{ width: `${telemetry.oxygen}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono text-[#9298A3]">
                <span>MOXIE: 12.0 g/h</span>
                <span className="text-[#34D399]">+0.8 kg/sol</span>
              </div>
            </div>

            {/* 2. Water Resources */}
            <div className="p-6 rounded-2xl bg-[#080B12]/80 border border-white/5 relative overflow-hidden group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono text-[#9298A3] uppercase">WATER RESOURCES</span>
                <Droplets size={18} className="text-[#38BDF8]" />
              </div>
              <div className="font-mono text-4xl font-bold text-[#F5F1E8] mb-3">
                {telemetry.water}%
              </div>
              <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden mb-3">
                <div
                  className="bg-[#38BDF8] h-full rounded-full transition-all duration-500"
                  style={{ width: `${telemetry.water}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono text-[#9298A3]">
                <span>SABATIER RECYCLE</span>
                <span className="text-[#34D399]">98.4% EFF</span>
              </div>
            </div>

            {/* 3. Crew Health & Vitals */}
            <div className="p-6 rounded-2xl bg-[#080B12]/80 border border-white/5 relative overflow-hidden group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono text-[#9298A3] uppercase">CREW HEALTH</span>
                <Heart size={18} className="text-[#F87171]" />
              </div>
              <div className="font-mono text-4xl font-bold text-[#F5F1E8] mb-3">
                {telemetry.health}%
              </div>
              <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden mb-3">
                <div
                  className="bg-[#34D399] h-full rounded-full transition-all duration-500"
                  style={{ width: `${telemetry.health}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono text-[#9298A3]">
                <span>PULSE: {telemetry.heartRate} BPM</span>
                <span className="text-[#34D399]">DOSAGE: 42 mSv</span>
              </div>
            </div>

            {/* 4. Power Levels */}
            <div className="p-6 rounded-2xl bg-[#080B12]/80 border border-white/5 relative overflow-hidden group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono text-[#9298A3] uppercase">POWER LEVELS</span>
                <BatteryCharging size={18} className="text-[#FBBF24]" />
              </div>
              <div className="font-mono text-4xl font-bold text-[#F5F1E8] mb-3">
                {telemetry.power}%
              </div>
              <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden mb-3">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    telemetry.power < 70 ? 'bg-[#FBBF24]' : 'bg-[#34D399]'
                  }`}
                  style={{ width: `${telemetry.power}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono text-[#9298A3]">
                <span>KILOPOWER + SOLAR</span>
                <span className="text-[#F5F1E8]">8.4 kW LOAD</span>
              </div>
            </div>
          </div>

          {/* Bottom Launch Flight Simulator CTA */}
          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="flex items-center space-x-3 text-xs font-mono text-[#9298A3]">
              <Activity size={16} className="text-[#C65B43]" />
              <span>READY TO TAKE COMMAND OF THE JEZERO MISSION?</span>
            </div>

            <button
              onClick={() => {
                soundManager.playLaunch();
                onOpenSimulator();
              }}
              className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-[#C65B43] hover:bg-[#b54f38] text-white font-mono text-xs font-semibold tracking-wider transition-all duration-300 shadow-[0_0_25px_rgba(198,91,67,0.4)] hover:shadow-[0_0_40px_rgba(198,91,67,0.65)] flex items-center justify-center space-x-2 active:scale-95"
            >
              <Play size={14} className="fill-current" />
              <span>ENTER FULL MISSION FLIGHT DECK</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
