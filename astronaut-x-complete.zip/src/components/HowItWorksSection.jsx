import React, { useState } from 'react';
import { UserCheck, BookOpen, Trophy, ArrowRight, CheckCircle, Shield, Sparkles } from 'lucide-react';
import { soundManager } from '../utils/audio';

const STEPS = [
  {
    step: '01',
    title: 'PREPARE',
    tagline: 'Create your astronaut profile.',
    desc: 'Input your callsign, select your expeditionary specialty (Life Support Engineering, Geological Science, or Flight Systems), and receive your personalized telemetry biometric credentials.',
    badge: 'STAGE 1: FLIGHT CANDIDACY',
    details: [
      'Biometric baseline telemetry calibration',
      'Role assignment & specialized emergency triage clearance',
      'Cognitive stamina & radiation hazard induction',
    ],
  },
  {
    step: '02',
    title: 'TRAIN',
    tagline: 'Learn essential survival techniques.',
    desc: 'Master closed-loop life support balancing, calibrate the MOXIE solid-oxide electrolysis reactors, practice pressurized rover navigation through rocky crater terrain, and learn emergency dust storm lockdown protocols.',
    badge: 'STAGE 2: HAB SIMULATION',
    details: [
      'CO₂ scrubbers & Sabatier water recovery loops',
      'Pressurized EVA suit thermal regulations',
      'Autonomous communication blackout contingencies',
    ],
  },
  {
    step: '03',
    title: 'SURVIVE',
    tagline: 'Complete your Mars mission.',
    desc: 'Face real-time simulated Martian crises: dust storms obscuring solar arrays, unexpected ECLSS valve anomalies, and ice core extraction EVA emergencies. Your decisions dictate crew survival until the Earth transit burn window.',
    badge: 'STAGE 3: EXPEDITION MASTERY',
    details: [
      'Real-time crisis decision engine with immediate life-support impact',
      'Autonomous crew leadership under 14-minute signal latency',
      'Official NASA Space Apps Junior Astronaut Certification',
    ],
  },
];

export default function HowItWorksSection({ onStartMission }) {
  const [activeStep, setActiveStep] = useState(0);

  const handleSelectStep = (idx) => {
    soundManager.playClick();
    setActiveStep(idx);
  };

  return (
    <section className="py-28 md:py-36 bg-transparent border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#C65B43] uppercase mb-4">
              <span>05 / SECTION</span>
              <span className="w-8 h-[1px] bg-[#C65B43]/50" />
              <span>TRAINING SYLLABUS</span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white uppercase">
              HOW IT WORKS
            </h2>
          </div>
          <p className="max-w-md text-sm text-[#94A3B8] font-light leading-relaxed">
            The mission simulator transforms complex NASA planetary science and aerospace engineering into an intuitive, high-stakes interactive experience.
          </p>
        </div>

        {/* 3 Step Progression Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {STEPS.map((item, idx) => {
            const isActive = activeStep === idx;
            return (
              <div
                key={item.step}
                onClick={() => handleSelectStep(idx)}
                className={`p-8 rounded-3xl border transition-all duration-300 cursor-pointer relative overflow-hidden flex flex-col justify-between group ${
                  isActive
                    ? 'glass-panel-card border-[#C65B43] shadow-[0_0_35px_rgba(198,91,67,0.3)] scale-[1.02]'
                    : 'glass-panel-card hover:border-white/25'
                }`}
              >
                {/* Step indicator */}
                <div>
                  <div className="flex items-center justify-between mb-8">
                    <span className="font-mono text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#C65B43] to-[#E07A5F]">
                      {item.step}
                    </span>
                    <span className="text-[10px] font-mono tracking-wider px-3 py-1 rounded-full bg-white/5 text-[#9298A3] border border-white/5">
                      {item.badge}
                    </span>
                  </div>

                  <h3 className="font-display text-3xl font-bold tracking-tight text-[#F5F1E8] mb-2">
                    {item.title}
                  </h3>
                  <p className="text-sm font-medium text-[#C65B43] mb-4">
                    {item.tagline}
                  </p>
                  <p className="text-xs text-[#9298A3] leading-relaxed mb-6 font-light">
                    {item.desc}
                  </p>
                </div>

                {/* Sub details list */}
                <div className="border-t border-white/5 pt-6 mt-4 space-y-2.5">
                  {item.details.map((detail, dIdx) => (
                    <div key={dIdx} className="flex items-center space-x-2 text-xs text-[#F5F1E8]/70">
                      <CheckCircle size={14} className="text-[#34D399] shrink-0" />
                      <span>{detail}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Callout Bar */}
        <div className="p-8 rounded-3xl bg-gradient-to-r from-[#101827] via-[#101827] to-[#1c1214] border border-white/10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="p-3.5 rounded-2xl bg-[#C65B43]/20 border border-[#C65B43]/40 text-[#C65B43]">
              <Sparkles size={24} />
            </div>
            <div>
              <h4 className="font-semibold text-base text-[#F5F1E8]">
                EARN YOUR OFFICIAL FLIGHT WINGS
              </h4>
              <p className="text-xs text-[#9298A3]">
                Successful completion of all three simulation phases awards a personalized NASA Space Apps 2026 Junior Astronaut Certificate.
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundManager.playLaunch();
              onStartMission();
            }}
            className="px-6 py-3.5 rounded-full bg-[#C65B43] hover:bg-[#b54f38] text-white font-mono text-xs font-semibold tracking-wider transition-all duration-300 shadow-[0_0_20px_rgba(198,91,67,0.35)] shrink-0 flex items-center space-x-2 active:scale-95"
          >
            <span>START STEP 01 NOW</span>
            <ArrowRight size={14} />
          </button>
        </div>
      </div>
    </section>
  );
}
