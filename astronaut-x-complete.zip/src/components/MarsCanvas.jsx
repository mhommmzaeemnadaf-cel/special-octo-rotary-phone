import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Layers, Eye, Maximize2, Radio, Compass, Orbit } from 'lucide-react';
import { soundManager } from '../utils/audio';

// --- PROCEDURAL TEXTURE GENERATOR FOR HIGH-DEFINITION MARS (NATURAL ALBEDO) ---
function createNaturalMarsTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 2048;
  canvas.height = 1024;
  const ctx = canvas.getContext('2d');

  // Multi-tier latitudinal base gradient
  const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  bgGrad.addColorStop(0.0, '#42160F');   // Deep North Polar Trough
  bgGrad.addColorStop(0.12, '#7C2F20');  // Vastitas Borealis lowlands
  bgGrad.addColorStop(0.35, '#B85038');  // Acidalia Planitia & Chryse
  bgGrad.addColorStop(0.50, '#C65B43');  // Arabia Terra & Equatorial Red Dunes
  bgGrad.addColorStop(0.65, '#9E3E2A');  // Sinus Sabaeus & Southern Highlands
  bgGrad.addColorStop(0.85, '#682417');  // Hellas Basin & Argyre Planitia
  bgGrad.addColorStop(1.0, '#3D120B');   // South Polar Cap Periphery
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Basalt dark albedo features (Syrtis Major, Tyrrhenum, Acidalia)
  const basaltPatches = [
    { x: 1400, y: 520, rx: 160, ry: 100, rot: 0.3, alpha: 0.75 }, // Syrtis Major Planum
    { x: 750, y: 420, rx: 220, ry: 90, rot: -0.2, alpha: 0.65 },  // Acidalia Planitia
    { x: 1100, y: 640, rx: 280, ry: 80, rot: 0.1, alpha: 0.60 },  // Mare Tyrrhenum
    { x: 300, y: 620, rx: 180, ry: 90, rot: -0.15, alpha: 0.55 }, // Sirenum
  ];

  basaltPatches.forEach((p) => {
    const grad = ctx.createRadialGradient(p.x, p.y, 10, p.x, p.y, p.rx);
    grad.addColorStop(0, `rgba(42, 17, 13, ${p.alpha})`);
    grad.addColorStop(0.5, `rgba(65, 26, 19, ${p.alpha * 0.7})`);
    grad.addColorStop(1, 'rgba(198, 91, 67, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(p.x, p.y, p.rx, p.ry, p.rot, 0, Math.PI * 2);
    ctx.fill();
  });

  // Valles Marineris Canyon Rift (Equatorial chasm system: 4,000 km long)
  ctx.strokeStyle = 'rgba(28, 10, 8, 0.92)';
  ctx.lineWidth = 14;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(680, 530);
  ctx.bezierCurveTo(800, 560, 960, 520, 1140, 570);
  ctx.stroke();

  // Subsidiary Candor & Melas Chasma canyons
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(820, 545);
  ctx.lineTo(900, 590);
  ctx.moveTo(960, 530);
  ctx.lineTo(1020, 495);
  ctx.stroke();

  // Olympus Mons Caldera & Base Scarp (x=410, y=430)
  const calderaGrad = ctx.createRadialGradient(410, 430, 6, 410, 430, 85);
  calderaGrad.addColorStop(0, 'rgba(32, 12, 9, 0.95)');
  calderaGrad.addColorStop(0.25, 'rgba(95, 36, 25, 0.85)');
  calderaGrad.addColorStop(0.65, 'rgba(198, 91, 67, 0.6)');
  calderaGrad.addColorStop(0.9, 'rgba(235, 155, 130, 0.4)');
  calderaGrad.addColorStop(1, 'rgba(198, 91, 67, 0)');
  ctx.fillStyle = calderaGrad;
  ctx.beginPath();
  ctx.arc(410, 430, 85, 0, Math.PI * 2);
  ctx.fill();

  // Impact craters with realistic illuminated rims and shadow depths
  for (let c = 0; c < 350; c++) {
    const cx = Math.random() * canvas.width;
    const cy = 100 + Math.random() * (canvas.height - 200);
    const cr = 3 + Math.random() * 24;

    // Floor shadow
    ctx.fillStyle = 'rgba(30, 10, 8, 0.7)';
    ctx.beginPath();
    ctx.arc(cx, cy, cr, 0, Math.PI * 2);
    ctx.fill();

    // Sunlight rim highlight
    ctx.strokeStyle = 'rgba(245, 185, 165, 0.35)';
    ctx.lineWidth = Math.max(1, cr * 0.16);
    ctx.beginPath();
    ctx.arc(cx - cr * 0.12, cy - cr * 0.12, cr * 0.95, 0, Math.PI * 2);
    ctx.stroke();
  }

  // North Polar Ice Cap (Layered CO₂ & Water Ice)
  const northCap = ctx.createRadialGradient(canvas.width / 2, 0, 15, canvas.width / 2, 0, 140);
  northCap.addColorStop(0, 'rgba(255, 255, 255, 0.98)');
  northCap.addColorStop(0.55, 'rgba(240, 248, 255, 0.88)');
  northCap.addColorStop(0.85, 'rgba(185, 215, 240, 0.3)');
  northCap.addColorStop(1, 'rgba(185, 215, 240, 0)');
  ctx.fillStyle = northCap;
  ctx.beginPath();
  ctx.rect(0, 0, canvas.width, 145);
  ctx.fill();

  // South Polar Ice Cap
  const southCap = ctx.createRadialGradient(canvas.width / 2, canvas.height, 10, canvas.width / 2, canvas.height, 110);
  southCap.addColorStop(0, 'rgba(255, 255, 255, 0.98)');
  southCap.addColorStop(0.65, 'rgba(225, 240, 255, 0.78)');
  southCap.addColorStop(1, 'rgba(225, 240, 255, 0)');
  ctx.fillStyle = southCap;
  ctx.beginPath();
  ctx.rect(0, canvas.height - 110, canvas.width, 110);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  return texture;
}

// --- MOLA TOPOGRAPHIC ELEVATION MAP (SCIENTIFIC FALSE-COLOR) ---
function createMolaElevationTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');

  // MOLA Rainbow Spectrum (Deep Purple - Blue = -8km, Green = 0km Datum, Yellow = +4km, White = +21km)
  const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  grad.addColorStop(0.0, '#38BDF8');   // North Polar Basin
  grad.addColorStop(0.2, '#1E40AF');   // Lowlands (-4 km)
  grad.addColorStop(0.45, '#059669');  // Chryse / Acidalia Lowland (-2 km)
  grad.addColorStop(0.55, '#F59E0B');  // Southern Cratered Highlands (+2 km)
  grad.addColorStop(0.75, '#DC2626');  // Tharsis Volcanic Rise (+8 km)
  grad.addColorStop(0.95, '#FFFFFF');  // South Pole & Peak
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Olympus Mons elevation bullseye (+21.9 km peak)
  const olympus = ctx.createRadialGradient(205, 215, 4, 205, 215, 60);
  olympus.addColorStop(0, '#FFFFFF');
  olympus.addColorStop(0.4, '#FCA5A5');
  olympus.addColorStop(0.7, '#DC2626');
  olympus.addColorStop(1, 'rgba(220, 38, 38, 0)');
  ctx.fillStyle = olympus;
  ctx.beginPath();
  ctx.arc(205, 215, 60, 0, Math.PI * 2);
  ctx.fill();

  // Hellas Planitia (-8.2 km deep basin)
  const hellas = ctx.createRadialGradient(720, 380, 5, 720, 380, 80);
  hellas.addColorStop(0, '#1E1B4B');
  hellas.addColorStop(0.6, '#1E40AF');
  hellas.addColorStop(1, 'rgba(30, 64, 175, 0)');
  ctx.fillStyle = hellas;
  ctx.beginPath();
  ctx.arc(720, 380, 80, 0, Math.PI * 2);
  ctx.fill();

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

// --- THEMIS THERMAL INFRARED NIGHT-SIDE MAP ---
function createThermalTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#05070E';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // High thermal inertia bedrock glow (blue to hot amber)
  for (let i = 0; i < 40; i++) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    const r = 30 + Math.random() * 120;
    const grad = ctx.createRadialGradient(x, y, 2, x, y, r);
    grad.addColorStop(0, 'rgba(245, 158, 11, 0.45)');
    grad.addColorStop(0.5, 'rgba(124, 58, 237, 0.25)');
    grad.addColorStop(1, 'rgba(5, 7, 14, 0)');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

// --- TRANSLUCENT MARTIAN DUST & ICE CIRRUS CLOUDS ---
function createCloudsTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Delicate white-cyan water ice cirrus bands
  ctx.fillStyle = 'rgba(225, 240, 255, 0.18)';
  for (let i = 0; i < 28; i++) {
    const x = Math.random() * canvas.width;
    const y = 80 + Math.random() * (canvas.height - 160);
    const rw = 90 + Math.random() * 200;
    const rh = 15 + Math.random() * 40;
    ctx.beginPath();
    ctx.ellipse(x, y, rw, rh, (Math.random() - 0.5) * 0.4, 0, Math.PI * 2);
    ctx.fill();
  }

  // Thin equatorial dust haze streaks
  ctx.fillStyle = 'rgba(235, 140, 105, 0.12)';
  for (let j = 0; j < 18; j++) {
    const x = Math.random() * canvas.width;
    const y = 200 + Math.random() * 140;
    ctx.beginPath();
    ctx.ellipse(x, y, 140, 25, 0.1, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

// Bump map generator for realistic crustal roughness
function createMarsBumpMap() {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (let i = 0; i < 450; i++) {
    const x = Math.random() * canvas.width;
    const y = Math.random() * canvas.height;
    const r = 2 + Math.random() * 20;
    const grad = ctx.createRadialGradient(x, y, 1, x, y, r);
    grad.addColorStop(0, '#1a1a1a');
    grad.addColorStop(0.8, '#d4d4d4');
    grad.addColorStop(1, '#808080');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  return texture;
}

// Telemetry Landmarks on Mars
const LANDMARKS = [
  {
    id: 'jezero',
    name: 'Jezero Crater (Hab Alpha)',
    coords: '18.38° N, 77.58° E',
    elev: '-2,500 m',
    targetRotY: 1.25,
    targetRotX: 0.12,
    phi: (90 - 18.38) * (Math.PI / 180),
    theta: (77.58 + 180) * (Math.PI / 180),
    desc: 'Primary expeditionary base & Perseverance rover landing sector. Ancient river delta sediments holding biosignatures.',
  },
  {
    id: 'olympus',
    name: 'Olympus Mons',
    coords: '18.65° N, 226.2° E',
    elev: '+21,287 m',
    targetRotY: 3.85,
    targetRotX: 0.14,
    phi: (90 - 18.65) * (Math.PI / 180),
    theta: (226.2 + 180) * (Math.PI / 180),
    desc: 'The largest volcanic shield in the Solar System. 2.5× Mount Everest; caldera spans 80 km across.',
  },
  {
    id: 'valles',
    name: 'Valles Marineris',
    coords: '14.0° S, 290.0° E',
    elev: '-8,000 m',
    targetRotY: 4.85,
    targetRotX: -0.10,
    phi: (90 - (-14)) * (Math.PI / 180),
    theta: (290 + 180) * (Math.PI / 180),
    desc: 'Grand canyon system extending 4,000 km across the Martian equator. Deep chasms 7 km below datum.',
  },
  {
    id: 'gale',
    name: 'Gale Crater (Curiosity)',
    coords: '5.4° S, 137.8° E',
    elev: '-4,500 m',
    targetRotY: 2.20,
    targetRotX: -0.05,
    phi: (90 - (-5.4)) * (Math.PI / 180),
    theta: (137.8 + 180) * (Math.PI / 180),
    desc: 'Ancient lake basin explored by Curiosity; central mound Mount Sharp rises 5.5 km from crater floor.',
  },
];

export default function MarsCanvas({ activeLandmarkId, onSelectLandmark, interactive = true }) {
  const mountRef = useRef(null);
  const [selectedLandmark, setSelectedLandmark] = useState(null);
  const [renderMode, setRenderMode] = useState('natural'); // natural, elevation, thermal
  const [targetCamZ, setTargetCamZ] = useState(5.2);

  // References to switch textures dynamically without recreating scene
  const texturesRef = useRef({});
  const marsMaterialRef = useRef(null);
  const rotTargetRef = useRef({ y: 0.4, x: 0.08 });

  // Handle Mode Switch
  const handleSwitchMode = (mode) => {
    soundManager.playClick();
    setRenderMode(mode);
    if (!marsMaterialRef.current) return;

    if (mode === 'natural') {
      marsMaterialRef.current.map = texturesRef.current.natural;
      marsMaterialRef.current.roughness = 0.88;
    } else if (mode === 'elevation') {
      marsMaterialRef.current.map = texturesRef.current.elevation;
      marsMaterialRef.current.roughness = 0.55;
    } else if (mode === 'thermal') {
      marsMaterialRef.current.map = texturesRef.current.thermal;
      marsMaterialRef.current.roughness = 0.70;
    }
    marsMaterialRef.current.needsUpdate = true;
  };

  // Fly to Landmark
  const handleSelectLandmark = (lm) => {
    soundManager.playQuindar(true);
    setSelectedLandmark(lm);
    rotTargetRef.current.y = lm.targetRotY;
    rotTargetRef.current.x = lm.targetRotX;
    setTargetCamZ(4.5); // Cinematic orbital close-up
    if (onSelectLandmark) onSelectLandmark(lm);
  };

  const handleResetView = () => {
    soundManager.playClick();
    setSelectedLandmark(null);
    setTargetCamZ(5.2);
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    // Scene, Camera, High-Precision WebGL Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 1000);
    camera.position.set(0, 0, 5.2);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;
    container.appendChild(renderer.domElement);

    // --- STARFIELD WITH REAL STELLAR SPECTRAL COLORS ---
    const starsCount = 1500;
    const starsGeo = new THREE.BufferGeometry();
    const starPos = new Float32Array(starsCount * 3);
    const starColors = new Float32Array(starsCount * 3);

    const colorPalette = [
      new THREE.Color(0xF5F1E8), // Warm white
      new THREE.Color(0x93C5FD), // Hot O/B-type blue
      new THREE.Color(0xFDE047), // G-type yellow (solar)
      new THREE.Color(0xFCA5A5), // M-type red giant
    ];

    for (let i = 0; i < starsCount; i++) {
      const radius = 28 + Math.random() * 55;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      starPos[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      starPos[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      starPos[i * 3 + 2] = radius * Math.cos(phi);

      const col = colorPalette[Math.floor(Math.random() * colorPalette.length)];
      starColors[i * 3] = col.r;
      starColors[i * 3 + 1] = col.g;
      starColors[i * 3 + 2] = col.b;
    }

    starsGeo.setAttribute('position', new THREE.BufferAttribute(starPos, 3));
    starsGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));

    const starMat = new THREE.PointsMaterial({
      size: 0.08,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
    });
    const starField = new THREE.Points(starsGeo, starMat);
    scene.add(starField);

    // --- MARS PLANET SETUP ---
    const planetRadius = 1.75;
    const marsGeometry = new THREE.SphereGeometry(planetRadius, 64, 64);

    texturesRef.current.natural = createNaturalMarsTexture();
    texturesRef.current.elevation = createMolaElevationTexture();
    texturesRef.current.thermal = createThermalTexture();
    const bumpMap = createMarsBumpMap();

    const marsMaterial = new THREE.MeshStandardMaterial({
      map: texturesRef.current.natural,
      bumpMap: bumpMap,
      bumpScale: 0.04,
      roughness: 0.88,
      metalness: 0.06,
    });
    marsMaterialRef.current = marsMaterial;

    const marsMesh = new THREE.Mesh(marsGeometry, marsMaterial);
    marsMesh.rotation.z = (25.19 * Math.PI) / 180; // Authentic Mars axial tilt (25.19°)
    scene.add(marsMesh);

    // --- TRANSLUCENT CIRRUS & DUST CLOUDS LAYER ---
    const cloudsGeo = new THREE.SphereGeometry(planetRadius * 1.012, 64, 64);
    const cloudsTexture = createCloudsTexture();
    const cloudsMat = new THREE.MeshBasicMaterial({
      map: cloudsTexture,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
      side: THREE.FrontSide,
    });
    const cloudsMesh = new THREE.Mesh(cloudsGeo, cloudsMat);
    marsMesh.add(cloudsMesh);

    // --- RAYLEIGH SCATTERING ATMOSPHERIC OUTER GLOW SHADER ---
    const atmosphereGeometry = new THREE.SphereGeometry(planetRadius * 1.06, 64, 64);
    const atmosphereMaterial = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec3 vNormal;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vNormal;
        void main() {
          float intensity = pow(0.66 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 2.8);
          gl_FragColor = vec4(0.88, 0.40, 0.26, 1.0) * intensity * 1.5;
        }
      `,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true,
    });
    const atmosphereMesh = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
    scene.add(atmosphereMesh);

    // --- ORBITING RECONNAISSANCE SATELLITE (MRO) ---
    const satOrbitGroup = new THREE.Group();
    satOrbitGroup.rotation.x = 0.55;
    scene.add(satOrbitGroup);

    // Satellite Trajectory Ring
    const orbitRingGeo = new THREE.RingGeometry(2.38, 2.40, 64);
    const orbitRingMat = new THREE.MeshBasicMaterial({
      color: 0x38BDF8,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.22,
    });
    const orbitRing = new THREE.Mesh(orbitRingGeo, orbitRingMat);
    orbitRing.rotation.x = Math.PI / 2;
    satOrbitGroup.add(orbitRing);

    // Satellite Dot Mesh
    const satMesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.028, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0x38BDF8 })
    );
    satOrbitGroup.add(satMesh);

    // --- LANDMARK BEACONS ON MARS SURFACE ---
    const markerGroup = new THREE.Group();
    marsMesh.add(markerGroup);

    LANDMARKS.forEach((landmark) => {
      const r = planetRadius + 0.015;
      const x = -r * Math.sin(landmark.phi) * Math.cos(landmark.theta);
      const y = r * Math.cos(landmark.phi);
      const z = r * Math.sin(landmark.phi) * Math.sin(landmark.theta);

      const dotGeo = new THREE.SphereGeometry(0.024, 16, 16);
      const dotMat = new THREE.MeshBasicMaterial({ color: 0xF5F1E8 });
      const dot = new THREE.Mesh(dotGeo, dotMat);
      dot.position.set(x, y, z);
      dot.userData = { landmark };

      const ringGeo = new THREE.RingGeometry(0.038, 0.054, 24);
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0xC65B43,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.9,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.position.set(x, y, z);
      ring.lookAt(new THREE.Vector3(x * 2, y * 2, z * 2));
      ring.userData = { isRing: true };

      markerGroup.add(dot);
      markerGroup.add(ring);
    });

    // --- SOLAR DIRECTIONAL LIGHTING ---
    const sunLight = new THREE.DirectionalLight(0xfff5ea, 3.0);
    sunLight.position.set(6, 2.5, 4.0);
    scene.add(sunLight);

    const rimLight = new THREE.DirectionalLight(0xC65B43, 0.85);
    rimLight.position.set(-6, -2, -3);
    scene.add(rimLight);

    const ambientLight = new THREE.AmbientLight(0x0e1320, 0.9);
    scene.add(ambientLight);

    // --- INTERACTIVE DRAG STATE ---
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;
    let currentRotationY = 0.4;
    let currentRotationX = 0.08;

    const onPointerDown = (e) => {
      if (!interactive) return;
      isDragging = true;
      prevMouseX = e.clientX || (e.touches && e.touches[0].clientX);
      prevMouseY = e.clientY || (e.touches && e.touches[0].clientY);
    };

    const onPointerMove = (e) => {
      const clientX = e.clientX || (e.touches && e.touches[0].clientX);
      const clientY = e.clientY || (e.touches && e.touches[0].clientY);

      if (isDragging && interactive) {
        const deltaX = clientX - prevMouseX;
        const deltaY = clientY - prevMouseY;
        rotTargetRef.current.y += deltaX * 0.005;
        rotTargetRef.current.x += deltaY * 0.005;
        rotTargetRef.current.x = Math.max(-0.6, Math.min(0.6, rotTargetRef.current.x));
        prevMouseX = clientX;
        prevMouseY = clientY;
      } else {
        const normX = (clientX / window.innerWidth) * 2 - 1;
        const normY = -(clientY / window.innerHeight) * 2 + 1;
        starField.rotation.y = normX * 0.035;
        starField.rotation.x = -normY * 0.035;
      }
    };

    const onPointerUp = () => {
      isDragging = false;
    };

    window.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);
    window.addEventListener('touchstart', onPointerDown, { passive: true });
    window.addEventListener('touchmove', onPointerMove, { passive: true });
    window.addEventListener('touchend', onPointerUp);

    const handleResize = () => {
      if (!container) return;
      const newW = container.clientWidth;
      const newH = container.clientHeight;
      camera.aspect = newW / newH;
      camera.updateProjectionMatrix();
      renderer.setSize(newW, newH);
    };
    window.addEventListener('resize', handleResize);

    // --- ANIMATION LOOP ---
    let animationFrameId;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Continuous slow cinematic spin when not manually dragging
      if (!isDragging && !selectedLandmark) {
        rotTargetRef.current.y += 0.0007;
      }

      // Smooth damping interpolation
      currentRotationY += (rotTargetRef.current.y - currentRotationY) * 0.06;
      currentRotationX += (rotTargetRef.current.x - currentRotationX) * 0.06;

      marsMesh.rotation.y = currentRotationY;
      marsMesh.rotation.x = currentRotationX;

      // Differential clouds drift
      cloudsMesh.rotation.y = elapsedTime * 0.006;

      // Satellite orbital translation
      const satAngle = elapsedTime * 0.6;
      satMesh.position.set(2.39 * Math.cos(satAngle), 0, 2.39 * Math.sin(satAngle));

      // Camera zoom interpolation
      camera.position.z += (targetCamZ - camera.position.z) * 0.05;

      // Beacon ring pulses
      markerGroup.children.forEach((child) => {
        if (child.userData && child.userData.isRing) {
          const s = 1 + Math.sin(elapsedTime * 3.5) * 0.2;
          child.scale.set(s, s, s);
        }
      });

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousedown', onPointerDown);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      window.removeEventListener('touchstart', onPointerDown);
      window.removeEventListener('touchmove', onPointerMove);
      window.removeEventListener('touchend', onPointerUp);
      window.removeEventListener('resize', handleResize);
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [interactive, targetCamZ]);

  return (
    <div className="relative w-full h-full select-none">
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Left: Planetary Inspection Mode Switcher */}
      <div className="absolute top-6 left-6 z-20 flex flex-col space-y-2">
        <div className="flex items-center space-x-2 text-[10px] tracking-widest text-[#9298A3] font-mono">
          <span className="w-1.5 h-1.5 rounded-full bg-[#C65B43] animate-ping" />
          <span>3D PLANETARY SENSOR CHANNELS</span>
        </div>

        <div className="inline-flex p-1 rounded-xl bg-[#080B12]/80 backdrop-blur-md border border-white/10 text-xs font-mono">
          <button
            onClick={() => handleSwitchMode('natural')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              renderMode === 'natural'
                ? 'bg-[#C65B43] text-white shadow-[0_0_15px_rgba(198,91,67,0.4)]'
                : 'text-[#9298A3] hover:text-white'
            }`}
          >
            NATURAL ALBEDO
          </button>
          <button
            onClick={() => handleSwitchMode('elevation')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              renderMode === 'elevation'
                ? 'bg-[#38BDF8] text-black font-semibold shadow-[0_0_15px_rgba(56,189,248,0.4)]'
                : 'text-[#9298A3] hover:text-white'
            }`}
          >
            MOLA ELEVATION
          </button>
          <button
            onClick={() => handleSwitchMode('thermal')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              renderMode === 'thermal'
                ? 'bg-[#FBBF24] text-black font-semibold shadow-[0_0_15px_rgba(251,191,36,0.4)]'
                : 'text-[#9298A3] hover:text-white'
            }`}
          >
            THEMIS THERMAL
          </button>
        </div>
      </div>

      {/* Top Right: Orbiting Reconnaissance Telemetry */}
      <div className="absolute top-6 right-6 hidden md:block z-20 bg-[#080B12]/75 backdrop-blur-md border border-white/10 px-4 py-3 rounded-2xl text-xs font-mono text-right">
        <div className="flex items-center justify-end space-x-2 text-[#38BDF8] text-[10px] font-bold">
          <Orbit size={13} className="animate-spin" />
          <span>MRO ORBITAL RECONNAISSANCE</span>
        </div>
        <div className="text-[#F5F1E8] font-bold mt-1">ALT: 320 KM • VEL: 3.4 KM/S</div>
        <div className="text-[10px] text-[#9298A3]">INCLINATION: 92.8° SUN-SYNCHRONOUS</div>
      </div>

      {/* Bottom Center: Sector Quick Fly-To Selector */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 bg-[#101827]/85 backdrop-blur-md border border-white/10 px-4 py-2.5 rounded-full flex items-center space-x-3 text-xs font-mono text-[#F5F1E8]">
        <span className="text-[#C65B43] flex items-center space-x-1">
          <Compass size={13} />
          <span>FOCUS SECTOR:</span>
        </span>
        {LANDMARKS.map((lm) => (
          <button
            key={lm.id}
            onClick={() => handleSelectLandmark(lm)}
            className={`px-3 py-1 rounded-full transition-all text-xs ${
              selectedLandmark?.id === lm.id
                ? 'bg-[#C65B43] text-white shadow-[0_0_15px_rgba(198,91,67,0.5)] font-semibold'
                : 'hover:bg-white/10 text-[#9298A3]'
            }`}
          >
            {lm.name.split(' ')[0]}
          </button>
        ))}
        {selectedLandmark && (
          <button
            onClick={handleResetView}
            className="text-[10px] text-[#9298A3] hover:text-white pl-1 underline"
          >
            RESET ORBIT
          </button>
        )}
      </div>

      {/* Active Landmark Telemetry Inspection Card */}
      {selectedLandmark && (
        <div className="absolute bottom-20 left-1/2 -translate-x-1/2 z-30 w-full max-w-md bg-[#101827]/95 backdrop-blur-xl border border-[#C65B43]/50 p-5 rounded-2xl shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex justify-between items-start mb-2">
            <div>
              <span className="text-[10px] font-mono text-[#C65B43] tracking-widest uppercase">
                TARGET SECTOR ACQUIRED
              </span>
              <h4 className="font-semibold text-base text-[#F5F1E8]">{selectedLandmark.name}</h4>
            </div>
            <button
              onClick={handleResetView}
              className="text-[#9298A3] hover:text-white text-xs px-2 py-1 rounded bg-white/5"
            >
              ✕
            </button>
          </div>
          <div className="flex space-x-4 text-xs text-[#9298A3] font-mono mb-3">
            <span>COORDS: <strong className="text-white">{selectedLandmark.coords}</strong></span>
            <span>•</span>
            <span>ELEV: <strong className="text-[#38BDF8]">{selectedLandmark.elev}</strong></span>
          </div>
          <p className="text-xs text-[#F5F1E8]/85 leading-relaxed font-light">
            {selectedLandmark.desc}
          </p>
        </div>
      )}
    </div>
  );
}
