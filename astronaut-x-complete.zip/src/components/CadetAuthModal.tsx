import React, { useState } from 'react';
import {
  Shield, Key, User, Sparkles, CheckCircle2, Lock,
  ChevronRight, X, Fingerprint, Eye, Award, Orbit, Rocket, Dna, Compass, Zap
} from 'lucide-react';
import { useProgress } from '../context/ProgressContext';
import { soundManager } from '../utils/audio';

interface CadetAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenLogin?: () => void;
}

const ROSTER_PROFILES = [
  {
    callsign: 'Cadet Aria Vance',
    specialisation: 'Flight Commander & Astrodynamics',
    rank: 'Flight Commander',
    level: 4,
    xp: 2850,
    avatar: '🧑‍🚀',
    pin: '2026',
    clearance: 'LEVEL 4 // COMMAND',
  },
  {
    callsign: 'Cadet Leo Chen',
    specialisation: 'Bio-Regenerative Life Support',
    rank: 'Mission Specialist',
    level: 3,
    xp: 1450,
    avatar: '🔬',
    pin: '1977',
    clearance: 'LEVEL 3 // SCIENTIST',
  },
  {
    callsign: 'Cadet Maya Patel',
    specialisation: 'Propulsion & Kinetic Defense',
    rank: 'Mission Specialist',
    level: 3,
    xp: 1820,
    avatar: '🚀',
    pin: '2024',
    clearance: 'LEVEL 3 // ENGINEER',
  },
];

const SPECIALIZATIONS = [
  'Flight Commander & Astrodynamics',
  'Bio-Regenerative Life Support & Astrobiology',
  'Orbital Astrodynamics & Navigation',
  'Propulsion Systems & Kinetic Defense',
  'Planetary Geology & Sample Caching',
];

export default function CadetAuthModal({ isOpen, onClose, onOpenLogin }: CadetAuthModalProps) {
  const { progress, loginProfile } = useProgress();

  const [mode, setMode] = useState<'login' | 'register' | 'roster'>('login');
  const [callsign, setCallsign] = useState(progress.callsign || 'Cadet Aria Vance');
  const [pin, setPin] = useState('2026');
  const [specialisation, setSpecialisation] = useState(progress.specialisation || SPECIALIZATIONS[0]);

  // Biometric Scan Animation State
  const [isScanning, setIsScanning] = useState(false);
  const [scanVerified, setScanVerified] = useState(false);
  const [authSuccess, setAuthSuccess] = useState(false);

  if (!isOpen) return null;

  // Simulate Biometric Scanning
  const triggerBiometricScan = () => {
    soundManager.playClick();
    setIsScanning(true);
    setScanVerified(false);

    setTimeout(() => {
      setIsScanning(false);
      setScanVerified(true);
      soundManager.playSuccess();
    }, 1200);
  };

  // Handle Login / Registration Submit
  const handleAuthorize = (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playLaunch();
    setAuthSuccess(true);

    setTimeout(() => {
      loginProfile({
        callsign: callsign.trim() || 'Cadet Aria Vance',
        specialisation,
        xp: mode === 'register' ? 250 : progress.xp,
      });
      setAuthSuccess(false);
      onClose();
    }, 800);
  };

  // Quick Select from Demo Roster
  const handleSelectRoster = (prof: typeof ROSTER_PROFILES[0]) => {
    soundManager.playSuccess();
    setCallsign(prof.callsign);
    setSpecialisation(prof.specialisation);
    setPin(prof.pin);
    setScanVerified(true);
    loginProfile({
      callsign: prof.callsign,
      specialisation: prof.specialisation,
      xp: prof.xp,
    });
    setTimeout(() => {
      onClose();
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl animate-in fade-in duration-300">
      {/* Background Cosmic Glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[550px] bg-[#C65B43]/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[450px] h-[450px] bg-[#38BDF8]/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Main Glassmorphic Auth Card */}
      <div className="relative w-full max-w-xl rounded-3xl bg-[#060B18]/95 border border-white/15 p-6 sm:p-8 text-[#F8FAFC] shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden">
        {/* Subtle Scanline Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-white/[0.02] to-transparent pointer-events-none" />

        {/* Modal Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-[#94A3B8] hover:text-white transition-colors cursor-pointer"
        >
          <X size={16} />
        </button>

        {/* Card Header & Insignia */}
        <div className="text-center mb-6">
          <div className="relative w-14 h-14 mx-auto mb-3 flex items-center justify-center rounded-2xl bg-gradient-to-br from-[#C65B43] to-[#8F3724] border border-white/20 shadow-[0_0_30px_rgba(198,91,67,0.5)]">
            <Shield size={24} className="text-white" />
            <span className="absolute -inset-1.5 rounded-2xl border border-[#C65B43]/40 animate-pulse" />
          </div>

          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-mono text-[#38BDF8] uppercase tracking-widest mb-1.5">
            <Lock size={11} />
            <span>NASA RESOURCE ACCESS PROTOCOL // LEVEL 4</span>
          </div>

          <h3 className="font-display font-extrabold text-2xl sm:text-3xl text-white tracking-tight">
            Astronaut Flight Authorization
          </h3>
          <p className="text-xs font-mono text-[#94A3B8] mt-1">
            Authenticate astronaut credentials to sync mission telemetry, XP, and certified badges.
          </p>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10 mb-6 font-mono text-xs">
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`flex-1 py-2 rounded-xl transition-all cursor-pointer font-bold ${
              mode === 'login'
                ? 'bg-gradient-to-r from-[#C65B43] to-[#E07A5F] text-white shadow-lg'
                : 'text-[#94A3B8] hover:text-white'
            }`}
          >
            LOGIN
          </button>
          <button
            type="button"
            onClick={() => setMode('register')}
            className={`flex-1 py-2 rounded-xl transition-all cursor-pointer font-bold ${
              mode === 'register'
                ? 'bg-gradient-to-r from-[#38BDF8] to-[#818CF8] text-black shadow-lg'
                : 'text-[#94A3B8] hover:text-white'
            }`}
          >
            NEW CADET
          </button>
          <button
            type="button"
            onClick={() => setMode('roster')}
            className={`flex-1 py-2 rounded-xl transition-all cursor-pointer font-bold ${
              mode === 'roster'
                ? 'bg-gradient-to-r from-[#FBBF24] to-[#F59E0B] text-black shadow-lg'
                : 'text-[#94A3B8] hover:text-white'
            }`}
          >
            DEMO ROSTER
          </button>
        </div>

        {/* TAB 1 & 2: LOGIN / REGISTER FORM */}
        {mode !== 'roster' && (
          <form onSubmit={handleAuthorize} className="space-y-4">
            {/* Callsign Input */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-mono text-[#94A3B8] uppercase block">
                Astronaut Callsign / Handle:
              </label>
              <div className="relative">
                <User size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
                <input
                  type="text"
                  required
                  value={callsign}
                  onChange={(e) => setCallsign(e.target.value)}
                  placeholder="e.g. Cadet Aria Vance"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-[#38BDF8] transition-colors"
                />
              </div>
            </div>

            {/* Specialization Selection (for Register) */}
            {mode === 'register' && (
              <div className="space-y-1.5">
                <label className="text-[11px] font-mono text-[#94A3B8] uppercase block">
                  Mission Specialization:
                </label>
                <select
                  value={specialisation}
                  onChange={(e) => setSpecialisation(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#0B132B] border border-white/15 text-white font-mono text-xs focus:outline-none focus:border-[#38BDF8]"
                >
                  {SPECIALIZATIONS.map((spec) => (
                    <option key={spec} value={spec} className="bg-[#060B18] text-white">
                      {spec}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Security PIN Passcode */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[11px] font-mono">
                <span className="text-[#94A3B8] uppercase">Flight Clearance PIN:</span>
                <span className="text-[#38BDF8]">Demo PIN: 2026</span>
              </div>
              <div className="relative">
                <Key size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
                <input
                  type="password"
                  required
                  maxLength={6}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="••••"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs tracking-widest focus:outline-none focus:border-[#C65B43] transition-colors"
                />
              </div>
            </div>

            {/* Biometric Scan Simulator Strip */}
            <div className="pt-2">
              <button
                type="button"
                onClick={triggerBiometricScan}
                disabled={isScanning}
                className={`w-full p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer ${
                  scanVerified
                    ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-400'
                    : isScanning
                    ? 'bg-blue-950/30 border-blue-500/40 text-blue-400 animate-pulse'
                    : 'bg-white/[0.03] border-white/10 text-[#94A3B8] hover:bg-white/[0.06] hover:text-white'
                }`}
              >
                <div className="flex items-center space-x-2.5 font-mono text-xs">
                  <Fingerprint size={18} className={scanVerified ? 'text-[#34D399]' : 'text-[#38BDF8]'} />
                  <span>
                    {isScanning
                      ? 'SCANNING RETINAL & BIOMETRIC UPLINK...'
                      : scanVerified
                      ? 'BIOMETRIC SIGNATURE VERIFIED'
                      : 'TAP TO SIMULATE BIOMETRIC SCAN'}
                  </span>
                </div>
                {scanVerified && <CheckCircle2 size={16} className="text-[#34D399]" />}
              </button>
            </div>

            {/* Action Buttons */}
            <div className="pt-3 space-y-2">
              <button
                type="submit"
                disabled={authSuccess}
                className="w-full py-3.5 rounded-full bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#C65B43] hover:brightness-110 text-white font-mono text-xs font-bold tracking-wider uppercase shadow-[0_0_30px_rgba(198,91,67,0.5)] transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Sparkles size={14} />
                <span>
                  {authSuccess
                    ? 'CLEARANCE GRANTED // SYNCING...'
                    : mode === 'register'
                    ? 'COMMISSION NEW CADET'
                    : 'AUTHORIZE FLIGHT ACCESS'}
                </span>
              </button>

              {onOpenLogin && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenLogin();
                  }}
                  className="w-full py-2.5 rounded-full bg-gradient-to-r from-[#38BDF8]/20 to-[#818CF8]/20 border border-[#38BDF8]/50 text-[#38BDF8] hover:text-white font-mono text-xs font-bold transition-all cursor-pointer flex items-center justify-center space-x-1.5"
                >
                  <Shield size={13} />
                  <span>OPEN FULLSCREEN STUDENT LOGIN PORTAL</span>
                </button>
              )}

              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 rounded-full bg-white/5 hover:bg-white/10 text-[#94A3B8] hover:text-white font-mono text-xs transition-colors cursor-pointer"
              >
                Continue as Guest Astronaut
              </button>
            </div>
          </form>
        )}

        {/* TAB 3: DEMO ROSTER (1-CLICK QUICK ACCESS) */}
        {mode === 'roster' && (
          <div className="space-y-3">
            <span className="text-[11px] font-mono text-[#94A3B8] uppercase block">
              Pre-Configured Flight Crew Profiles (Click to Authorize):
            </span>

            {ROSTER_PROFILES.map((prof) => (
              <button
                key={prof.callsign}
                onClick={() => handleSelectRoster(prof)}
                className="w-full p-4 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-[#38BDF8] hover:bg-white/[0.07] transition-all text-left flex items-center justify-between group cursor-pointer"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-xl">
                    {prof.avatar}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-display font-bold text-sm text-white group-hover:text-[#38BDF8] transition-colors">
                        {prof.callsign}
                      </span>
                      <span className="px-2 py-0.5 rounded text-[9px] font-mono bg-[#38BDF8]/20 text-[#38BDF8]">
                        Level {prof.level}
                      </span>
                    </div>
                    <span className="text-xs text-[#94A3B8] font-mono block mt-0.5">
                      {prof.specialisation}
                    </span>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <span className="text-xs font-bold text-[#FBBF24] block">{prof.xp} XP</span>
                  <span className="text-[10px] text-[#34D399] flex items-center gap-1 justify-end">
                    <span>Select</span>
                    <ChevronRight size={12} />
                  </span>
                </div>
              </button>
            ))}

            <button
              type="button"
              onClick={onClose}
              className="w-full py-2.5 mt-2 rounded-full bg-white/5 hover:bg-white/10 text-[#94A3B8] hover:text-white font-mono text-xs transition-colors cursor-pointer"
            >
              Close Roster
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
