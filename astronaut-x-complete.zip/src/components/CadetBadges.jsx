import React, { useState } from 'react';
import {
  Award, Star, ShieldCheck, Trophy, Sparkles, CheckCircle2, Lock,
  Download, Upload, Printer, RotateCcw, FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../utils/audio';
import { useProgress, ALL_ACHIEVEMENTS } from '../context/ProgressContext';

export default function CadetBadges({ onOpenCertificate }) {
  const {
    progress,
    rank,
    exportProgressJson,
    importProgressJson,
    resetProgress,
    setCallsign,
    setSpecialisation
  } = useProgress();

  const [selectedBadge, setSelectedBadge] = useState(ALL_ACHIEVEMENTS[0]);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [tempCallsign, setTempCallsign] = useState(progress.callsign);

  const handleBadgeClick = (b) => {
    soundManager.playSuccess();
    setSelectedBadge(b);
    if (progress.unlockedAchievements.includes(b.id)) {
      try {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.7 },
          colors: ['#FBBF24', '#34D399', '#38BDF8', '#C65B43'],
        });
      } catch (e) {}
    }
  };

  const handleExportBackup = () => {
    const jsonStr = exportProgressJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `astronaut_x_progress_${progress.callsign.replace(/\s+/g, '_').toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result;
        if (text) {
          importProgressJson(text);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <section id="cadet-badges" className="py-20 bg-[#080B12] border-t border-white/5 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#FBBF24] uppercase mb-3">
              <Trophy size={14} className="text-[#FBBF24]" />
              <span>ASTRONAUT DOSSIER // UNIFIED PROGRESSION</span>
            </div>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight text-[#F5F1E8] uppercase">
              Flight Ranks & Flight Wings
            </h2>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            {onOpenCertificate && (
              <button
                onClick={onOpenCertificate}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#FBBF24] to-[#C65B43] text-[#080B12] font-display font-bold text-xs uppercase tracking-wider flex items-center space-x-2 transition-all hover:scale-105 shadow cursor-pointer"
              >
                <Award size={15} />
                <span>Print Flight Wings Certificate</span>
              </button>
            )}
            <button
              onClick={handleExportBackup}
              className="px-3.5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-xs flex items-center space-x-1.5 transition-colors cursor-pointer"
              title="Export progress JSON backup"
            >
              <Download size={13} />
              <span>Export</span>
            </button>
            <label className="px-3.5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-xs flex items-center space-x-1.5 transition-colors cursor-pointer">
              <Upload size={13} />
              <span>Import</span>
              <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
            </label>
          </div>
        </div>

        {/* Level Progression Bar */}
        <div className="p-6 rounded-3xl bg-[#101827] border border-white/10 shadow-2xl mb-10">
          <div className="flex flex-wrap justify-between items-center text-xs font-mono mb-2 gap-2">
            <div className="flex items-center space-x-3">
              <span className="text-[#34D399] font-bold text-sm">
                RANK: {rank.title.toUpperCase()} (LEVEL {rank.level})
              </span>
              <span className="text-white/60">•</span>
              <span className="text-[#38BDF8]">{progress.callsign}</span>
              <span className="text-white/40">[{progress.specialisation}]</span>
            </div>
            <div className="text-white/80 font-mono">
              <span className="text-[#FBBF24] font-bold text-base">{progress.xp} XP</span>
              <span className="text-[#9298A3] text-xs"> / {rank.nextXp} XP (Tier {rank.progressPercent}%)</span>
            </div>
          </div>

          <div className="w-full bg-[#080B12] h-3 rounded-full overflow-hidden p-0.5 border border-white/10">
            <div
              className="bg-gradient-to-r from-[#C65B43] via-[#FBBF24] to-[#34D399] h-full rounded-full transition-all duration-500"
              style={{ width: `${rank.progressPercent}%` }}
            />
          </div>

          <div className="flex justify-between text-[10px] font-mono text-[#9298A3]/70 mt-2">
            <span>JUNIOR CADET (0 XP)</span>
            <span>FLIGHT SPECIALIST (300 XP)</span>
            <span>MISSION SPECIALIST (750 XP)</span>
            <span>FLIGHT COMMANDER (1,400 XP)</span>
            <span>EXPEDITION DIRECTOR (2,200+ XP)</span>
          </div>
        </div>

        {/* Collectible Badges Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          {ALL_ACHIEVEMENTS.map((b) => {
            const isUnlocked = progress.unlockedAchievements.includes(b.id);
            const isSelected = selectedBadge?.id === b.id;

            return (
              <div
                key={b.id}
                onClick={() => handleBadgeClick(b)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col items-center text-center group relative overflow-hidden ${
                  isSelected
                    ? 'bg-[#101827] border-[#FBBF24] shadow-[0_0_25px_rgba(251,191,36,0.3)] scale-105'
                    : isUnlocked
                    ? 'bg-[#101827]/70 border-white/15 hover:border-white/30'
                    : 'bg-[#101827]/30 border-white/5 opacity-50'
                }`}
              >
                {!isUnlocked && (
                  <div className="absolute top-2 right-2 text-white/30">
                    <Lock size={12} />
                  </div>
                )}
                <div className={`text-3xl mb-2 transition-transform group-hover:scale-110 ${!isUnlocked ? 'grayscale' : ''}`}>
                  {b.icon}
                </div>
                <h4 className="font-semibold text-xs text-[#F5F1E8] mb-1 leading-tight line-clamp-1">
                  {b.name}
                </h4>
                <span className="text-[10px] font-mono text-[#FBBF24] font-bold">
                  {isUnlocked ? `+${b.xp} XP` : `Locked (${b.xp} XP)`}
                </span>
              </div>
            );
          })}
        </div>

        {/* Selected Badge Inspection Detail */}
        {selectedBadge && (
          <div className="p-6 rounded-2xl bg-[#101827]/80 border border-[#FBBF24]/30 backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <span className="text-3xl">{selectedBadge.icon}</span>
              <div>
                <h4 className="font-semibold text-sm text-[#F5F1E8] flex items-center space-x-2">
                  <span>{selectedBadge.name}</span>
                  {progress.unlockedAchievements.includes(selectedBadge.id) ? (
                    <span className="text-[#34D399] font-mono text-xs">(UNLOCKED)</span>
                  ) : (
                    <span className="text-[#9298A3] font-mono text-xs">(LOCKED — COMPLETE RELEVANT MISSION)</span>
                  )}
                </h4>
                <p className="text-xs text-[#9298A3] leading-relaxed">
                  {selectedBadge.desc}
                </p>
              </div>
            </div>
            <div className="font-mono text-sm font-bold text-[#FBBF24] shrink-0">
              VALUED: +{selectedBadge.xp} XP
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
