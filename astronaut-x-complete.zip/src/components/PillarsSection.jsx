import React, { useState } from 'react';
import { HeartPulse, Compass, BrainCircuit, Droplets, Wind, Zap, Shield, AlertTriangle, CheckCircle2, ChevronRight } from 'lucide-react';
import { soundManager } from '../utils/audio';

const PILLARS_DATA = [
  {
    id: 'survival',
    number: '01',
    title: 'SURVIVAL',
    subtitle: 'Manage oxygen, water, food and energy.',
    icon: HeartPulse,
    accent: '#C65B43',
    overview: 'A closed-loop ecological life support system where every molecule counts. On Mars, resupply from Earth takes 9 months—survival hinges on in-situ resource utilization (ISRU) and 98% reclamation efficiency.',
    subsystems: [
      {
        name: 'MOXIE Oxygen Production',
        description: 'Extracts breathable O₂ directly from the Martian atmospheric CO₂ via solid oxide electrolysis at 800°C.',
        metric: '12.0 g/hr',
        status: 'NOMINAL',
        icon: Wind,
      },
      {
        name: 'Sabatier Water Recovery',
        description: 'Catalytic reduction of CO₂ with hydrogen byproduct to recycle 98.4% of all crew moisture and perspiration.',
        metric: '98.4% RECLAIM',
        status: 'OPTIMAL',
        icon: Droplets,
      },
      {
        name: 'Kilopower Fission Reactor',
        description: 'Stirling-cycle 10 kW nuclear power unit providing uninterrupted baseline energy through dust storms and polar night.',
        metric: '9.8 kW OUT',
        status: 'ACTIVE',
        icon: Zap,
      },
    ],
    interactivePreview: {
      type: 'slider',
      label: 'MOXIE ELECTROLYSIS OUTPUT',
      unit: '%',
      defaultVal: 85,
    },
  },
  {
    id: 'exploration',
    number: '02',
    title: 'EXPLORATION',
    subtitle: 'Discover Martian terrain and environmental challenges.',
    icon: Compass,
    accent: '#E07A5F',
    overview: 'Traversing the Jezero delta, descending into volcanic lava tubes, and surveying vast subsurface glaciers. Crew members must operate in extreme 0.38g dust environments under lethal cosmic radiation exposure.',
    subsystems: [
      {
        name: 'Pressurized Rover Logistics',
        description: '14-day autonomous range with onboard dual airlock, active radiation shielding, and rocker-bogie terrain suspension.',
        metric: '120 km RANGE',
        status: 'STAGED',
        icon: Compass,
      },
      {
        name: 'Sub-Surface Glacier Coring',
        description: 'Deep ice radar sounding to extract pristine paleoclimate ice cores from Utopia Planitia buried glaciers.',
        metric: '140 m DEPTH',
        status: 'LOGGED',
        icon: Shield,
      },
      {
        name: 'Electrostatic Dust Mitigation',
        description: 'Electrodynamic dust shields to prevent abrasive, perchlorate-laden Martian regolith from penetrating EVA seals.',
        metric: '99.1% REPEL',
        status: 'ONLINE',
        icon: Wind,
      },
    ],
    interactivePreview: {
      type: 'radar',
      label: 'EVA TRAVERSE SAFETY RADIUS',
      unit: 'km',
      defaultVal: 45,
    },
  },
  {
    id: 'decision',
    number: '03',
    title: 'DECISION',
    subtitle: 'Make critical choices that determine your crew’s future.',
    icon: BrainCircuit,
    accent: '#38BDF8',
    overview: 'With a 14-minute communication delay to Mission Control in Houston, real-time crisis resolution belongs entirely to the Junior Commander. One split-second calculation alters the mission trajectory forever.',
    subsystems: [
      {
        name: 'Cognitive Triage Protocol',
        description: 'Algorithmic decision tree prioritizing crew life, critical life support integrity, and mission objectives.',
        metric: '14m 22s DELAY',
        status: 'AUTONOMOUS',
        icon: BrainCircuit,
      },
      {
        name: 'Hohmann Transfer Abort Window',
        description: 'Orbital velocity delta-v calculations determining return-to-Earth burn windows and ballistic trajectories.',
        metric: 'ΔV 3.8 km/s',
        status: 'LOCKED',
        icon: AlertTriangle,
      },
      {
        name: 'Resource Depletion Allocation',
        description: 'Dynamic power shedding during dust storm occlusions to maintain cryogenic oxygen tank pressurization.',
        metric: 'AUTO-SHED',
        status: 'STANDBY',
        icon: CheckCircle2,
      },
    ],
    interactivePreview: {
      type: 'decision',
      label: 'SIMULATED CRISIS RESPONSE PROTOCOL',
      unit: 'SOL',
      defaultVal: 1042,
    },
  },
];

export default function PillarsSection() {
  const [activePillarIndex, setActivePillarIndex] = useState(0);
  const [sliderValue, setSliderValue] = useState(85);

  const activePillar = PILLARS_DATA[activePillarIndex];

  const handleSelectPillar = (idx) => {
    soundManager.playClick();
    setActivePillarIndex(idx);
  };

  return (
    <section id="three-pillars" className="py-28 md:py-36 bg-transparent border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#C65B43] uppercase mb-4">
              <span>03 / SECTION</span>
              <span className="w-8 h-[1px] bg-[#C65B43]/50" />
              <span>CORE ARCHITECTURE</span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-white uppercase">
              THE THREE PILLARS
            </h2>
          </div>
          <p className="max-w-md text-sm text-[#94A3B8] font-light leading-relaxed">
            Every astronaut cadet undergoes rigorous preparation structured across three foundational tenets of deep space expeditionary survival.
          </p>
        </div>

        {/* Pillar Navigation Tabs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          {PILLARS_DATA.map((pillar, idx) => {
            const Icon = pillar.icon;
            const isSelected = activePillarIndex === idx;
            return (
              <button
                key={pillar.id}
                onClick={() => handleSelectPillar(idx)}
                className={`text-left p-6 rounded-3xl border transition-all duration-300 relative overflow-hidden group cursor-pointer ${
                  isSelected
                    ? 'glass-panel-card border-[#C65B43] shadow-[0_0_35px_rgba(198,91,67,0.3)] scale-[1.02]'
                    : 'glass-panel-card hover:border-white/20'
                }`}
              >
                {/* Active Indicator bar */}
                {isSelected && (
                  <span className="absolute top-0 left-0 right-0 h-[2.5px] bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#38BDF8]" />
                )}

                <div className="flex items-center justify-between mb-4">
                  <span className="font-mono text-xs tracking-widest text-[#94A3B8]">
                    {pillar.number} — TENET
                  </span>
                  <Icon
                    size={20}
                    className={`transition-colors ${
                      isSelected ? 'text-[#C65B43]' : 'text-[#94A3B8] group-hover:text-white'
                    }`}
                  />
                </div>

                <h3 className="font-display text-2xl font-bold tracking-tight text-white mb-2">
                  {pillar.title}
                </h3>
                <p className="text-xs text-[#94A3B8] leading-relaxed">
                  {pillar.subtitle}
                </p>
              </button>
            );
          })}
        </div>

        {/* Detailed Pillar Inspection Panel */}
        <div className="p-8 md:p-12 rounded-3xl glass-panel-card relative overflow-hidden">
          {/* Subtle background glow */}
          <div
            className="absolute -right-32 -top-32 w-80 h-80 rounded-full blur-[100px] pointer-events-none opacity-20"
            style={{ backgroundColor: activePillar.accent }}
          />

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            {/* Left Column: Pillar Deep Dive */}
            <div className="lg:col-span-5">
              <div className="inline-flex items-center space-x-2 text-xs font-mono tracking-widest text-[#9298A3] uppercase mb-3">
                <span className="w-1.5 h-1.5 rounded-full bg-[#C65B43]" />
                <span>DEEP SPACE DOCTRINE</span>
              </div>
              <h4 className="font-display text-3xl font-bold text-[#F5F1E8] mb-4">
                {activePillar.title}: MISSION SPECIFICATION
              </h4>
              <p className="text-sm text-[#9298A3] leading-relaxed mb-8 font-light">
                {activePillar.overview}
              </p>

              {/* Interactive Subsystem Telemetry Slider */}
              <div className="p-5 rounded-2xl bg-[#080B12]/80 border border-white/10 mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-mono text-[#9298A3]">
                    {activePillar.interactivePreview.label}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#C65B43]">
                    {sliderValue}
                    {activePillar.interactivePreview.unit}
                  </span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="100"
                  value={sliderValue}
                  onChange={(e) => setSliderValue(Number(e.target.value))}
                  className="w-full accent-[#C65B43] bg-white/10 h-1.5 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] font-mono text-[#9298A3]/60 mt-1">
                  <span>CONSERVATIVE (40%)</span>
                  <span>PEAK THRUPUT (100%)</span>
                </div>
              </div>
            </div>

            {/* Right Column: Subsystems Cards */}
            <div className="lg:col-span-7 flex flex-col space-y-4">
              <div className="text-xs font-mono tracking-widest text-[#9298A3] uppercase mb-2">
                CRITICAL LIFE-LINE SUBSYSTEMS
              </div>

              {activePillar.subsystems.map((sub, sIdx) => {
                const SubIcon = sub.icon;
                return (
                  <div
                    key={sIdx}
                    className="p-5 rounded-2xl bg-[#080B12]/60 border border-white/5 hover:border-white/15 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 group"
                  >
                    <div className="flex items-start space-x-4">
                      <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-[#C65B43] group-hover:scale-105 transition-transform">
                        <SubIcon size={20} />
                      </div>
                      <div>
                        <h5 className="font-semibold text-sm text-[#F5F1E8] mb-1">
                          {sub.name}
                        </h5>
                        <p className="text-xs text-[#9298A3] leading-relaxed max-w-md">
                          {sub.description}
                        </p>
                      </div>
                    </div>

                    <div className="flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto border-t sm:border-t-0 border-white/5 pt-3 sm:pt-0">
                      <span className="font-mono text-sm font-bold text-[#F5F1E8]">
                        {sub.metric}
                      </span>
                      <span className="text-[10px] font-mono text-[#34D399] tracking-wider">
                        {sub.status}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
