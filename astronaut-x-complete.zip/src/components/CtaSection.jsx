import React from 'react';
import { Rocket, ArrowRight, ShieldCheck, Orbit } from 'lucide-react';
import { soundManager } from '../utils/audio';

export default function CtaSection({ onEnterMissionControl }) {
  const handleEnterMissionControl = () => {
    soundManager.playLaunch();
    onEnterMissionControl();
  };

  return (
    <section className="relative min-h-[85vh] flex items-center justify-center bg-transparent overflow-hidden py-32 border-t border-white/5">
      {/* Background Deep Space & Martian Atmospheric Horizon Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-[#C65B43]/20 via-[#030712] to-[#030712] pointer-events-none" />
      <div className="absolute -bottom-48 left-1/2 -translate-x-1/2 w-[900px] h-[350px] rounded-full bg-[#C65B43]/20 blur-[140px] pointer-events-none" />
      <div className="absolute top-10 left-10 w-[400px] h-[400px] bg-[#38BDF8]/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Telemetry Grid Overlay */}
      <div className="absolute inset-0 telemetry-grid opacity-20 pointer-events-none" />

      <div className="max-w-5xl mx-auto px-6 md:px-12 text-center relative z-10">
        {/* Mission Index Badge */}
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 mb-8 backdrop-blur-xl">
          <span className="w-2 h-2 rounded-full bg-[#34D399] animate-ping" />
          <span className="text-xs font-mono tracking-widest text-[#38BDF8] uppercase font-bold">
            FLIGHT READINESS COMMENCEMENT // EXPEDITION 2026
          </span>
        </div>

        {/* Section Heading */}
        <h2 className="font-display text-5xl sm:text-7xl md:text-8xl font-black tracking-tight text-white uppercase leading-[0.92] mb-8 drop-shadow-2xl">
          YOUR MISSION.
          <span className="block text-gradient-mars">
            YOUR DECISIONS.
          </span>
          <span className="block text-white">YOUR FUTURE.</span>
        </h2>

        {/* Supporting Narrative */}
        <p className="max-w-2xl mx-auto text-base sm:text-lg text-[#94A3B8] leading-relaxed font-normal mb-12">
          Step into the flight deck of Habitation Alpha at Jezero Crater. Calibrate life support, navigate treacherous regolith storms, and forge the next giant leap for humankind.
        </p>

        {/* Primary Action Button: ENTER MISSION CONTROL */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <button
            onClick={handleEnterMissionControl}
            className="group px-10 py-5 rounded-full bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#C65B43] hover:brightness-110 text-white font-mono text-sm tracking-widest font-bold transition-all duration-300 shadow-[0_0_40px_rgba(198,91,67,0.55)] hover:shadow-[0_0_65px_rgba(198,91,67,0.85)] active:scale-95 flex items-center space-x-3 cursor-pointer"
          >
            <span>ENTER MISSION CONTROL</span>
            <Rocket size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </button>
        </div>

        {/* Bottom Verification Badges */}
        <div className="flex flex-wrap items-center justify-center gap-8 text-xs font-mono text-[#9298A3]">
          <div className="flex items-center space-x-2">
            <ShieldCheck size={16} className="text-[#34D399]" />
            <span>NASA SPACE APPS 2026 STANDARDS</span>
          </div>
          <div className="text-white/20">•</div>
          <div className="flex items-center space-x-2">
            <Orbit size={16} className="text-[#38BDF8]" />
            <span>AUTHENTIC JPL TELEMETRY</span>
          </div>
          <div className="text-white/20">•</div>
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-[#34D399]" />
            <span>ZERO LATENCY WEB ENGINE</span>
          </div>
        </div>
      </div>
    </section>
  );
}
