import React, { useState, useEffect } from 'react';
import {
  Volume2, VolumeX, Menu, X, Rocket, Compass, Shield, Orbit, Activity,
  CloudSun, Wrench, Presentation, Play, Trophy, Scale, Home, BookOpen,
  Image as ImageIcon, Bot, Award, Sparkles, Database, Gamepad2, Dna, Radio
} from 'lucide-react';
import { soundManager } from '../utils/audio';
import { useProgress } from '../context/ProgressContext';

export default function Navbar({
  onLaunchSimulator,
  onOpenPresentation,
  onOpenAstra,
  onOpenDemoTour,
  onOpenCertificate,
  onOpenAuth,
  onOpenLogin,
}) {
  const { progress, rank } = useProgress();
  const [isAudioActive, setIsAudioActive] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [freqBars, setFreqBars] = useState([6, 12, 18, 14, 22, 10, 5, 3]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Poll frequency data for audio visualizer
  useEffect(() => {
    if (!isAudioActive) return;
    const interval = setInterval(() => {
      const data = soundManager.getFrequencyData();
      if (data && data.length > 0) {
        setFreqBars(data.map((v) => Math.max(3, Math.floor(v / 8))));
      }
    }, 100);
    return () => clearInterval(interval);
  }, [isAudioActive]);

  // Global keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.key === 'm' || e.key === 'M') {
        const active = soundManager.toggleMute();
        setIsAudioActive(active);
      } else if (e.key === 'a' || e.key === 'A') {
        if (onOpenAstra) {
          soundManager.playClick();
          onOpenAstra();
        }
      } else if (e.key === 'd' || e.key === 'D') {
        if (onOpenDemoTour) {
          soundManager.playClick();
          onOpenDemoTour();
        }
      } else if (e.key === 'c' || e.key === 'C') {
        if (onOpenCertificate) {
          soundManager.playClick();
          onOpenCertificate();
        }
      } else if (e.key === 'l' || e.key === 'L') {
        if (onOpenLogin) {
          soundManager.playClick();
          onOpenLogin();
        } else if (onOpenAuth) {
          soundManager.playClick();
          onOpenAuth();
        }
      } else if (e.key === 'p' || e.key === 'P') {
        if (onOpenPresentation) {
          soundManager.playClick();
          onOpenPresentation();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onOpenAstra, onOpenDemoTour, onOpenCertificate, onOpenPresentation, onOpenAuth]);

  const handleToggleAudio = () => {
    const active = soundManager.toggleMute();
    setIsAudioActive(active);
    if (active) soundManager.playClick();
  };

  const navLinks = [
    { label: 'COSMOS MCC', href: '#cosmos-mission-control', icon: Rocket },
    { label: 'SOLAR SYSTEM', href: '#solar-system-explorer', icon: Orbit },
    { label: 'EVA FLIGHT', href: '#eva-operations-hub', icon: Compass },
    { label: 'SIM ARCADE', href: '#space-games-arcade', icon: Gamepad2 },
    { label: 'ACADEMY', href: '#astronaut-academy', icon: BookOpen },
    { label: 'SPACE BIOLOGY', href: '#space-biology-lab', icon: Dna },
    { label: 'NASA MEDIA', href: '#nasa-media-explorer', icon: ImageIcon },
    { label: 'DATA REPO', href: '#scientific-resources', icon: Database },
  ];

  const handleLinkClick = (e, href) => {
    e.preventDefault();
    soundManager.playClick();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 px-3 sm:px-6 pt-3 sm:pt-4 transition-all duration-300 pointer-events-none">
      {/* Floating Glassmorphic Pill Dock */}
      <div
        className={`max-w-7xl mx-auto rounded-full transition-all duration-300 pointer-events-auto flex items-center justify-between px-3.5 sm:px-5 py-2 sm:py-2.5 ${
          isScrolled
            ? 'bg-[#060B18]/85 backdrop-blur-2xl border border-white/15 shadow-[0_20px_50px_rgba(0,0,0,0.85)]'
            : 'bg-[#060B18]/60 backdrop-blur-xl border border-white/10 shadow-[0_10px_30px_rgba(0,0,0,0.6)]'
        }`}
      >
        {/* Brand Insignia: ASTRONAUT-X */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            soundManager.playClick();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="group flex items-center space-x-3 text-decoration-none select-none"
        >
          <div className="relative w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center rounded-full bg-gradient-to-br from-[#C65B43] to-[#8F3724] border border-white/20 shadow-[0_0_20px_rgba(198,91,67,0.4)] group-hover:shadow-[0_0_25px_rgba(198,91,67,0.7)] transition-all">
            <span className="font-display font-black text-white text-xs sm:text-sm tracking-tight">AX</span>
            {/* Pulsing Orbit Ring */}
            <span className="absolute -inset-1 rounded-full border border-[#C65B43]/40 group-hover:scale-110 transition-transform duration-500" />
          </div>

          <div className="hidden xs:block">
            <div className="flex items-center space-x-1.5 leading-none">
              <span className="font-display font-extrabold tracking-wider text-sm sm:text-base text-white">
                ASTRONAUT-X
              </span>
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#34D399] animate-pulse" />
            </div>
            <div className="text-[9px] sm:text-[10px] font-mono tracking-widest text-[#94A3B8] uppercase mt-0.5">
              {rank.title} • <span className="text-[#38BDF8]">{progress.xp} XP</span>
            </div>
          </div>
        </a>

        {/* Center Desktop Navigation Pill Links */}
        <nav className="hidden lg:flex items-center space-x-1 bg-white/[0.03] border border-white/5 rounded-full px-3 py-1">
          {navLinks.map((item) => (
            <a
              key={item.label}
              href={item.href}
              onClick={(e) => handleLinkClick(e, item.href)}
              className="text-[11px] font-mono tracking-wider text-[#94A3B8] hover:text-white px-3 py-1.5 rounded-full transition-all hover:bg-white/5 relative group flex items-center space-x-1"
            >
              <span>{item.label}</span>
              <span className="w-1 h-1 rounded-full bg-[#38BDF8] opacity-0 group-hover:opacity-100 transition-opacity" />
            </a>
          ))}
        </nav>

        {/* Right Action Cluster */}
        <div className="flex items-center space-x-1.5 sm:space-x-2">
          {/* Hackathon Demo Tour Pill */}
          {onOpenDemoTour && (
            <button
              onClick={() => {
                soundManager.playClick();
                onOpenDemoTour();
              }}
              title="Launch Judges Hackathon Guided Demo Flow [D]"
              className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-[#C65B43]/15 border border-[#C65B43]/50 text-[#FF7B59] hover:bg-[#C65B43]/30 transition-all font-mono text-[11px] font-bold shadow-[0_0_15px_rgba(198,91,67,0.25)] cursor-pointer"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF7B59] animate-ping" />
              <span>DEMO [D]</span>
            </button>
          )}

          {/* ASTRA AI Button */}
          {onOpenAstra && (
            <button
              onClick={() => {
                soundManager.playClick();
                onOpenAstra();
              }}
              title="Open ASTRA AI Assistant [A]"
              className="px-2.5 sm:px-3 py-1.5 rounded-full bg-white/5 border border-white/10 hover:border-[#38BDF8] text-[#38BDF8] hover:bg-[#38BDF8]/10 transition-all font-mono text-[11px] flex items-center space-x-1.5 cursor-pointer"
            >
              <Bot size={13} />
              <span className="hidden sm:inline">ASTRA [A]</span>
            </button>
          )}

          {/* Flight Wings Certificate */}
          {onOpenCertificate && (
            <button
              onClick={() => {
                soundManager.playClick();
                onOpenCertificate();
              }}
              title="Print Flight Wings Certificate [C]"
              className="hidden md:flex items-center space-x-1 px-2.5 py-1.5 rounded-full bg-white/5 border border-white/10 hover:border-[#FBBF24] text-[#FBBF24] hover:bg-[#FBBF24]/10 transition-all font-mono text-[11px] cursor-pointer"
            >
              <Award size={13} />
              <span>WINGS [C]</span>
            </button>
          )}

          {/* Deep Space Soundscape Audio Toggle */}
          <button
            onClick={handleToggleAudio}
            title={isAudioActive ? 'Mute Deep Space Audio [M]' : 'Enable Deep Space Atmosphere & Audio [M]'}
            className={`p-2 rounded-full border transition-all flex items-center justify-center cursor-pointer ${
              isAudioActive
                ? 'bg-[#C65B43]/20 border-[#C65B43] text-white shadow-[0_0_15px_rgba(198,91,67,0.3)]'
                : 'bg-white/5 border-white/10 text-[#94A3B8] hover:text-white'
            }`}
          >
            {isAudioActive ? (
              <span className="flex space-x-0.5 items-end h-3 px-0.5">
                {freqBars.slice(0, 4).map((h, i) => (
                  <span
                    key={i}
                    className="w-0.5 bg-[#FF7B59] rounded-full transition-all duration-100"
                    style={{ height: `${Math.min(12, Math.max(3, h))}px` }}
                  />
                ))}
              </span>
            ) : (
              <VolumeX size={14} />
            )}
          </button>

          {/* Cadet Flight Authorization / Student Login Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              if (onOpenLogin) {
                onOpenLogin();
              } else if (onOpenAuth) {
                onOpenAuth();
              }
            }}
            title="Student Flight Login & Security Clearance Portal [L]"
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-[#38BDF8]/20 via-[#6366F1]/20 to-[#A855F7]/20 border border-[#38BDF8]/60 text-white hover:text-white hover:border-[#38BDF8] hover:bg-[#38BDF8]/30 transition-all font-mono text-[11px] font-bold shadow-[0_0_15px_rgba(56,189,248,0.3)] hover:shadow-[0_0_25px_rgba(56,189,248,0.6)] cursor-pointer"
          >
            <Shield size={13} className="text-[#38BDF8] animate-pulse" />
            <span className="hidden xs:inline tracking-wider">STUDENT LOGIN</span>
            <span className="xs:hidden">LOGIN</span>
          </button>

          {/* Primary CTA: Launch Flight Deck */}
          <button
            onClick={() => {
              soundManager.playLaunch();
              onLaunchSimulator();
            }}
            className="px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-full bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#C65B43] hover:brightness-110 text-white font-mono text-[11px] sm:text-xs font-bold tracking-wider flex items-center space-x-1.5 shadow-[0_0_20px_rgba(198,91,67,0.45)] hover:shadow-[0_0_30px_rgba(198,91,67,0.65)] transition-all cursor-pointer select-none"
          >
            <Play size={12} className="fill-current" />
            <span className="hidden xs:inline">FLIGHT DECK</span>
            <span className="xs:hidden">DECK</span>
          </button>

          {/* Mobile Hamburger Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-full bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? <X size={15} /> : <Menu size={15} />}
          </button>
        </div>
      </div>

      {/* Mobile Glassmorphic Overlay Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden pointer-events-auto mt-2 max-w-md mx-auto rounded-3xl bg-[#060B18]/95 backdrop-blur-2xl border border-white/15 p-5 shadow-2xl animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="grid grid-cols-2 gap-2 mb-4">
            {navLinks.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={(e) => handleLinkClick(e, item.href)}
                  className="flex items-center space-x-2 p-3 rounded-2xl bg-white/[0.04] border border-white/5 text-left text-xs font-mono text-white hover:bg-[#38BDF8]/10 hover:border-[#38BDF8]/30 transition-all"
                >
                  <Icon size={14} className="text-[#38BDF8]" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-3 border-t border-white/10 flex flex-col gap-2">
            <button
              onClick={() => {
                soundManager.playClick();
                setMobileMenuOpen(false);
                if (onOpenLogin) onOpenLogin();
                else if (onOpenAuth) onOpenAuth();
              }}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#38BDF8]/20 via-[#6366F1]/20 to-[#A855F7]/20 border border-[#38BDF8]/60 text-white font-mono text-xs font-bold flex items-center justify-center space-x-2 shadow-[0_0_15px_rgba(56,189,248,0.3)]"
            >
              <Shield size={14} className="text-[#38BDF8]" />
              <span>STUDENT LOGIN & CLEARANCE PORTAL</span>
            </button>

            {onOpenDemoTour && (
              <button
                onClick={() => {
                  soundManager.playClick();
                  setMobileMenuOpen(false);
                  onOpenDemoTour();
                }}
                className="w-full py-2.5 rounded-xl bg-[#C65B43]/20 border border-[#C65B43]/50 text-[#FF7B59] font-mono text-xs font-bold flex items-center justify-center space-x-2"
              >
                <Sparkles size={14} />
                <span>LAUNCH JUDGES DEMO TOUR [D]</span>
              </button>
            )}

            {onOpenCertificate && (
              <button
                onClick={() => {
                  soundManager.playClick();
                  setMobileMenuOpen(false);
                  onOpenCertificate();
                }}
                className="w-full py-2.5 rounded-xl bg-white/5 border border-white/10 text-[#FBBF24] font-mono text-xs font-bold flex items-center justify-center space-x-2"
              >
                <Award size={14} />
                <span>FLIGHT WINGS CERTIFICATE [C]</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
