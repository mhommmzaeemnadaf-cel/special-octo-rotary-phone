import React, { useState } from 'react';
import {
  Compass, ChevronRight, ChevronLeft, CheckCircle2, Play,
  X, Award, Sparkles, HelpCircle, ArrowRight
} from 'lucide-react';

export interface DemoStep {
  id: number;
  title: string;
  badge: string;
  desc: string;
  actionLabel: string;
  targetAction: () => void;
}

interface HackathonDemoTourProps {
  isOpen: boolean;
  onClose: () => void;
  onLaunchSimulator: () => void;
  onOpenCertificate: () => void;
  onNavigateSection: (sectionId: string) => void;
}

export default function HackathonDemoTour({
  isOpen,
  onClose,
  onLaunchSimulator,
  onOpenCertificate,
  onNavigateSection,
}: HackathonDemoTourProps) {
  const [currentStep, setCurrentStep] = useState<number>(1);

  if (!isOpen) return null;

  const DEMO_STEPS: DemoStep[] = [
    {
      id: 1,
      title: 'Welcome to ASTRONAUT-X',
      badge: 'OVERVIEW & SENSORS',
      desc: 'Experience the 3D WebGL Mars globe, live JPL weather telemetry, and astronaut recruitment briefing.',
      actionLabel: 'View Orbital Command',
      targetAction: () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
    },
    {
      id: 2,
      title: 'Interactive Solar System Orrery',
      badge: 'PLANETARY ORBITS',
      desc: 'Explore Keplerian orbits across 8 planets + the Sun with planetary atmospheres, radiometry, and NASA mission fleets.',
      actionLabel: 'Open Solar System',
      targetAction: () => {
        onNavigateSection('solar-system-explorer');
      },
    },
    {
      id: 3,
      title: 'Spaceflight Games Arcade (5 Sims)',
      badge: 'GAMES & PHYSICS',
      desc: 'Play DART asteroid deflection, Voyager gravity assist slingshots, and 6-DOF ISS station docking.',
      actionLabel: 'Launch Games Arcade',
      targetAction: () => {
        onNavigateSection('space-games-arcade');
      },
    },
    {
      id: 4,
      title: 'Enter the Astronaut Academy',
      badge: '10-STEP CURRICULUM',
      desc: 'Rigorous aerospace syllabus based on primary NASA research, orbital physics, and life support chemistry.',
      actionLabel: 'Open Academy',
      targetAction: () => {
        onNavigateSection('astronaut-academy');
      },
    },
    {
      id: 5,
      title: 'Take a Certified Knowledge Quiz',
      badge: 'QUIZ & FEEDBACK',
      desc: '5-question flight certification quiz with instant scoring, real physics explanations, and XP rewards.',
      actionLabel: 'Jump to Quiz',
      targetAction: () => {
        onNavigateSection('astronaut-academy');
      },
    },
    {
      id: 6,
      title: 'Explore Real NASA Media Library',
      badge: 'LIVE API INTEGRATION',
      desc: 'Search 140,000+ authentic NASA photos, rover panoramas, and manifest video streams from images-api.nasa.gov.',
      actionLabel: 'Open NASA Explorer',
      targetAction: () => {
        onNavigateSection('nasa-media-explorer');
      },
    },
    {
      id: 7,
      title: 'Play the Sky Crane EDL Simulator',
      badge: 'FLIGHT DECK',
      desc: 'Pilot retro-rockets during the 7 Minutes of Terror to land safely on Jezero Crater (<3.5 m/s touchdown).',
      actionLabel: 'Launch Flight Sim',
      targetAction: () => {
        onLaunchSimulator();
      },
    },
    {
      id: 8,
      title: 'Construct a Martian Colony Base',
      badge: 'HAB BUILDER',
      desc: 'Deploy solar arrays, Kilopower nuclear reactors, and Sabatier recyclers to balance O₂, water, and energy.',
      actionLabel: 'Open Base Builder',
      targetAction: () => {
        onNavigateSection('hab-builder');
      },
    },
    {
      id: 9,
      title: 'Rocket Propulsion Engineering Lab',
      badge: 'TSIOLKOVSKY EQUATION',
      desc: 'Select Merlin/Raptor engines, fuel masses, and staging to calculate Delta-V (Δv) and TWR for orbital launch.',
      actionLabel: 'Enter Rocket Lab',
      targetAction: () => {
        onNavigateSection('rocket-builder');
      },
    },
    {
      id: 10,
      title: 'Controlled Space Agriculture Biome',
      badge: 'CEA GREENHOUSE',
      desc: 'Calibrate LED photoperiods, temperature, and hydroponics to grow Martian crops and generate oxygen.',
      actionLabel: 'Enter Greenhouse',
      targetAction: () => {
        onNavigateSection('space-agriculture');
      },
    },
    {
      id: 11,
      title: 'Show Flight Wings Certificate',
      badge: 'HONORS & GAMIFICATION',
      desc: 'View unlocked XP badges, astronaut rank progression, and generate the museum-grade printable certificate.',
      actionLabel: 'View Flight Wings',
      targetAction: () => {
        onOpenCertificate();
      },
    },
  ];

  const current = DEMO_STEPS.find((s) => s.id === currentStep) || DEMO_STEPS[0];

  const handleNext = () => {
    if (currentStep < DEMO_STEPS.length) {
      const nextStepNum = currentStep + 1;
      setCurrentStep(nextStepNum);
      const nextStep = DEMO_STEPS.find((s) => s.id === nextStepNum);
      if (nextStep) nextStep.targetAction();
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      const prevStepNum = currentStep - 1;
      setCurrentStep(prevStepNum);
      const prevStep = DEMO_STEPS.find((s) => s.id === prevStepNum);
      if (prevStep) prevStep.targetAction();
    }
  };

  const handleSelectStep = (num: number) => {
    setCurrentStep(num);
    const step = DEMO_STEPS.find((s) => s.id === num);
    if (step) step.targetAction();
  };

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 max-w-4xl mx-auto animate-in slide-in-from-bottom duration-300">
      <div className="bg-[#0F172A]/95 backdrop-blur-xl border-2 border-[#C65B43]/70 rounded-2xl shadow-[0_0_40px_rgba(198,91,67,0.3)] p-4 sm:p-5 text-left text-white">
        {/* Top bar */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#C65B43] animate-ping" />
            <h4 className="font-display font-bold text-sm text-[#F5F1E8]">
              JUDGES HACKATHON DEMO TOUR — STEP {currentStep} OF {DEMO_STEPS.length}
            </h4>
          </div>

          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-[#C65B43]/20 text-[#FF7B59] border border-[#C65B43]/30">
              {current.badge}
            </span>
            <button
              onClick={onClose}
              aria-label="Exit Demo"
              className="p-1 rounded-lg bg-white/5 hover:bg-white/15 text-white/60 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Step details & Jump pills */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1 max-w-xl">
            <div className="font-display font-bold text-base text-white flex items-center space-x-2">
              <span>{current.title}</span>
            </div>
            <p className="text-xs text-[#9298A3] leading-relaxed">
              {current.desc}
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex items-center space-x-2 shrink-0 w-full sm:w-auto justify-end">
            <button
              onClick={handlePrev}
              disabled={currentStep === 1}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/15 disabled:opacity-30 text-white transition-all cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <button
              onClick={current.targetAction}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-mono text-xs flex items-center space-x-1.5 transition-all cursor-pointer border border-white/10"
            >
              <span>{current.actionLabel}</span>
              <ArrowRight className="w-3 h-3 text-[#38BDF8]" />
            </button>

            <button
              onClick={handleNext}
              disabled={currentStep === DEMO_STEPS.length}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#C65B43] to-[#E07A5F] hover:from-[#D76951] hover:to-[#EB896E] disabled:opacity-30 text-white font-display font-bold text-xs flex items-center space-x-1.5 transition-all cursor-pointer shadow"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stepper dots */}
        <div className="flex items-center justify-between pt-3 mt-3 border-t border-white/5 overflow-x-auto no-scrollbar gap-1.5">
          {DEMO_STEPS.map((s) => (
            <button
              key={s.id}
              onClick={() => handleSelectStep(s.id)}
              className={`h-1.5 flex-1 rounded-full transition-all cursor-pointer ${
                s.id === currentStep
                  ? 'bg-[#C65B43] ring-2 ring-[#C65B43]/50'
                  : s.id < currentStep
                  ? 'bg-[#34D399]'
                  : 'bg-white/10 hover:bg-white/30'
              }`}
              title={`Step ${s.id}: ${s.title}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
