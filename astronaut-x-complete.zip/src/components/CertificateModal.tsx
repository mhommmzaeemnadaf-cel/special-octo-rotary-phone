import React, { useRef } from 'react';
import {
  X, Award, Printer, Download, Sparkles, CheckCircle2,
  ShieldCheck, ShieldAlert, Star, Compass, Share2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useProgress, ALL_ACHIEVEMENTS } from '../context/ProgressContext';
import { NASA_DISCLAIMER_TEXT } from './NasaAttribution';

interface CertificateModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CertificateModal({ isOpen, onClose }: CertificateModalProps) {
  const { progress, rank } = useProgress();
  const certRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const unlockedAchList = ALL_ACHIEVEMENTS.filter((a) =>
    progress.unlockedAchievements.includes(a.id)
  );

  const formattedDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  // Unique deterministic verification hash
  const certId = `AX-${btoa(progress.callsign + progress.specialisation).slice(0, 8).toUpperCase()}-${progress.xp}`;

  const handlePrint = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
    window.print();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="cert-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl bg-[#0B1120] border border-white/20 rounded-2xl shadow-2xl p-6 sm:p-8 my-auto text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Controls */}
        <div className="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
          <div className="flex items-center space-x-2">
            <Award className="w-5 h-5 text-[#FBBF24]" />
            <h3 id="cert-title" className="font-display font-bold text-lg text-white">
              Official ASTRONAUT-X Flight Wings Certificate
            </h3>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#C65B43] hover:bg-[#D76951] text-white font-mono text-xs font-medium transition-all cursor-pointer shadow"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              aria-label="Close certificate"
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Certificate Canvas */}
        <div
          ref={certRef}
          className="relative p-8 sm:p-12 rounded-xl bg-gradient-to-b from-[#0F172A] to-[#070B14] border-2 border-[#FBBF24]/50 shadow-[0_0_50px_rgba(251,191,36,0.1)] text-center overflow-hidden"
        >
          {/* Ornate corner borders */}
          <div className="absolute top-3 left-3 w-6 h-6 border-t-2 border-l-2 border-[#FBBF24]" />
          <div className="absolute top-3 right-3 w-6 h-6 border-t-2 border-r-2 border-[#FBBF24]" />
          <div className="absolute bottom-3 left-3 w-6 h-6 border-b-2 border-l-2 border-[#FBBF24]" />
          <div className="absolute bottom-3 right-3 w-6 h-6 border-b-2 border-r-2 border-[#FBBF24]" />

          {/* Background watermark */}
          <div className="absolute inset-0 flex items-center justify-center opacity-5 pointer-events-none">
            <span className="font-display font-black text-9xl tracking-widest text-white">ASTRONAUT-X</span>
          </div>

          {/* Certificate Header */}
          <div className="relative z-10 space-y-2 mb-6">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#FBBF24]/10 border border-[#FBBF24]/30 text-[#FBBF24] font-mono text-xs uppercase tracking-widest">
              <Sparkles className="w-3.5 h-3.5" />
              <span>ASTRONAUT-X FLIGHT ACADEMY</span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-display font-extrabold text-[#F5F1E8] tracking-tight uppercase">
              Certificate of Spaceflight Excellence
            </h1>
            <p className="text-[#9298A3] font-mono text-xs tracking-wider">
              VERIFICATION RECORD NO. {certId}
            </p>
          </div>

          {/* Student Dossier */}
          <div className="relative z-10 space-y-4 my-8">
            <p className="text-xs sm:text-sm text-[#9298A3] uppercase tracking-widest font-mono">
              THIS DISTINCTION IS PROUDLY CONFERRED UPON
            </p>
            <div className="text-3xl sm:text-5xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-[#FBBF24] via-[#F5F1E8] to-[#C65B43] tracking-wide py-1">
              {progress.callsign || 'Cadet Aria Vance'}
            </div>
            <p className="max-w-xl mx-auto text-xs sm:text-sm text-white/80 leading-relaxed font-sans">
              having demonstrated outstanding scientific proficiency, orbital mechanics problem-solving,
              closed-loop life support operations, and planetary exploration leadership as a certified
            </p>
            <div className="inline-block px-4 py-1.5 rounded-lg bg-white/10 border border-white/20 text-[#38BDF8] font-mono text-sm font-bold tracking-wider uppercase">
              {progress.specialisation} — {rank.title} (Level {rank.level})
            </div>
          </div>

          {/* Unlocked Badges Row */}
          <div className="relative z-10 pt-4 border-t border-white/10 max-w-xl mx-auto mb-6">
            <div className="text-[10px] font-mono text-[#9298A3] uppercase tracking-wider mb-3">
              Certified Competencies & Flight Badges ({unlockedAchList.length} Unlocked • {progress.xp} Total XP)
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              {unlockedAchList.slice(0, 6).map((ach) => (
                <div
                  key={ach.id}
                  className="px-2.5 py-1 rounded-md bg-white/[0.04] border border-white/10 flex items-center space-x-1.5 text-xs text-white"
                >
                  <span>{ach.icon}</span>
                  <span className="font-mono text-[10px]">{ach.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Signatures & Seal */}
          <div className="relative z-10 grid grid-cols-3 items-end pt-6 border-t border-white/10 text-left text-xs font-mono">
            <div>
              <div className="text-[#9298A3] text-[10px] uppercase">Conferred Date</div>
              <div className="text-white font-medium">{formattedDate}</div>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-[#FBBF24]/10 border-2 border-[#FBBF24] flex items-center justify-center text-[#FBBF24] font-display font-black text-xl shadow-[0_0_20px_rgba(251,191,36,0.3)]">
                AX
              </div>
              <div className="text-[9px] text-[#FBBF24] tracking-widest uppercase mt-1">OFFICIAL SEAL</div>
            </div>

            <div className="text-right">
              <div className="text-[#9298A3] text-[10px] uppercase">Platform Director</div>
              <div className="text-white font-medium">ASTRONAUT-X FLIGHT DECK</div>
            </div>
          </div>

          {/* Mandatory NASA Educational Disclaimer */}
          <div className="relative z-10 mt-6 pt-4 border-t border-white/10 text-[10px] text-white/50 leading-relaxed font-sans text-center">
            <ShieldAlert className="w-3.5 h-3.5 inline mr-1 text-[#FBBF24] -mt-0.5" />
            <span>
              This certificate is issued exclusively by ASTRONAUT-X as an independent educational recognition.
              It is not an official NASA certification or government endorsement.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
