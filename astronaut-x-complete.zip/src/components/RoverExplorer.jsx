import React, { useState } from 'react';
import { Compass, Zap, Shield, Eye, Cpu, Wrench, Crosshair, ChevronRight } from 'lucide-react';
import { soundManager } from '../utils/audio';

const ROVER_SYSTEMS = [
  {
    id: 'mmrtg',
    name: 'MMRTG Nuclear Generator',
    category: 'POWER & THERMAL',
    icon: Zap,
    specs: '110W Electrical • 2,000W Thermal',
    desc: 'Multi-Mission Radioisotope Thermoelectric Generator converting decay heat of 4.8 kg Plutonium-238 dioxide into electrical energy, operating unaffected by global dust storms and polar night.',
    coords: { x: '18%', y: '48%' },
    telemetry: 'OUTPUT: 108.4 W • CORE TEMP: 485°C • FUEL LIFE: 14+ YEARS',
  },
  {
    id: 'mastcam',
    name: 'Mastcam-Z & SuperCam Laser',
    category: 'OPTICAL RECONNAISSANCE',
    icon: Eye,
    specs: '2 Megapixel 3D Stereo • 110mm Zoom',
    desc: 'Stereoscopic multispectral imaging mast paired with SuperCam laser-induced breakdown spectroscopy (LIBS), firing infrared laser pulses to vaporize mineral targets at 7 meters distance.',
    coords: { x: '72%', y: '24%' },
    telemetry: 'ZOOM RATIO: 3.8:1 • LASER PULSE: 1064 nm • TARGET FOCUS: 4.8 m',
  },
  {
    id: 'suspension',
    name: 'Rocker-Bogie Mobility System',
    category: 'LOCOMOTION & TERRAIN',
    icon: Compass,
    specs: '6-Wheel Independent Drive • 0.38g Optimized',
    desc: 'Patented NASA kinematic linkage mechanism that maintains equal ground pressure on all six machined aluminum wheels, allowing the rover to climb over obstacles larger than wheel diameter without tipping.',
    coords: { x: '45%', y: '78%' },
    telemetry: 'TRAVERSE VELOCITY: 0.12 km/h • WHEEL TORQUE: 180 Nm • SLIP: 2.1%',
  },
  {
    id: 'moxie',
    name: 'MOXIE ISRU Unit',
    category: 'ATMOSPHERE & LIFE SUPPORT',
    icon: Shield,
    specs: 'Solid Oxide Electrolysis • 800°C Core',
    desc: 'The Mars Oxygen ISRU Experiment splits atmospheric CO₂ into breathable O₂ and carbon monoxide waste gas, demonstrating foundational resource production for human expedition return missions.',
    coords: { x: '42%', y: '42%' },
    telemetry: 'O₂ PRODUCTION: 12.0 g/h • PURITY: 99.6% • POWER DRAW: 300 W',
  },
  {
    id: 'arm',
    name: 'Robotic Coring Drill Arm',
    category: 'GEOCHEMISTRY & CACHING',
    icon: Wrench,
    specs: '5-DOF Articulation • 2.1m Reach',
    desc: 'Heavy-duty robotic turret holding a rotary-percussive coring drill, dust removal tool (gDRT), and SHERLOC UV Raman spectrometer to collect and hermetically seal core samples into ultra-clean titanium tubes.',
    coords: { x: '82%', y: '62%' },
    telemetry: 'TUBES SEALED: 24/43 • BIT SPEED: 3000 RPM • DRILL DEPTH: 76 mm',
  },
  {
    id: 'avionics',
    name: 'Radiation-Hardened BAE RAD750',
    category: 'AUTONOMOUS NAVIGATION',
    icon: Cpu,
    specs: '133 MHz PowerPC • AutoNav FPGA',
    desc: 'Dual redundant radiation-hardened central computing flight computers executing AutoNav stereo vision algorithms, allowing real-time autonomous boulder avoidance across Jezero delta.',
    coords: { x: '52%', y: '32%' },
    telemetry: 'BUS UTILIZATION: 34% • MEMORY: 512 MB DRAM • REBOOTS: 0',
  },
];

export default function RoverExplorer() {
  const [activeSystemId, setActiveSystemId] = useState('moxie');
  const activeSystem = ROVER_SYSTEMS.find((s) => s.id === activeSystemId) || ROVER_SYSTEMS[0];

  const handleSelectSystem = (id) => {
    soundManager.playClick();
    setActiveSystemId(id);
  };

  return (
    <section className="py-24 bg-[#080B12] border-t border-white/5 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center space-x-3 text-xs font-mono tracking-widest text-[#C65B43] uppercase mb-4">
              <span>EXPLORATION FLEET // HARDWARE ARCHIVE</span>
            </div>
            <h2 className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-[#F5F1E8] uppercase">
              EXPEDITIONARY ROVER SCHEMATICS
            </h2>
          </div>
          <p className="max-w-md text-sm text-[#9298A3] font-light leading-relaxed">
            Engineered to endure 100°C diurnal thermal shocks, abrasive perchlorate dust, and unpaved boulder fields across the ancient Jezero river delta.
          </p>
        </div>

        {/* Blueprint Interactive Display Area */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-12">
          {/* Left Column: Interactive Rover Schematic Graphic */}
          <div className="lg:col-span-7 relative h-[420px] rounded-3xl bg-[#101827] border border-white/10 overflow-hidden p-6 flex items-center justify-center shadow-2xl">
            {/* Blueprint Grid Lines Overlay */}
            <div className="absolute inset-0 telemetry-grid opacity-30 pointer-events-none" />

            {/* Stylized Vector Rover Schematic Representation */}
            <svg
              className="w-full h-full max-h-[340px] opacity-90"
              viewBox="0 0 600 400"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Rover Main Chassis Body */}
              <rect x="180" y="160" width="220" height="90" rx="12" fill="#162235" stroke="#C65B43" strokeWidth="2" />
              <rect x="200" y="140" width="160" height="25" rx="6" fill="#1C2C45" stroke="#38BDF8" strokeWidth="1.5" />

              {/* Mastcam Tower */}
              <line x1="390" y1="160" x2="420" y2="70" stroke="#F5F1E8" strokeWidth="3" />
              <rect x="405" y="55" width="35" height="25" rx="4" fill="#162235" stroke="#F5F1E8" strokeWidth="2" />
              <circle cx="417" cy="67" r="5" fill="#38BDF8" />
              <circle cx="430" cy="67" r="4" fill="#C65B43" />

              {/* Robotic Arm Turret */}
              <path d="M 400 220 L 460 250 L 510 230 L 525 255" stroke="#F5F1E8" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
              <circle cx="525" cy="255" r="9" fill="#C65B43" stroke="#F5F1E8" strokeWidth="1.5" />

              {/* MMRTG Cylindrical Tail */}
              <rect x="100" y="170" width="80" height="45" rx="6" fill="#162235" stroke="#FBBF24" strokeWidth="2" />
              <line x1="120" y1="170" x2="120" y2="215" stroke="#FBBF24" strokeWidth="1" />
              <line x1="140" y1="170" x2="140" y2="215" stroke="#FBBF24" strokeWidth="1" />
              <line x1="160" y1="170" x2="160" y2="215" stroke="#FBBF24" strokeWidth="1" />

              {/* Rocker Bogie Suspension Struts */}
              <path d="M 220 230 L 150 280 L 120 320" stroke="#F5F1E8" strokeWidth="3" strokeLinecap="round" />
              <path d="M 150 280 L 220 320" stroke="#F5F1E8" strokeWidth="3" strokeLinecap="round" />
              <path d="M 360 230 L 430 320" stroke="#F5F1E8" strokeWidth="3" strokeLinecap="round" />

              {/* Titanium Machined Wheels */}
              <circle cx="120" cy="320" r="26" fill="#0E1726" stroke="#38BDF8" strokeWidth="3" />
              <circle cx="220" cy="320" r="26" fill="#0E1726" stroke="#38BDF8" strokeWidth="3" />
              <circle cx="430" cy="320" r="26" fill="#0E1726" stroke="#38BDF8" strokeWidth="3" />

              {/* Tread cleat details */}
              <circle cx="120" cy="320" r="14" stroke="#9298A3" strokeWidth="1" strokeDasharray="3 3" />
              <circle cx="220" cy="320" r="14" stroke="#9298A3" strokeWidth="1" strokeDasharray="3 3" />
              <circle cx="430" cy="320" r="14" stroke="#9298A3" strokeWidth="1" strokeDasharray="3 3" />
            </svg>

            {/* Interactive Hotspot Buttons directly over Schematic */}
            {ROVER_SYSTEMS.map((sys) => {
              const isSelected = activeSystemId === sys.id;
              return (
                <button
                  key={sys.id}
                  onClick={() => handleSelectSystem(sys.id)}
                  style={{ top: sys.coords.y, left: sys.coords.x }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 p-1.5 rounded-full border transition-all z-20 group ${
                    isSelected
                      ? 'bg-[#C65B43] border-white scale-125 shadow-[0_0_20px_#C65B43]'
                      : 'bg-[#101827] border-[#C65B43]/70 hover:scale-110 hover:border-white'
                  }`}
                  title={sys.name}
                >
                  <Crosshair
                    size={15}
                    className={`transition-colors ${
                      isSelected ? 'text-white' : 'text-[#C65B43] group-hover:text-white'
                    }`}
                  />
                </button>
              );
            })}

            {/* Bottom Blueprint Watermark */}
            <div className="absolute bottom-4 left-6 text-[10px] font-mono text-[#9298A3]/70">
              NASA JPL DWG NO. 2026-MR-ECLSS • SCALE 1:20 • HIGH GAIN LINK: VERIFIED
            </div>
          </div>

          {/* Right Column: Selected System Deep-Dive Panel */}
          <div className="lg:col-span-5 p-8 rounded-3xl bg-[#101827] border border-white/10 shadow-xl relative overflow-hidden">
            <span className="text-[10px] font-mono tracking-widest text-[#C65B43] uppercase mb-2 block">
              {activeSystem.category}
            </span>
            <h3 className="font-display text-2xl sm:text-3xl font-bold text-[#F5F1E8] mb-3">
              {activeSystem.name}
            </h3>

            <div className="p-3.5 rounded-xl bg-[#080B12] border border-white/5 text-xs font-mono text-[#38BDF8] mb-6">
              SPECIFICATION: {activeSystem.specs}
            </div>

            <p className="text-xs text-[#9298A3] leading-relaxed mb-6 font-light">
              {activeSystem.desc}
            </p>

            {/* Telemetry Readout */}
            <div className="p-4 rounded-xl bg-[#080B12] border border-[#C65B43]/30 mb-6">
              <div className="text-[10px] font-mono text-[#9298A3] uppercase mb-1">
                REAL-TIME HARDWARE TELEMETRY
              </div>
              <div className="font-mono text-xs text-[#34D399] font-bold">
                {activeSystem.telemetry}
              </div>
            </div>

            {/* System Switcher Grid */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10">
              {ROVER_SYSTEMS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => handleSelectSystem(s.id)}
                  className={`px-3 py-2 rounded-lg text-left text-xs font-mono truncate transition-all ${
                    activeSystemId === s.id
                      ? 'bg-[#C65B43] text-white font-semibold'
                      : 'bg-white/5 hover:bg-white/10 text-[#9298A3]'
                  }`}
                >
                  {s.name.split(' ')[0]} {s.name.split(' ')[1] || ''}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
