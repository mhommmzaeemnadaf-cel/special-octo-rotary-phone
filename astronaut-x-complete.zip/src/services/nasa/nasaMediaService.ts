/**
 * ASTRONAUT-X — Official NASA Image and Video Library Service
 * API Docs: https://images.nasa.gov/docs/images.nasa.gov_api_docs.pdf
 * Base URL: https://images-api.nasa.gov
 */

const NASA_IMAGES_API = "https://images-api.nasa.gov";

export interface NasaMediaItem {
  nasaId: string;
  title: string;
  description: string;
  dateCreated?: string;
  mediaType: "image" | "video" | "audio";
  thumbnail: string;
  nasaCenter?: string;
  photographer?: string;
  keywords?: string[];
  nasaUrl: string;
  isBundledFallback?: boolean;
}

export interface NasaAssetManifest {
  nasaId: string;
  assets: string[];
  playableVideo?: string | null;
  highResImage?: string | null;
  captionsUrl?: string | null;
}

// In-Memory & LocalStorage Cache with 1-hour TTL
const CACHE_TTL_MS = 60 * 60 * 1000;
const memoryCache = new Map<string, { timestamp: number; data: any }>();

function getCached<T>(key: string): T | null {
  // Check memory cache
  const mem = memoryCache.get(key);
  if (mem && Date.now() - mem.timestamp < CACHE_TTL_MS) {
    return mem.data as T;
  }
  // Check localStorage cache
  try {
    const raw = localStorage.getItem(`nasa_cache_${key}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Date.now() - parsed.timestamp < CACHE_TTL_MS) {
        memoryCache.set(key, parsed);
        return parsed.data as T;
      } else {
        localStorage.removeItem(`nasa_cache_${key}`);
      }
    }
  } catch {
    // LocalStorage quota or access error handled gracefully
  }
  return null;
}

function setCache<T>(key: string, data: T): void {
  const entry = { timestamp: Date.now(), data };
  memoryCache.set(key, entry);
  try {
    localStorage.setItem(`nasa_cache_${key}`, JSON.stringify(entry));
  } catch {
    // Ignore storage write issues
  }
}

/**
 * Curated offline fallback dataset featuring authentic NASA images & videos
 * Used when network is offline, rate-limited, or blocked.
 */
export const BUNDLED_NASA_FALLBACK: NasaMediaItem[] = [
  {
    nasaId: "PIA23764",
    title: "Perseverance Rover Touching Down on Mars (Sky Crane)",
    description: "NASA's Perseverance Mars rover is lowered from the Sky Crane descent stage onto the surface of Mars in Jezero Crater on Feb. 18, 2021. This high-resolution still was captured by one of the cameras on the descent stage as the rover hung just meters above the Martian regolith.",
    dateCreated: "2021-02-19T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/PIA23764/PIA23764~thumb.jpg",
    nasaCenter: "JPL",
    photographer: "NASA/JPL-Caltech",
    keywords: ["Perseverance", "Mars 2020", "EDL", "Sky Crane", "Jezero Crater", "Mars"],
    nasaUrl: "https://images.nasa.gov/details/PIA23764",
    isBundledFallback: true
  },
  {
    nasaId: "PIA24482",
    title: "Ingenuity Mars Helicopter Sol 39 Flight",
    description: "NASA's Ingenuity Mars Helicopter captured during powered flight through the thin Martian atmosphere. Demonstrating the first powered, controlled aerodynamic flight on another planet.",
    dateCreated: "2021-04-19T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/PIA24482/PIA24482~thumb.jpg",
    nasaCenter: "JPL",
    photographer: "NASA/JPL-Caltech",
    keywords: ["Ingenuity", "Helicopter", "Flight", "Mars", "Atmosphere"],
    nasaUrl: "https://images.nasa.gov/details/PIA24482",
    isBundledFallback: true
  },
  {
    nasaId: "PIA24925",
    title: "Curiosity Rover Exploring Mount Sharp Clay Units",
    description: "NASA's Curiosity Mars rover took this 360-degree selfie on Mount Sharp within Gale Crater, showing ancient clay-bearing rock layers that hold clues to Mars' wet, watery past billions of years ago.",
    dateCreated: "2021-11-20T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/PIA24925/PIA24925~thumb.jpg",
    nasaCenter: "JPL",
    photographer: "NASA/JPL-Caltech/MSSS",
    keywords: ["Curiosity", "Gale Crater", "Mount Sharp", "Rover", "Mars Geology"],
    nasaUrl: "https://images.nasa.gov/details/PIA24925",
    isBundledFallback: true
  },
  {
    nasaId: "ARTEMIS-I-EARTH-MOON",
    title: "Artemis I Orion Spacecraft Earth & Moon View",
    description: "Orion captured this stunning image of Earth and the Moon together while completing its distant retrograde orbit during the uncrewed Artemis I flight test in deep space.",
    dateCreated: "2022-11-28T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/art001e000672/art001e000672~thumb.jpg",
    nasaCenter: "JSC",
    photographer: "NASA",
    keywords: ["Artemis", "Orion", "Moon", "Earth", "Deep Space"],
    nasaUrl: "https://images.nasa.gov/details/art001e000672",
    isBundledFallback: true
  },
  {
    nasaId: "AS11-40-5903",
    title: "Apollo 11 Buzz Aldrin on the Lunar Surface",
    description: "Astronaut Buzz Aldrin walks on the surface of the Moon near the leg of the Lunar Module Eagle during the historic Apollo 11 mission on July 20, 1969. Photographed by Neil Armstrong.",
    dateCreated: "1969-07-20T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/as11-40-5903/as11-40-5903~thumb.jpg",
    nasaCenter: "JSC",
    photographer: "Neil Armstrong / NASA",
    keywords: ["Apollo 11", "Moon", "Astronaut", "Lunar", "Historic"],
    nasaUrl: "https://images.nasa.gov/details/as11-40-5903",
    isBundledFallback: true
  },
  {
    nasaId: "ISS065-E-000456",
    title: "Spacewalk Outside the International Space Station",
    description: "Flight Engineer conducts an Extravehicular Activity (EVA) spacewalk 260 miles above Earth, installing solar array modification kits to augment the ISS power grid.",
    dateCreated: "2021-06-16T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/iss065e000456/iss065e000456~thumb.jpg",
    nasaCenter: "JSC",
    photographer: "NASA Astronaut",
    keywords: ["ISS", "Spacewalk", "EVA", "Space Station", "Earth Orbit"],
    nasaUrl: "https://images.nasa.gov/details/iss065e000456",
    isBundledFallback: true
  },
  {
    nasaId: "weic2208a",
    title: "James Webb Space Telescope: Carina Nebula 'Cosmic Cliffs'",
    description: "NASA's James Webb Space Telescope reveals emerging stellar nurseries and individual stars in the Carina Nebula previously obscured by cosmic dust, captured in near-infrared light with MIRI and NIRCam.",
    dateCreated: "2022-07-12T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/weic2208a/weic2208a~thumb.jpg",
    nasaCenter: "GSFC",
    photographer: "NASA, ESA, CSA, STScI",
    keywords: ["JWST", "James Webb", "Carina Nebula", "Star Formation", "Infrared"],
    nasaUrl: "https://images.nasa.gov/details/weic2208a",
    isBundledFallback: true
  },
  {
    nasaId: "hubble_pillars_creation",
    title: "Hubble Space Telescope: Pillars of Creation",
    description: "NASA's Hubble Space Telescope revisited the iconic Pillars of Creation in the Eagle Nebula (M16), showing towering columns of cold gas and dust where newborn stars are being formed.",
    dateCreated: "2015-01-05T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/GSFC_20171208_Archive_e001435/GSFC_20171208_Archive_e001435~thumb.jpg",
    nasaCenter: "GSFC",
    photographer: "NASA, ESA, and the Hubble Heritage Team (STScI/AURA)",
    keywords: ["Hubble", "Pillars of Creation", "Eagle Nebula", "Deep Space", "Astronomy"],
    nasaUrl: "https://images.nasa.gov/details/GSFC_20171208_Archive_e001435",
    isBundledFallback: true
  },
  {
    nasaId: "GSFC_20171208_Archive_e001920",
    title: "The Blue Marble: Next Generation Earth",
    description: "NASA composite image of Earth created from observations collected by the Moderate Resolution Imaging Spectroradiometer (MODIS) aboard NASA's Terra satellite.",
    dateCreated: "2002-02-08T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/GSFC_20171208_Archive_e001920/GSFC_20171208_Archive_e001920~thumb.jpg",
    nasaCenter: "GSFC",
    photographer: "NASA Goddard Space Flight Center",
    keywords: ["Earth", "Blue Marble", "Terra", "MODIS", "Oceans", "Atmosphere"],
    nasaUrl: "https://images.nasa.gov/details/GSFC_20171208_Archive_e001920",
    isBundledFallback: true
  },
  {
    nasaId: "KSC-20221116-PH-KLS01_0001",
    title: "Artemis I SLS Moon Rocket Night Launch",
    description: "NASA's Space Launch System (SLS) rocket carrying the Orion spacecraft lifts off from Launch Complex 39B at NASA's Kennedy Space Center in Florida, generating 8.8 million pounds of thrust.",
    dateCreated: "2022-11-16T00:00:00Z",
    mediaType: "image",
    thumbnail: "https://images-assets.nasa.gov/image/KSC-20221116-PH-KLS01_0001/KSC-20221116-PH-KLS01_0001~thumb.jpg",
    nasaCenter: "KSC",
    photographer: "NASA/Keegan Barber",
    keywords: ["SLS", "Artemis", "Rocket", "Launch", "Propulsion", "Kennedy Space Center"],
    nasaUrl: "https://images.nasa.gov/details/KSC-20221116-PH-KLS01_0001",
    isBundledFallback: true
  },
  {
    nasaId: "NHQ202102180001",
    title: "Mars 2020 Perseverance Entry, Descent, and Landing Video",
    description: "Broadcast stream telemetry and high-frame-rate engineering camera capture of NASA's Mars 2020 Perseverance Rover landing on Mars.",
    dateCreated: "2021-02-18T00:00:00Z",
    mediaType: "video",
    thumbnail: "https://images-assets.nasa.gov/video/NHQ202102180001/NHQ202102180001~thumb.jpg",
    nasaCenter: "HQ",
    photographer: "NASA",
    keywords: ["Mars", "Landing", "Video", "EDL", "Perseverance"],
    nasaUrl: "https://images.nasa.gov/details/NHQ202102180001",
    isBundledFallback: true
  },
  {
    nasaId: "JSC-2021-M0001",
    title: "Life Aboard the International Space Station",
    description: "Expedition crew members conduct advanced fluid physics research, microgravity crystallization, and daily exercise routines in Earth orbit.",
    dateCreated: "2021-04-12T00:00:00Z",
    mediaType: "video",
    thumbnail: "https://images-assets.nasa.gov/image/iss064e001234/iss064e001234~thumb.jpg",
    nasaCenter: "JSC",
    photographer: "NASA",
    keywords: ["ISS", "Microgravity", "Science", "Astronauts", "Life Support"],
    nasaUrl: "https://images.nasa.gov/details/iss064e001234",
    isBundledFallback: true
  }
];

/**
 * Perform search against NASA Image and Video Library
 * Includes 8-second request timeout, query caching, structure validation, and fallback
 */
export async function searchNasaMedia(
  query: string,
  mediaType: "image" | "video" | "audio" | "image,video" = "image",
  page = 1,
  pageSize = 20,
  abortSignal?: AbortSignal
): Promise<{ items: NasaMediaItem[]; isFallback: boolean; totalHits: number }> {
  const sanitizedQuery = (query || "mars").trim().toLowerCase();
  const cacheKey = `search_${sanitizedQuery}_${mediaType}_p${page}_s${pageSize}`;

  const cached = getCached<{ items: NasaMediaItem[]; isFallback: boolean; totalHits: number }>(cacheKey);
  if (cached) {
    return cached;
  }

  const params = new URLSearchParams({
    q: sanitizedQuery,
    media_type: mediaType,
    page: String(Math.max(1, page)),
    page_size: String(pageSize)
  });

  const url = `${NASA_IMAGES_API}/search?${params.toString()}`;

  // Create an internal timeout signal if none provided
  const timeoutController = new AbortController();
  const timeoutId = setTimeout(() => timeoutController.abort(), 8500);

  // Link caller signal if provided
  if (abortSignal) {
    abortSignal.addEventListener("abort", () => timeoutController.abort());
  }

  try {
    const response = await fetch(url, { signal: timeoutController.signal });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`NASA API returned HTTP ${response.status}`);
    }

    const result = await response.json();
    const rawItems = result?.collection?.items;

    if (!Array.isArray(rawItems)) {
      throw new Error("Invalid NASA API response payload format");
    }

    const items: NasaMediaItem[] = rawItems
      .map((item: any): NasaMediaItem | null => {
        const data = item.data?.[0];
        if (!data || !data.nasa_id) return null;

        // Find thumbnail safely
        const links = Array.isArray(item.links) ? item.links : [];
        const thumbLink = links.find((l: any) => l.render === "image" || l.rel === "preview")?.href;
        
        // Sanitize thumbnail URL to https
        const secureThumb = thumbLink ? thumbLink.replace(/^http:\/\//i, "https://") : "";

        // Safe description
        const rawDesc = data.description_508 || data.description || "";
        const description = rawDesc.trim().length > 0
          ? rawDesc
          : "No detailed description provided by NASA archival record.";

        return {
          nasaId: String(data.nasa_id),
          title: data.title || "NASA Archived Asset",
          description,
          dateCreated: data.date_created,
          mediaType: (data.media_type as "image" | "video" | "audio") || "image",
          thumbnail: secureThumb,
          nasaCenter: data.center || "NASA",
          photographer: data.photographer || data.secondary_creator || undefined,
          keywords: Array.isArray(data.keywords) ? data.keywords : [],
          nasaUrl: `https://images.nasa.gov/details/${encodeURIComponent(data.nasa_id)}`,
          isBundledFallback: false
        };
      })
      .filter((item): item is NasaMediaItem => item !== null && (item.thumbnail !== "" || item.mediaType === "video"));

    const totalHits = result.collection?.metadata?.total_hits || items.length;
    const finalResult = { items, isFallback: false, totalHits };

    if (items.length > 0) {
      setCache(cacheKey, finalResult);
      return finalResult;
    }

    // If query returned zero items, provide relevant filtered fallbacks
    const fallbackFiltered = BUNDLED_NASA_FALLBACK.filter(b => 
      b.title.toLowerCase().includes(sanitizedQuery) ||
      b.description.toLowerCase().includes(sanitizedQuery) ||
      b.keywords?.some(k => k.toLowerCase().includes(sanitizedQuery))
    );

    return {
      items: fallbackFiltered.length > 0 ? fallbackFiltered : BUNDLED_NASA_FALLBACK.slice(0, 8),
      isFallback: true,
      totalHits: fallbackFiltered.length || BUNDLED_NASA_FALLBACK.length
    };
  } catch (err: any) {
    clearTimeout(timeoutId);
    console.warn("[NASA API] Search request failed or timed out, activating curated NASA archive:", err.message);

    // Fallback search across bundled assets
    const filtered = BUNDLED_NASA_FALLBACK.filter(b => {
      const matchMedia = mediaType.includes(b.mediaType);
      const matchQuery =
        sanitizedQuery === "" ||
        b.title.toLowerCase().includes(sanitizedQuery) ||
        b.keywords?.some(k => k.toLowerCase().includes(sanitizedQuery));
      return matchMedia || matchQuery;
    });

    const fallbackList = filtered.length > 0 ? filtered : BUNDLED_NASA_FALLBACK;
    return {
      items: fallbackList,
      isFallback: true,
      totalHits: fallbackList.length
    };
  }
}

/**
 * Retrieve asset manifest for a given NASA ID to extract media URLs (.mp4, .webm, high-res .jpg)
 */
export async function getNasaAssetManifest(
  nasaId: string,
  abortSignal?: AbortSignal
): Promise<string[]> {
  if (!nasaId || typeof nasaId !== "string") {
    return [];
  }

  const cacheKey = `manifest_${nasaId}`;
  const cached = getCached<string[]>(cacheKey);
  if (cached) return cached;

  const url = `${NASA_IMAGES_API}/asset/${encodeURIComponent(nasaId)}`;

  const timeoutController = new AbortController();
  const timeoutId = setTimeout(() => timeoutController.abort(), 7000);

  if (abortSignal) {
    abortSignal.addEventListener("abort", () => timeoutController.abort());
  }

  try {
    const response = await fetch(url, { signal: timeoutController.signal });
    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`NASA asset manifest returned HTTP ${response.status}`);
    }

    const result = await response.json();
    const rawItems = result?.collection?.items;

    if (!Array.isArray(rawItems)) {
      return [];
    }

    const assets = rawItems
      .map((item: any) => (typeof item?.href === "string" ? item.href.replace(/^http:\/\//i, "https://") : ""))
      .filter((href: string) => {
        if (!href) return false;
        const lower = href.toLowerCase();
        return (
          lower.endsWith(".mp4") ||
          lower.endsWith(".webm") ||
          lower.endsWith(".jpg") ||
          lower.endsWith(".jpeg") ||
          lower.endsWith(".png") ||
          lower.endsWith(".vtt") ||
          lower.endsWith(".srt")
        );
      });

    setCache(cacheKey, assets);
    return assets;
  } catch (err: any) {
    clearTimeout(timeoutId);
    console.warn(`[NASA API] Could not fetch manifest for ${nasaId}:`, err.message);
    return [];
  }
}

/**
 * Locate best playable video URL from asset manifest
 * Prefers medium/orig MP4, falls back to webm
 */
export async function getNasaVideoUrl(
  nasaId: string,
  abortSignal?: AbortSignal
): Promise<string | null> {
  const assets = await getNasaAssetManifest(nasaId, abortSignal);
  if (!assets.length) return null;

  // Prefer mobile or medium sized MP4 to prevent buffering huge multi-gigabyte video files
  const mediumMp4 = assets.find(url => {
    const lower = url.toLowerCase();
    return lower.endsWith("~medium.mp4") || lower.endsWith("~mobile.mp4");
  });
  if (mediumMp4) return mediumMp4;

  const anyMp4 = assets.find(url => url.toLowerCase().endsWith(".mp4"));
  if (anyMp4) return anyMp4;

  const webm = assets.find(url => url.toLowerCase().endsWith(".webm"));
  return webm || null;
}

/**
 * Retrieve high-resolution image URL from asset manifest
 */
export async function getNasaHighResImage(
  nasaId: string,
  abortSignal?: AbortSignal
): Promise<string | null> {
  const assets = await getNasaAssetManifest(nasaId, abortSignal);
  if (!assets.length) return null;

  // Prefer large/orig jpg
  const largeJpg = assets.find(url => {
    const lower = url.toLowerCase();
    return lower.endsWith("~large.jpg") || lower.endsWith("~orig.jpg");
  });
  if (largeJpg) return largeJpg;

  const anyJpg = assets.find(url => {
    const lower = url.toLowerCase();
    return lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png");
  });
  return anyJpg || null;
}

/**
 * Retrieve NASA metadata details
 */
export async function getNasaMetadata(
  nasaId: string,
  abortSignal?: AbortSignal
): Promise<Record<string, any> | null> {
  if (!nasaId) return null;
  const cacheKey = `metadata_${nasaId}`;
  const cached = getCached<Record<string, any>>(cacheKey);
  if (cached) return cached;

  const url = `${NASA_IMAGES_API}/metadata/${encodeURIComponent(nasaId)}`;
  try {
    const response = await fetch(url, { signal: abortSignal });
    if (!response.ok) return null;
    const result = await response.json();
    const metaUrl = result?.location;
    if (metaUrl) {
      const metaRes = await fetch(metaUrl);
      if (metaRes.ok) {
        const metaData = await metaRes.json();
        setCache(cacheKey, metaData);
        return metaData;
      }
    }
  } catch (err: any) {
    console.warn(`[NASA API] Metadata fetch error for ${nasaId}:`, err.message);
  }
  return null;
}

/**
 * Retrieve video captions/subtitles (.vtt / .srt)
 */
export async function getNasaCaptions(
  nasaId: string,
  abortSignal?: AbortSignal
): Promise<string | null> {
  const assets = await getNasaAssetManifest(nasaId, abortSignal);
  const captionFile = assets.find(url => {
    const lower = url.toLowerCase();
    return lower.endsWith(".vtt") || lower.endsWith(".srt");
  });
  return captionFile || null;
}
