/**
 * NASA Mars Trek Portal & Planetary Elevation Data Service
 * Official Portal: https://trek.nasa.gov/mars/
 * 
 * Provides interactive coordinate bookmarks, MOLA (Mars Orbiter Laser Altimeter)
 * elevation profiles, landing site hazards, and direct Trek map deep-links for
 * real Martian environmental & outpost site evaluation.
 */

export interface MarsTrekLocation {
  id: string;
  name: string;
  subheading: string;
  lat: number; // degrees North (positive) or South (negative)
  lon: number; // degrees East (0-360)
  elevationMeters: number; // relative to Mars datum (MOLA)
  atmosphericPressurePascals: number; // approx surface pressure
  temperatureRangeC: [number, number]; // [min, max]
  terrainType: string;
  missionConnection: string;
  scientificValue: string;
  outpostFeasibilityScore: number; // 0 to 100
  outpostPros: string[];
  outpostCons: string[];
  trekDirectUrl: string;
  hiRiseObservationId?: string;
}

export const MARS_TREK_LOCATIONS: MarsTrekLocation[] = [
  {
    id: 'jezero-delta',
    name: 'Jezero Crater Delta',
    subheading: 'Perseverance Rover Sample Caching Site',
    lat: 18.38,
    lon: 77.58,
    elevationMeters: -2530,
    atmosphericPressurePascals: 710,
    temperatureRangeC: [-90, -10],
    terrainType: 'Fluvial-lacustrine sedimentary fan & crater floor',
    missionConnection: 'Mars 2020 Perseverance Rover & Ingenuity Helicopter',
    scientificValue: 'Ancient lakebed sediments rich in smectite clays and carbonates capable of preserving biosignatures from 3.7 billion years ago.',
    outpostFeasibilityScore: 78,
    outpostPros: ['Dense atmospheric cushion (-2.5 km elevation increases entry mass margin)', 'Abundant carbonate minerals for ISRU construction', 'Accessible flat landing ellipse on crater floor'],
    outpostCons: ['Scarce shallow water ice compared to high latitudes', 'Rugged delta scarps present vehicle mobility choke points'],
    trekDirectUrl: 'https://trek.nasa.gov/mars/#v=0.1&x=77.58&y=18.38&z=6&p=urn%3Aogc%3Adef%3Acrs%3AEPSG%3A%3A104905&d=',
    hiRiseObservationId: 'ESP_037267_1985',
  },
  {
    id: 'arcadia-planitia',
    name: 'Arcadia Planitia (Ice Sheet Haven)',
    subheading: 'Prime Candidate for Human Martian Outpost',
    lat: 39.3,
    lon: 189.7,
    elevationMeters: -4100,
    atmosphericPressurePascals: 790,
    temperatureRangeC: [-110, -20],
    terrainType: 'Flat volcanic smooth plains with patterned ground permafrost',
    missionConnection: 'Mars Reconnaissance Orbiter (SHARAD radar detection of sheet ice)',
    scientificValue: 'Extensive, pure subsurface water ice glaciers buried only 1 to 2.5 meters below the desiccated regolith dust mantle.',
    outpostFeasibilityScore: 94,
    outpostPros: [
      'Direct access to thousands of tons of potable water ice for propellant (LOX/CH4) synthesis',
      'Ultra-flat terrain with virtually zero rock hazards for automated cargo landers',
      'Thickest atmospheric column on Mars for radiation shielding and aerodynamic deceleration'
    ],
    outpostCons: [
      'Lower solar insolation due to higher northern latitude (39°N)',
      'Sub-zero winter temperatures demanding nuclear kilopower surface reactors'
    ],
    trekDirectUrl: 'https://trek.nasa.gov/mars/#v=0.1&x=189.7&y=39.3&z=5&p=urn%3Aogc%3Adef%3Acrs%3AEPSG%3A%3A104905&d=',
    hiRiseObservationId: 'ESP_016766_2195',
  },
  {
    id: 'gale-mount-sharp',
    name: 'Gale Crater (Mount Sharp / Aeolis Mons)',
    subheading: 'Curiosity Rover 12-Year Traverse',
    lat: -5.38,
    lon: 137.44,
    elevationMeters: -4490,
    atmosphericPressurePascals: 840,
    temperatureRangeC: [-85, 0],
    terrainType: 'Sulfate & clay-bearing sedimentary mound inside impact basin',
    missionConnection: 'Curiosity Rover (Mars Science Laboratory)',
    scientificValue: 'Continuous 5-kilometer vertical stratigraphic record documenting Mars transition from warm, wet habitable lakes to arid cold desert.',
    outpostFeasibilityScore: 72,
    outpostPros: ['Equatorial latitude provides high solar panel electrical yield', 'Deep basin provides maximum atmospheric shielding against space radiation'],
    outpostCons: ['Complex sand dune fields (Bagnold Dunes) create wheel entrapment hazards', 'Extremely low water concentration in equatorial regolith'],
    trekDirectUrl: 'https://trek.nasa.gov/mars/#v=0.1&x=137.44&y=-5.38&z=6&p=urn%3Aogc%3Adef%3Acrs%3AEPSG%3A%3A104905&d=',
    hiRiseObservationId: 'PSP_009595_1755',
  },
  {
    id: 'olympus-mons-caldera',
    name: 'Olympus Mons Summit Caldera',
    subheading: 'Solar System’s Largest Shield Volcano',
    lat: 18.65,
    lon: 226.2,
    elevationMeters: 21229, // +21.2 km above datum!
    atmosphericPressurePascals: 72, // Near-vacuum (< 0.1 Earth sea level)
    temperatureRangeC: [-125, -40],
    terrainType: 'Complex basaltic collapse calderas and lava flows',
    missionConnection: 'Mariner 9, Viking 1 & 2, Mars Express HRSC',
    scientificValue: 'Volcanic hotspot history and subsurface thermal vents/lava tube networks that could shelter subterranean habitats.',
    outpostFeasibilityScore: 35,
    outpostPros: ['Magnificent scientific observation vantage point above 95% of Martian atmosphere', 'Intact lava tubes could offer zero-surface radiation caves'],
    outpostCons: [
      'Atmospheric pressure is near hard vacuum (72 Pa) requiring full spacesuit pressurization at all times',
      'Cannot use parachutes or aerodynamic drag for landing; requires 100% retro-propulsion fuel mass'
    ],
    trekDirectUrl: 'https://trek.nasa.gov/mars/#v=0.1&x=226.2&y=18.65&z=5&p=urn%3Aogc%3Adef%3Acrs%3AEPSG%3A%3A104905&d=',
  },
  {
    id: 'valles-marineris-coprates',
    name: 'Valles Marineris (Coprates Chasma)',
    subheading: 'Grand Canyon of the Solar System',
    lat: -14.6,
    lon: 301.7,
    elevationMeters: -6800, // Deepest canyon floor!
    atmosphericPressurePascals: 920,
    temperatureRangeC: [-80, +5],
    terrainType: 'Colossal tectonic rift graben with recurring slope lineae (RSL)',
    missionConnection: 'Mars Reconnaissance Orbiter & Odyssey THEMIS',
    scientificValue: 'Exposes pristine crustal strata down to 8 kilometers deep, with potential seasonal brine flows (RSL).',
    outpostFeasibilityScore: 82,
    outpostPros: [
      'Highest atmospheric pressure anywhere on Mars (over 900 Pa, water boiling point elevated)',
      'Towering canyon walls block direct cosmic ray trajectories from horizon',
      'Milder nighttime thermal buffer from massive rock walls'
    ],
    outpostCons: ['Restricted field-of-view for line-of-sight satellite comms', 'Prone to localized morning dust and fog trapping in canyon depths'],
    trekDirectUrl: 'https://trek.nasa.gov/mars/#v=0.1&x=301.7&y=-14.6&z=5&p=urn%3Aogc%3Adef%3Acrs%3AEPSG%3A%3A104905&d=',
  },
];
