import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface QuizResult {
  score: number;
  total: number;
  date: string;
}

export interface Achievement {
  id: string;
  name: string;
  icon: string;
  desc: string;
  xp: number;
  category: 'academy' | 'simulation' | 'exploration' | 'commander';
}

export const ALL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_steps',
    name: 'First Giant Leap',
    icon: '🚀',
    desc: 'Began astronaut training in the ASTRONAUT-X Academy.',
    xp: 50,
    category: 'academy',
  },
  {
    id: 'orbit_recon',
    name: 'NASA Archives Scout',
    icon: '🌐',
    desc: 'Explored real NASA imagery and scientific asset telemetry.',
    xp: 100,
    category: 'exploration',
  },
  {
    id: 'gravity_pioneer',
    name: '0.38g Gravity Pioneer',
    icon: '⚛️',
    desc: 'Conducted comparative orbital ballistics in the Gravity Lab.',
    xp: 150,
    category: 'simulation',
  },
  {
    id: 'rover_ace',
    name: 'Jezero Dune Drifter',
    icon: '🏎️',
    desc: 'Successfully piloted the rover and cached sedimentary cores.',
    xp: 200,
    category: 'simulation',
  },
  {
    id: 'sky_crane_ace',
    name: 'Sky Crane Ace',
    icon: '🪂',
    desc: 'Executed precision touchdown on Jezero Crater during EDL.',
    xp: 250,
    category: 'simulation',
  },
  {
    id: 'moxie_chemist',
    name: 'MOXIE Oxygen Chemist',
    icon: '🧪',
    desc: 'Stabilized solid-oxide electrolysis cell for continuous O₂ output.',
    xp: 150,
    category: 'simulation',
  },
  {
    id: 'colony_architect',
    name: 'Martian Hab Architect',
    icon: '🏗️',
    desc: 'Engineered a balanced habitation life support grid on Mars.',
    xp: 250,
    category: 'simulation',
  },
  {
    id: 'rocket_engineer',
    name: 'Propulsion Specialist',
    icon: '🔥',
    desc: 'Designed and launched a multi-stage rocket achieving orbital velocity.',
    xp: 250,
    category: 'simulation',
  },
  {
    id: 'martian_botanist',
    name: 'Astro-Botanist',
    icon: '🌱',
    desc: 'Harvested fresh Martian food crops in controlled agriculture.',
    xp: 200,
    category: 'simulation',
  },
  {
    id: 'academy_scholar',
    name: 'Academy Honors Graduate',
    icon: '🎓',
    desc: 'Completed multiple science modules with 100% quiz scores.',
    xp: 300,
    category: 'academy',
  },
  {
    id: 'asteroid_deflector',
    name: 'Planetary Defender',
    icon: '🛡️',
    desc: 'Successfully deflected a hazardous asteroid using DART kinetic momentum transfer.',
    xp: 250,
    category: 'simulation',
  },
  {
    id: 'slingshot_master',
    name: 'Gravity Slingshot Ace',
    icon: '💫',
    desc: 'Reached interstellar escape velocity using multi-body planetary gravity assists.',
    xp: 300,
    category: 'simulation',
  },
  {
    id: 'docking_commander',
    name: 'Orbital Docking Master',
    icon: '🎯',
    desc: 'Executed soft capture and hard latching with the space station under 0.2 m/s.',
    xp: 250,
    category: 'simulation',
  },
  {
    id: 'solar_shield_master',
    name: 'Helios Shield Commander',
    icon: '☀️',
    desc: 'Deflected a coronal mass ejection and protected the crew from solar space radiation.',
    xp: 250,
    category: 'simulation',
  },
  {
    id: 'osdr_researcher',
    name: 'OSDR Space Biologist',
    icon: '🧬',
    desc: 'Investigated NASA Open Science Data Repository (OSDR) space biology and human physiology trade-offs.',
    xp: 200,
    category: 'exploration',
  },
  {
    id: 'donki_heliophysicist',
    name: 'DONKI Space Weather Officer',
    icon: '⚡',
    desc: 'Analyzed live Coronal Mass Ejections and Solar Flares from NASA DONKI.',
    xp: 200,
    category: 'exploration',
  },
  {
    id: 'mars_trekker',
    name: 'Mars Trek Topographer',
    icon: '🗺️',
    desc: 'Surveyed Martian landing sites and MOLA elevation profiles on NASA Mars Trek.',
    xp: 200,
    category: 'exploration',
  },
  {
    id: 'csa_food_pioneer',
    name: 'CSA Astro-Nutritionist',
    icon: '🥗',
    desc: 'Engineered closed-loop food systems following Canadian Space Agency deep space food guidelines.',
    xp: 200,
    category: 'simulation',
  },
  {
    id: 'flight_wings',
    name: 'ASTRONAUT-X Flight Wings',
    icon: '🎖️',
    desc: 'Reached Commander rank and certified flight readiness.',
    xp: 500,
    category: 'commander',
  },
];

export interface ProgressState {
  callsign: string;
  specialisation: string;
  xp: number;
  completedLessons: string[];
  quizScores: Record<string, QuizResult>;
  completedMissions: Record<string, boolean>;
  unlockedAchievements: string[];
  savedNotes: string[];
}

const DEFAULT_PROGRESS: ProgressState = {
  callsign: 'Cadet Aria Vance',
  specialisation: 'Life Support Specialist',
  xp: 350,
  completedLessons: ['gravity-01'],
  quizScores: {
    'gravity-01': { score: 5, total: 5, date: new Date().toISOString() },
  },
  completedMissions: {
    'edl-descent': true,
  },
  unlockedAchievements: ['first_steps', 'gravity_pioneer'],
  savedNotes: [],
};

const STORAGE_KEY = 'astronaut_x_progression_v2';

interface ProgressContextType {
  progress: ProgressState;
  rank: { title: string; level: number; nextXp: number; progressPercent: number };
  setCallsign: (name: string) => void;
  setSpecialisation: (spec: string) => void;
  addXp: (amount: number, reason?: string) => void;
  awardXp: (amount: number, reason?: string) => void;
  completeLesson: (lessonId: string, xpReward?: number) => void;
  submitQuizScore: (quizId: string, score: number, total: number, xpReward?: number) => void;
  completeMission: (missionId: string, xpReward?: number) => void;
  unlockAchievement: (achievementId: string) => void;
  resetProgress: () => void;
  exportProgressJson: () => string;
  importProgressJson: (jsonStr: string) => boolean;
  recentToast: { message: string; xp?: number } | null;
  loginProfile: (profile: { callsign: string; specialisation: string; xp?: number }) => void;
}

const ProgressContext = createContext<ProgressContextType | undefined>(undefined);

export function getRankDetails(xp: number) {
  if (xp < 300) {
    return { title: 'Junior Cadet', level: 1, nextXp: 300, progressPercent: Math.min(100, Math.round((xp / 300) * 100)) };
  } else if (xp < 750) {
    return { title: 'Flight Specialist', level: 2, nextXp: 750, progressPercent: Math.min(100, Math.round(((xp - 300) / 450) * 100)) };
  } else if (xp < 1400) {
    return { title: 'Mission Specialist', level: 3, nextXp: 1400, progressPercent: Math.min(100, Math.round(((xp - 750) / 650) * 100)) };
  } else if (xp < 2200) {
    return { title: 'Flight Commander', level: 4, nextXp: 2200, progressPercent: Math.min(100, Math.round(((xp - 1400) / 800) * 100)) };
  } else {
    return { title: 'Expedition Director', level: 5, nextXp: 3000, progressPercent: 100 };
  }
}

export function ProgressProvider({ children }: { children: ReactNode }) {
  const [progress, setProgress] = useState<ProgressState>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return { ...DEFAULT_PROGRESS, ...JSON.parse(stored) };
      }
    } catch (e) {
      console.warn('Could not read progress from localStorage:', e);
    }
    return DEFAULT_PROGRESS;
  });

  const [recentToast, setRecentToast] = useState<{ message: string; xp?: number } | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch (e) {
      console.warn('Could not save progress to localStorage:', e);
    }
  }, [progress]);

  const showToast = (message: string, xp?: number) => {
    setRecentToast({ message, xp });
    setTimeout(() => {
      setRecentToast(null);
    }, 4500);
  };

  const setCallsign = (name: string) => {
    if (!name.trim()) return;
    setProgress((prev) => ({ ...prev, callsign: name.trim() }));
  };

  const setSpecialisation = (spec: string) => {
    setProgress((prev) => ({ ...prev, specialisation: spec }));
  };

  const addXp = (amount: number, reason?: string) => {
    setProgress((prev) => {
      const newXp = prev.xp + amount;
      return { ...prev, xp: newXp };
    });
    if (reason) {
      showToast(`+${amount} XP: ${reason}`, amount);
    }
  };

  const unlockAchievement = (achievementId: string) => {
    setProgress((prev) => {
      if (prev.unlockedAchievements.includes(achievementId)) return prev;
      const ach = ALL_ACHIEVEMENTS.find((a) => a.id === achievementId);
      const xpBonus = ach ? ach.xp : 100;
      showToast(`🏆 Achievement Unlocked: ${ach?.name || achievementId}! (+${xpBonus} XP)`, xpBonus);
      return {
        ...prev,
        xp: prev.xp + xpBonus,
        unlockedAchievements: [...prev.unlockedAchievements, achievementId],
      };
    });
  };

  const completeLesson = (lessonId: string, xpReward = 150) => {
    setProgress((prev) => {
      const alreadyDone = prev.completedLessons.includes(lessonId);
      const nextLessons = alreadyDone ? prev.completedLessons : [...prev.completedLessons, lessonId];
      const xpAdd = alreadyDone ? 25 : xpReward;
      showToast(`Lesson Completed! (+${xpAdd} XP)`, xpAdd);
      return {
        ...prev,
        xp: prev.xp + xpAdd,
        completedLessons: nextLessons,
      };
    });
    unlockAchievement('first_steps');
  };

  const submitQuizScore = (quizId: string, score: number, total: number, xpReward = 100) => {
    setProgress((prev) => {
      const isPerfect = score === total;
      const earnedXp = Math.round(xpReward * (score / total));
      showToast(`Quiz Passed (${score}/${total})! (+${earnedXp} XP)`, earnedXp);
      const nextScores = {
        ...prev.quizScores,
        [quizId]: { score, total, date: new Date().toISOString() },
      };
      const updated = {
        ...prev,
        xp: prev.xp + earnedXp,
        quizScores: nextScores,
      };
      return updated;
    });

    if (score / total >= 0.8) {
      unlockAchievement('academy_scholar');
    }
  };

  const completeMission = (missionId: string, xpReward = 200) => {
    setProgress((prev) => {
      const nextMissions = { ...prev.completedMissions, [missionId]: true };
      const alreadyDone = prev.completedMissions[missionId];
      const xpAdd = alreadyDone ? 30 : xpReward;
      showToast(`Mission Milestone Accomplished! (+${xpAdd} XP)`, xpAdd);
      return {
        ...prev,
        xp: prev.xp + xpAdd,
        completedMissions: nextMissions,
      };
    });

    if (missionId === 'edl-descent') unlockAchievement('sky_crane_ace');
    if (missionId === 'moxie-boot') unlockAchievement('moxie_chemist');
    if (missionId === 'rover-drive') unlockAchievement('rover_ace');
    if (missionId === 'hab-builder') unlockAchievement('colony_architect');
    if (missionId === 'rocket-launch') unlockAchievement('rocket_engineer');
    if (missionId === 'space-agri') unlockAchievement('martian_botanist');
    if (missionId === 'dart-deflector') unlockAchievement('asteroid_deflector');
    if (missionId === 'slingshot-escape') unlockAchievement('slingshot_master');
    if (missionId === 'iss-docking') unlockAchievement('docking_commander');
  };

  const resetProgress = () => {
    setProgress(DEFAULT_PROGRESS);
    showToast('Progress profile reset to baseline cadet values.');
  };

  const exportProgressJson = (): string => {
    return JSON.stringify(progress, null, 2);
  };

  const importProgressJson = (jsonStr: string): boolean => {
    try {
      const parsed = JSON.parse(jsonStr);
      if (typeof parsed.xp === 'number' && typeof parsed.callsign === 'string') {
        setProgress({ ...DEFAULT_PROGRESS, ...parsed });
        showToast('Astronaut dossier imported successfully!');
        return true;
      }
    } catch (e) {
      console.error('Invalid import JSON', e);
    }
    return false;
  };

  const loginProfile = (profile: { callsign: string; specialisation: string; xp?: number }) => {
    setProgress((prev) => ({
      ...prev,
      callsign: profile.callsign,
      specialisation: profile.specialisation,
      xp: typeof profile.xp === 'number' ? profile.xp : prev.xp,
    }));
    showToast(`Flight Clearance Authorized: Welcome, ${profile.callsign}!`);
  };

  const rank = getRankDetails(progress.xp);

  return (
    <ProgressContext.Provider
      value={{
        progress,
        rank,
        setCallsign,
        setSpecialisation,
        loginProfile,
        addXp,
        awardXp: addXp,
        completeLesson,
        submitQuizScore,
        completeMission,
        unlockAchievement,
        resetProgress,
        exportProgressJson,
        importProgressJson,
        recentToast,
      }}
    >
      {children}
    </ProgressContext.Provider>
  );
}

export function useProgress() {
  const ctx = useContext(ProgressContext);
  if (!ctx) {
    throw new Error('useProgress must be used within a ProgressProvider');
  }
  return ctx;
}
