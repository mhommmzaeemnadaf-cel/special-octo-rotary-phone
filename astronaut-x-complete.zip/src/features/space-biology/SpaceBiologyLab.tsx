import React, { useState, useEffect } from 'react';
import {
  Dna, HeartPulse, Apple, Search, ExternalLink, ShieldAlert,
  Activity, Sparkles, BookOpen, Layers, CheckCircle2, AlertCircle,
  ChevronRight, RefreshCw, Info, Leaf, Award
} from 'lucide-react';
import { useProgress } from '../../context/ProgressContext';
import {
  searchOsdrStudies,
  BUNDLED_OSDR_STUDIES,
  OsdrStudy
} from '../../services/nasa/nasaOsdrService';
import {
  CSA_FOOD_PRODUCTION_MODULES,
  CSA_YOUTH_ACTIVITIES,
  CsaFoodProductionModule,
  CsaYouthActivity
} from '../../services/partners/csaService';

export default function SpaceBiologyLab() {
  const { awardXp, unlockAchievement } = useProgress();

  const [activeSection, setActiveSection] = useState<'osdr' | 'physiology' | 'csa-food' | 'csa-stem'>('osdr');

  // OSDR State
  const [searchQuery, setSearchQuery] = useState('');
  const [studies, setStudies] = useState<OsdrStudy[]>(BUNDLED_OSDR_STUDIES);
  const [selectedStudy, setSelectedStudy] = useState<OsdrStudy>(BUNDLED_OSDR_STUDIES[0]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isSearching, setIsSearching] = useState(false);

  // Physiology Trade-Off Simulator State
  const [activeBodySystem, setActiveBodySystem] = useState<'bone' | 'muscle' | 'immune' | 'sans'>('bone');
  const [exerciseHoursDaily, setExerciseHoursDaily] = useState<number>(2.0); // 0 to 3.5 hrs
  const [missionDurationMonths, setMissionDurationMonths] = useState<number>(6); // 1 to 30 months (Mars mission)

  // CSA Food System State
  const [selectedFoodModule, setSelectedFoodModule] = useState<CsaFoodProductionModule>(CSA_FOOD_PRODUCTION_MODULES[0]);

  // Handle OSDR Search
  const handleOsdrSearch = async (query: string) => {
    setIsSearching(true);
    try {
      const results = await searchOsdrStudies(query);
      setStudies(results);
      if (results.length > 0) setSelectedStudy(results[0]);
      awardXp(50);
      unlockAchievement('osdr_researcher');
    } finally {
      setIsSearching(false);
    }
  };

  const filteredStudies =
    selectedCategory === 'all'
      ? studies
      : studies.filter((s) => s.category === selectedCategory);

  // Physiology Calculations
  // Baseline bone density loss: ~1.2% per month in 0g
  // Mitigated by resistive exercise (ARED): up to 70% mitigation
  const exerciseMitigationFactor = Math.min(0.75, (exerciseHoursDaily / 2.5) * 0.75);
  const netMonthlyBoneLossPct = Math.max(0.2, 1.25 * (1 - exerciseMitigationFactor));
  const totalBoneLossPct = (netMonthlyBoneLossPct * missionDurationMonths).toFixed(1);

  // Muscle volume loss: ~2.5% per month unexercised
  const netMonthlyMuscleLossPct = Math.max(0.4, 2.5 * (1 - exerciseMitigationFactor * 0.9));
  const totalMuscleLossPct = (netMonthlyMuscleLossPct * missionDurationMonths).toFixed(1);

  return (
    <section id="space-biology-lab" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#EC4899]/10 border border-[#EC4899]/30 text-[#EC4899] text-xs font-mono uppercase tracking-widest mb-4">
          <Dna className="w-3.5 h-3.5" />
          <span>SPACE BIOLOGY, ASTRONAUT HEALTH & PARTNER SCIENCE</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-display font-extrabold text-[#F5F1E8] tracking-tight mb-4">
          Space Biology & Nutrition Lab
        </h2>
        <p className="text-[#9298A3] text-sm sm:text-base leading-relaxed">
          Ground human spaceflight in published science using the NASA Open Science Data Repository (OSDR), human microgravity trade-off simulations, and Canadian Space Agency (CSA) deep-space food production toolkits.
        </p>
      </div>

      {/* Primary Section Sub-Tabs */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {[
          { id: 'osdr', label: 'NASA OSDR Research Archive', icon: Dna },
          { id: 'physiology', label: 'Human Microgravity Physiology', icon: HeartPulse },
          { id: 'csa-food', label: 'CSA Deep Space Food Production', icon: Leaf },
          { id: 'csa-stem', label: 'CSA Bilingual STEM Activities', icon: BookOpen },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSection === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveSection(tab.id as any);
                if (tab.id === 'csa-food') {
                  awardXp(50);
                  unlockAchievement('csa_food_pioneer');
                }
              }}
              className={`px-4 py-2.5 rounded-xl font-mono text-xs flex items-center space-x-2 transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#C65B43] text-white font-bold shadow-lg shadow-[#C65B43]/20 scale-105'
                  : 'bg-white/[0.04] text-[#9298A3] hover:text-white hover:bg-white/[0.08] border border-white/5'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* SECTION 1: NASA OPEN SCIENCE DATA REPOSITORY (OSDR)                       */}
      {/* ========================================================================= */}
      {activeSection === 'osdr' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full bg-[#EC4899]/20 text-[#EC4899] border border-[#EC4899]/30 font-mono text-[10px] uppercase">
                NASA BIOLOGICAL & PHYSICAL SCIENCES
              </span>
              <h3 className="text-2xl font-display font-bold text-white mt-1">
                NASA Open Science Data Repository (OSDR)
              </h3>
              <p className="text-xs text-[#9298A3] mt-1 max-w-2xl">
                NASA's public archive of space biology and astronaut health research: microgravity bone demineralization, muscular atrophy, immune dysregulation, and plant morphogenesis.
              </p>
            </div>
            <a
              href="https://osdr.nasa.gov/bio/repo/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-mono text-xs border border-white/10"
            >
              <span>OSDR Official Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Search Bar & Category Filters */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#9298A3] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search OSDR studies (e.g. bone, muscle, immune, arabidopsis, radiation)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleOsdrSearch(searchQuery)}
                className="w-full pl-10 pr-24 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-[#EC4899]"
              />
              <button
                onClick={() => handleOsdrSearch(searchQuery)}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 px-3 py-1.5 rounded-lg bg-[#EC4899] text-white font-mono text-xs font-bold hover:brightness-110 cursor-pointer"
              >
                {isSearching ? 'Querying...' : 'Search'}
              </button>
            </div>

            <div className="flex items-center space-x-1 overflow-x-auto pb-1 sm:pb-0 text-xs font-mono">
              {['all', 'bone', 'muscle', 'immune', 'plant', 'cardiovascular'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-2 rounded-lg transition-colors cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-white/15 text-white font-bold'
                      : 'text-[#9298A3] hover:text-white'
                  }`}
                >
                  {cat.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* Two-Column OSDR Browser */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: Study List */}
            <div className="lg:col-span-5 space-y-3">
              <span className="text-xs font-mono text-[#9298A3] uppercase block">
                Published Spaceflight Investigations ({filteredStudies.length}):
              </span>
              <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
                {filteredStudies.map((study) => {
                  const isSel = selectedStudy.accession === study.accession;
                  return (
                    <button
                      key={study.accession}
                      onClick={() => setSelectedStudy(study)}
                      className={`w-full p-4 rounded-xl border text-left transition-all cursor-pointer ${
                        isSel
                          ? 'bg-[#EC4899]/15 border-[#EC4899] shadow-[0_0_15px_rgba(236,72,153,0.25)]'
                          : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#EC4899]/20 text-[#EC4899] font-bold">
                          {study.accession}
                        </span>
                        <span className="text-[11px] font-mono text-[#9298A3]">{study.organism}</span>
                      </div>
                      <h5 className="font-display font-bold text-xs text-white line-clamp-2 mt-1">
                        {study.title}
                      </h5>
                      <div className="text-[10px] text-[#9298A3] font-mono mt-1 flex justify-between">
                        <span>Factor: {study.spaceflightFactor}</span>
                        <span>{study.mission}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right Column: In-Depth Study Dossier */}
            <div className="lg:col-span-7 bg-black/40 rounded-xl border border-white/10 p-6 space-y-5">
              <div className="flex justify-between items-start border-b border-white/10 pb-4">
                <div>
                  <span className="px-2.5 py-0.5 rounded-full bg-[#EC4899]/20 text-[#EC4899] border border-[#EC4899]/30 font-mono text-[10px] font-bold uppercase">
                    {selectedStudy.accession} • {selectedStudy.category.toUpperCase()} RESEARCH
                  </span>
                  <h4 className="text-xl font-display font-bold text-white mt-1.5 leading-snug">
                    {selectedStudy.title}
                  </h4>
                  <span className="text-xs text-[#9298A3] font-mono block mt-1">
                    Authors: {selectedStudy.authors}
                  </span>
                </div>
                <a
                  href={selectedStudy.osdrUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="shrink-0 p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white"
                  title="View Study on OSDR"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>

              {/* Study Metadata Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">ORGANISM</span>
                  <span className="text-xs font-bold text-white truncate block">{selectedStudy.organism}</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">TISSUE TARGET</span>
                  <span className="text-xs font-bold text-[#38BDF8] truncate block">{selectedStudy.tissue}</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">MISSION / PAYLOAD</span>
                  <span className="text-xs font-bold text-[#34D399] truncate block">{selectedStudy.mission}</span>
                </div>
              </div>

              {/* Abstract */}
              <div className="space-y-1">
                <span className="text-xs font-mono text-white font-bold block">
                  Study Abstract & Methodology:
                </span>
                <p className="text-xs text-[#9298A3] leading-relaxed">
                  {selectedStudy.description}
                </p>
              </div>

              {/* Key Scientific Finding Highlight */}
              <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-4 space-y-1.5">
                <span className="text-xs font-mono font-bold text-[#34D399] flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  Key Published NASA Finding:
                </span>
                <p className="text-xs text-white/90 leading-relaxed font-mono">
                  {selectedStudy.keyFinding}
                </p>
              </div>

              <div className="pt-2 flex justify-between items-center text-xs font-mono text-[#9298A3]">
                <span>Released: {selectedStudy.releaseDate}</span>
                <span className="text-[#EC4899]">NASA GeneLab / ALSDA Harmonized Repository</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION 2: HUMAN MICROGRAVITY PHYSIOLOGY SIMULATOR                        */}
      {/* ========================================================================= */}
      {activeSection === 'physiology' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="border-b border-white/10 pb-4">
            <span className="px-2.5 py-0.5 rounded-full bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/30 font-mono text-[10px] uppercase">
              NASA HUMAN RESEARCH PROGRAM (HRP)
            </span>
            <h3 className="text-2xl font-display font-bold text-white mt-1">
              Human Spaceflight Physiological Trade-Off Simulator
            </h3>
            <p className="text-xs text-[#9298A3] mt-1 max-w-2xl">
              Model how microgravity, space radiation, and mechanical unloading impact bone density, muscle atrophy, cardiovascular fluid shifts, and the immune system across prolonged expedition timelines.
            </p>
          </div>

          {/* Interactive Controls: Exercise & Mission Duration */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white/5 p-4 rounded-xl border border-white/10 font-mono text-xs">
            <div className="space-y-2">
              <div className="flex justify-between items-center text-[#9298A3]">
                <span>DAILY ARED RESISTIVE EXERCISE:</span>
                <span className="text-white font-bold">{exerciseHoursDaily.toFixed(1)} hrs / day</span>
              </div>
              <input
                type="range"
                min="0"
                max="3.5"
                step="0.5"
                value={exerciseHoursDaily}
                onChange={(e) => setExerciseHoursDaily(parseFloat(e.target.value))}
                className="w-full accent-[#34D399] cursor-pointer"
              />
              <span className="text-[10px] text-[#9298A3]">
                ISS standard: 2.0 to 2.5 hours daily (T2 Treadmill, CEVIS cycle, ARED vacuum cylinders).
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center text-[#9298A3]">
                <span>EXPEDITION FLIGHT DURATION:</span>
                <span className="text-white font-bold">{missionDurationMonths} months</span>
              </div>
              <input
                type="range"
                min="1"
                max="30"
                step="1"
                value={missionDurationMonths}
                onChange={(e) => setMissionDurationMonths(parseInt(e.target.value))}
                className="w-full accent-[#C65B43] cursor-pointer"
              />
              <span className="text-[10px] text-[#9298A3]">
                6 mo (ISS Increment) vs 12 mo (1-Year Mission) vs 30 mo (Mars Round-Trip Transit).
              </span>
            </div>
          </div>

          {/* Body System Selector & Dynamic Health Projections */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-4 space-y-3">
              <span className="text-xs font-mono text-[#9298A3] uppercase block">
                Physiological Target Systems:
              </span>
              {[
                { id: 'bone', label: 'Skeletal Bone Matrix', metric: `-${totalBoneLossPct}% Loss`, icon: Dna },
                { id: 'muscle', label: 'Skeletal Muscle Volume', metric: `-${totalMuscleLossPct}% Atrophy`, icon: Activity },
                { id: 'sans', label: 'SANS & Fluid Redistribution', metric: '+1.8 L Cephalad', icon: HeartPulse },
                { id: 'immune', label: 'Immune & T-Cell Health', metric: 'Latent Viral Risk', icon: ShieldAlert },
              ].map((sys) => {
                const Icon = sys.icon;
                const isSel = activeBodySystem === sys.id;
                return (
                  <button
                    key={sys.id}
                    onClick={() => setActiveBodySystem(sys.id as any)}
                    className={`w-full p-4 rounded-xl border text-left transition-all cursor-pointer ${
                      isSel
                        ? 'bg-white/10 border-[#38BDF8] shadow-[0_0_15px_rgba(56,189,248,0.2)]'
                        : 'bg-white/[0.02] border-white/10 hover:bg-white/[0.05]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-display font-bold text-sm text-white">{sys.label}</span>
                      <span className="text-xs font-mono font-bold text-[#EF4444]">{sys.metric}</span>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="lg:col-span-8 bg-black/40 rounded-xl border border-white/10 p-6 space-y-5">
              {activeBodySystem === 'bone' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center border-b border-white/10 pb-3">
                    <h4 className="text-lg font-display font-bold text-white">
                      Bone Mineral Density (BMD) Degradation
                    </h4>
                    <span className="text-xs font-mono text-[#EF4444] font-bold">
                      Est. Total Loss: {totalBoneLossPct}%
                    </span>
                  </div>
                  <p className="text-xs text-[#9298A3] leading-relaxed">
                    Without Earth's 1g gravitational vector, osteoclasts (bone resorption cells) outpace osteoblasts (bone formation cells). Calcium leaches into the bloodstream, elevating kidney stone risks. Weight-bearing bones (lumbar vertebrae, femur, calcaneus) degrade at ~1.0% to 1.5% per month.
                  </p>
                  <div className="p-4 rounded-xl bg-white/5 border border-white/10 font-mono text-xs space-y-2">
                    <span className="text-[#34D399] font-bold block">NASA Countermeasure Protocol:</span>
                    <ul className="text-[11px] text-[#9298A3] space-y-1 list-disc pl-4">
                      <li>ARED (Advanced Resistive Exercise Device) delivers up to 600 lbs of load.</li>
                      <li>Dietary Calcium (1,200 mg/day) and Vitamin D supplementation.</li>
                      <li>Bisphosphonate therapy evaluated for 3-year deep-space Mars expeditions.</li>
                    </ul>
                  </div>
                </div>
              )}

              {activeBodySystem === 'muscle' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center border-b border-white/10 pb-3">
                    <h4 className="text-lg font-display font-bold text-white">
                      Skeletal Muscle Mass & Fiber Type Switching
                    </h4>
                    <span className="text-xs font-mono text-[#EF4444] font-bold">
                      Est. Total Atrophy: {totalMuscleLossPct}%
                    </span>
                  </div>
                  <p className="text-xs text-[#9298A3] leading-relaxed">
                    Anti-gravity postural muscles (soleus, gastrocnemius, quadriceps) undergo rapid disuse atrophy. Published OSDR research demonstrates a phenotype switch from slow-twitch Type I oxidative fibers to fast-twitch Type II glycolytic fibers, reducing endurance and metabolic efficiency.
                  </p>
                  <div className="p-4 rounded-xl bg-white/5 border border-white/10 font-mono text-xs space-y-2">
                    <span className="text-[#34D399] font-bold block">NASA Countermeasure Protocol:</span>
                    <ul className="text-[11px] text-[#9298A3] space-y-1 list-disc pl-4">
                      <li>T2 Treadmill with bungee harness providing 70-80% body weight simulation.</li>
                      <li>High-leucine branched-chain amino acid (BCAA) nutritional supplements.</li>
                    </ul>
                  </div>
                </div>
              )}

              {activeBodySystem === 'sans' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center border-b border-white/10 pb-3">
                    <h4 className="text-lg font-display font-bold text-white">
                      Spaceflight-Associated Neuro-Ocular Syndrome (SANS)
                    </h4>
                    <span className="text-xs font-mono text-[#F59E0B] font-bold">
                      Cephalad Fluid Shift: ~1.8 L
                    </span>
                  </div>
                  <p className="text-xs text-[#9298A3] leading-relaxed">
                    Absence of hydrostatic pressure gradient draws ~1.5 to 2.0 Liters of blood and interstitial fluid upward ("puffy face and bird legs"). Elevated venous pressures inside the skull lead to posterior globe flattening, optic disc edema, and hyperopic refractive shifts.
                  </p>
                  <div className="p-4 rounded-xl bg-white/5 border border-white/10 font-mono text-xs space-y-2">
                    <span className="text-[#34D399] font-bold block">NASA Countermeasure Protocol:</span>
                    <ul className="text-[11px] text-[#9298A3] space-y-1 list-disc pl-4">
                      <li>Chibis Lower Body Negative Pressure (LBNP) suit to draw fluids back to legs.</li>
                      <li>Dietary sodium management and daily optical coherence tomography (OCT) tracking.</li>
                    </ul>
                  </div>
                </div>
              )}

              {activeBodySystem === 'immune' && (
                <div className="space-y-4">
                  <div className="flex justify-between items-center border-b border-white/10 pb-3">
                    <h4 className="text-lg font-display font-bold text-white">
                      Immune System Dysregulation & Cosmic Radiation Stress
                    </h4>
                    <span className="text-xs font-mono text-[#F59E0B] font-bold">
                      Elevated Reactivation Risk
                    </span>
                  </div>
                  <p className="text-xs text-[#9298A3] leading-relaxed">
                    Chronic confinement, circadian disruption, and space radiation trigger hypothalamic-pituitary-adrenal axis stress hormones. T-cell activation is blunted, allowing latent herpesviruses (Epstein-Barr, Cytomegalovirus) to shed without full clinical symptoms.
                  </p>
                  <div className="p-4 rounded-xl bg-white/5 border border-white/10 font-mono text-xs space-y-2">
                    <span className="text-[#34D399] font-bold block">NASA Countermeasure Protocol:</span>
                    <ul className="text-[11px] text-[#9298A3] space-y-1 list-disc pl-4">
                      <li>HEPA microbial air filtration and active UV sterilization in life support loops.</li>
                      <li>Antioxidant nutritional cocktails (selenium, zinc, polyphenols, vitamin E).</li>
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION 3: CSA DEEP SPACE FOOD PRODUCTION & NUTRITION                     */}
      {/* ========================================================================= */}
      {activeSection === 'csa-food' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full bg-[#34D399]/20 text-[#34D399] border border-[#34D399]/30 font-mono text-[10px] uppercase">
                CANADIAN SPACE AGENCY (CSA / ASC)
              </span>
              <h3 className="text-2xl font-display font-bold text-white mt-1">
                Deep Space Food Production & Closed-Loop Nutrition
              </h3>
              <p className="text-xs text-[#9298A3] mt-1 max-w-2xl">
                Canadian Space Agency guidelines on growing nutrient-dense crops in microgravity, meeting astronaut metabolic quotas (2,800 kcal/day), and transferring space agriculture to northern and remote communities.
              </p>
            </div>
            <a
              href="https://www.asc-csa.gc.ca/eng/youth-educators/toolkits/food-production/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-mono text-xs border border-white/10"
            >
              <span>CSA Food Production Toolkit</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left: Food Modules */}
            <div className="lg:col-span-5 space-y-3">
              <span className="text-xs font-mono text-[#9298A3] uppercase block">
                CSA Advanced Life Support Growth Chambers:
              </span>
              {CSA_FOOD_PRODUCTION_MODULES.map((mod) => {
                const isSel = selectedFoodModule.id === mod.id;
                return (
                  <button
                    key={mod.id}
                    onClick={() => setSelectedFoodModule(mod)}
                    className={`w-full p-4 rounded-xl border text-left transition-all cursor-pointer ${
                      isSel
                        ? 'bg-[#34D399]/15 border-[#34D399] shadow-[0_0_15px_rgba(52,211,153,0.2)]'
                        : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-display font-bold text-sm text-white">{mod.title}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#34D399]/20 text-[#34D399]">
                        {mod.growthMethod}
                      </span>
                    </div>
                    <span className="text-xs text-[#9298A3] block">{mod.subtitle}</span>
                    <div className="text-[11px] text-[#9298A3] font-mono mt-2 flex justify-between">
                      <span>Water Recycled: {mod.waterRecyclingEfficiencyPct}%</span>
                      <span>Yield: {mod.nutrientYield.kcalPerDayPerM2} kcal/m²/day</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Right: Detailed Module Dossier & Earth Analogue */}
            <div className="lg:col-span-7 bg-black/40 rounded-xl border border-white/10 p-6 space-y-5">
              <div className="border-b border-white/10 pb-3">
                <span className="text-[10px] font-mono text-[#34D399] uppercase block">
                  CROP & NUTRITIONAL PROFILE
                </span>
                <h4 className="text-xl font-display font-bold text-white mt-0.5">
                  {selectedFoodModule.title}
                </h4>
                <p className="text-xs text-[#9298A3] mt-1">{selectedFoodModule.subtitle}</p>
              </div>

              {/* Yield Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">ENERGY INPUT</span>
                  <span className="text-base font-bold text-white">{selectedFoodModule.energyInputKWhPerKg} kWh/kg</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">WATER RECYCLING</span>
                  <span className="text-base font-bold text-[#34D399]">{selectedFoodModule.waterRecyclingEfficiencyPct}%</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">PROTEIN YIELD</span>
                  <span className="text-base font-bold text-[#38BDF8]">
                    {selectedFoodModule.nutrientYield.proteinGramsPerM2} g / m²
                  </span>
                </div>
              </div>

              {/* Target Crops */}
              <div className="bg-white/[0.02] p-4 rounded-xl border border-white/5 space-y-1.5">
                <span className="text-xs font-mono text-[#F5F1E8] font-bold block">
                  Target Flight Crops:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {selectedFoodModule.targetCrops.map((c, i) => (
                    <span key={i} className="px-2.5 py-1 rounded-md bg-white/5 text-xs text-white font-mono">
                      🌱 {c}
                    </span>
                  ))}
                </div>
              </div>

              {/* Dual Earth Benefit Box */}
              <div className="p-4 rounded-xl bg-blue-950/20 border border-blue-500/20 space-y-1.5">
                <span className="text-xs font-mono font-bold text-[#38BDF8] flex items-center gap-1.5">
                  <Globe className="w-4 h-4" />
                  Dual Benefit: Arctic & Remote Canadian Food Security:
                </span>
                <p className="text-xs text-white/90 leading-relaxed font-mono">
                  {selectedFoodModule.earthAnalogueApplication}
                </p>
              </div>

              <div className="pt-2 flex justify-between items-center text-xs font-mono text-[#9298A3]">
                <span>Reference: {selectedFoodModule.csaToolkitReference}</span>
                <a
                  href="#space-agriculture"
                  className="text-[#34D399] hover:underline flex items-center gap-1 font-bold"
                >
                  <span>Simulate Crop Cycle in Space Agriculture</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SECTION 4: CSA BILINGUAL STEM & YOUTH ACTIVITIES                          */}
      {/* ========================================================================= */}
      {activeSection === 'csa-stem' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full bg-[#38BDF8]/20 text-[#38BDF8] border border-[#38BDF8]/30 font-mono text-[10px] uppercase">
                CSA YOUTH & EDUCATOR OUTREACH
              </span>
              <h3 className="text-2xl font-display font-bold text-white mt-1">
                Canadian Space Agency Bilingual STEM Resources
              </h3>
              <p className="text-xs text-[#9298A3] mt-1 max-w-2xl">
                Free bilingual (English / Français) STEM learning modules, science activities, and hands-on experiments created for classrooms, science camps, libraries, and youth organizations.
              </p>
            </div>
            <a
              href="https://www.asc-csa.gc.ca/eng/youth-educators/resources-stem-and-youth-organizations.asp"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-mono text-xs border border-white/10"
            >
              <span>CSA STEM Resource Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {CSA_YOUTH_ACTIVITIES.map((act) => (
              <div
                key={act.id}
                className="bg-black/30 border border-white/10 rounded-xl p-6 flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-white/5 border border-white/10 text-[10px] font-mono text-[#38BDF8]">
                      {act.category}
                    </span>
                    <span className="text-[11px] font-mono text-[#9298A3]">
                      ⏱️ {act.durationMinutes} min • {act.ageGroup}
                    </span>
                  </div>

                  <h4 className="text-lg font-display font-bold text-white">
                    {act.titleEn}
                  </h4>
                  <div className="text-xs text-[#9298A3] italic font-serif mb-3">
                    {act.titleFr}
                  </div>

                  <p className="text-xs text-[#9298A3] leading-relaxed mb-4">
                    {act.summary}
                  </p>

                  <div className="space-y-1.5 border-t border-white/5 pt-3">
                    <span className="text-[11px] font-mono font-bold text-white block">
                      Target Learning Outcomes:
                    </span>
                    <ul className="text-xs text-[#9298A3] space-y-1 list-disc pl-4 font-mono">
                      {act.learningOutcomes.map((out, idx) => (
                        <li key={idx}>{out}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <a
                  href={act.csaUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-xs font-bold flex items-center justify-center space-x-2 transition-all cursor-pointer"
                >
                  <span>Access CSA Activity Package</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
