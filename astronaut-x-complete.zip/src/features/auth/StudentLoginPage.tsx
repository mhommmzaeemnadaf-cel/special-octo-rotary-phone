import React, { useState } from 'react';
import {
  Shield, Key, User, Sparkles, CheckCircle2, Lock,
  ChevronRight, ArrowLeft, Fingerprint, Eye, EyeOff, Award, Orbit,
  Rocket, Dna, Compass, Zap, GraduationCap, School, Globe, Check, AlertCircle
} from 'lucide-react';
import { useProgress } from '../../context/ProgressContext';
import { soundManager } from '../../utils/audio';
import MarsCanvas from '../../components/MarsCanvas';

interface StudentLoginPageProps {
  onBackToMission: () => void;
  onLoginSuccess?: () => void;
}

interface DemoStudent {
  studentId: string;
  name: string;
  callsign: string;
  grade: string;
  school: string;
  specialisation: string;
  xp: number;
  rank: string;
  passwordHint: string;
  avatar: string;
}

const DEMO_STUDENTS: DemoStudent[] = [
  {
    studentId: 'NASA-CADET-01',
    name: 'Aria Vance',
    callsign: 'Cadet Aria Vance',
    grade: 'Grade 11 • Senior Spaceflight Squadron',
    school: 'Goddard STEM Aerospace Academy',
    specialisation: 'Flight Commander & Astrodynamics',
    xp: 2850,
    rank: 'Flight Commander',
    passwordHint: 'astronaut2026',
    avatar: '🧑‍🚀',
  },
  {
    studentId: 'NASA-CADET-02',
    name: 'Leo Chen',
    callsign: 'Cadet Leo Chen',
    grade: 'Grade 9 • Junior Bio-Regenerative Flight',
    school: 'Kennedy Space Biology Institute',
    specialisation: 'Bio-Regenerative Life Support & Astrobiology',
    xp: 1450,
    rank: 'Mission Specialist',
    passwordHint: 'marslife2026',
    avatar: '🔬',
  },
  {
    studentId: 'NASA-CADET-03',
    name: 'Maya Patel',
    callsign: 'Cadet Maya Patel',
    grade: 'Grade 12 • Kinetic Defense Division',
    school: 'JPL Planetary Defense Lab School',
    specialisation: 'Propulsion Systems & Kinetic Defense',
    xp: 1820,
    rank: 'Mission Specialist',
    passwordHint: 'rocketpropel2026',
    avatar: '🚀',
  },
];

const GRADES = [
  'Grade 6–8 (Middle School Junior Cadet)',
  'Grade 9–10 (High School Flight Specialist)',
  'Grade 11–12 (Senior Mission Commander)',
  'University / Undergraduate Fellow',
  'Independent Space Enthusiast / Lifelong Learner',
];

const SPECIALIZATIONS = [
  'Flight Commander & Orbital Astrodynamics',
  'Bio-Regenerative Life Support & Astrobiology',
  'Propulsion Systems & Kinetic Deflection',
  'Planetary Geology & Rover Tele-operations',
  'Atmospheric Entry, Descent & Landing (EDL)',
];

export default function StudentLoginPage({ onBackToMission, onLoginSuccess }: StudentLoginPageProps) {
  const { progress, loginProfile, awardXp } = useProgress();

  const [activeTab, setActiveTab] = useState<'signin' | 'register'>('signin');

  // Sign In Form State
  const [studentId, setStudentId] = useState('NASA-CADET-01');
  const [password, setPassword] = useState('astronaut2026');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);

  // Registration Form State
  const [regName, setRegName] = useState('');
  const [regStudentId, setRegStudentId] = useState('NASA-CADET-' + Math.floor(1000 + Math.random() * 9000));
  const [regSchool, setRegSchool] = useState('');
  const [regGrade, setRegGrade] = useState(GRADES[1]);
  const [regSpecialisation, setRegSpecialisation] = useState(SPECIALIZATIONS[0]);
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');

  // Biometric state
  const [isBiometricScanning, setIsBiometricScanning] = useState(false);
  const [biometricVerified, setBiometricVerified] = useState(false);

  // Status feedback
  const [authStatus, setAuthStatus] = useState<'idle' | 'authorizing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  // Trigger Biometric Scan
  const handleBiometricScan = () => {
    soundManager.playClick();
    setIsBiometricScanning(true);
    setBiometricVerified(false);

    setTimeout(() => {
      setIsBiometricScanning(false);
      setBiometricVerified(true);
      soundManager.playSuccess();
    }, 1100);
  };

  // 1-Click Demo Login Quick Select
  const handleSelectDemoStudent = (demo: DemoStudent) => {
    soundManager.playClick();
    setStudentId(demo.studentId);
    setPassword(demo.passwordHint);
    setBiometricVerified(true);
    setErrorMessage('');
  };

  // Execute Student Sign In
  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playClick();

    if (!studentId.trim()) {
      setErrorMessage('Please enter your assigned Student ID.');
      return;
    }
    if (!password) {
      setErrorMessage('Please enter your flight passcode.');
      return;
    }

    setAuthStatus('authorizing');
    setErrorMessage('');

    setTimeout(() => {
      // Find matching demo student or authenticate custom student
      const matched = DEMO_STUDENTS.find(
        (s) => s.studentId.toLowerCase() === studentId.trim().toLowerCase()
      );

      const targetCallsign = matched ? matched.callsign : `Cadet ${studentId.trim()}`;
      const targetSpec = matched ? matched.specialisation : SPECIALIZATIONS[0];
      const targetXp = matched ? matched.xp : 450;

      loginProfile({
        callsign: targetCallsign,
        specialisation: targetSpec,
        xp: targetXp,
      });

      setAuthStatus('success');
      soundManager.playSuccess();

      setTimeout(() => {
        if (onLoginSuccess) onLoginSuccess();
        onBackToMission();
      }, 700);
    }, 800);
  };

  // Execute Student Registration
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playClick();

    if (!regName.trim()) {
      setErrorMessage('Please enter your full cadet name.');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setErrorMessage('Passwords do not match. Please verify.');
      return;
    }
    if (regPassword.length < 4) {
      setErrorMessage('Passcode must be at least 4 characters.');
      return;
    }

    setAuthStatus('authorizing');
    setErrorMessage('');

    setTimeout(() => {
      loginProfile({
        callsign: `Cadet ${regName.trim()}`,
        specialisation: regSpecialisation,
        xp: 500, // Welcome induction bonus
      });

      awardXp(250);
      setAuthStatus('success');
      soundManager.playSuccess();

      setTimeout(() => {
        if (onLoginSuccess) onLoginSuccess();
        onBackToMission();
      }, 700);
    }, 900);
  };

  return (
    <div className="relative min-h-screen w-full bg-[#030712] text-[#F8FAFC] flex flex-col justify-between overflow-x-hidden select-none">
      {/* Background Deep Cosmic Nebulae */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute -top-32 -left-32 w-[650px] h-[650px] bg-[#38BDF8]/10 rounded-full blur-[140px]" />
        <div className="absolute top-1/2 -right-32 w-[600px] h-[600px] bg-[#C65B43]/15 rounded-full blur-[140px]" />
        <div className="absolute -bottom-32 left-1/3 w-[500px] h-[500px] bg-[#8B5CF6]/10 rounded-full blur-[120px]" />
        <div className="absolute inset-0 telemetry-grid opacity-15" />
      </div>

      {/* Top Header / Navigation Bar */}
      <header className="relative z-20 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex items-center justify-between">
        <button
          onClick={onBackToMission}
          className="flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-mono text-[#94A3B8] hover:text-white transition-all cursor-pointer backdrop-blur-md"
        >
          <ArrowLeft size={14} />
          <span>RETURN TO MISSION PLATFORM</span>
        </button>

        <div className="flex items-center space-x-3">
          <div className="relative w-8 h-8 rounded-full bg-gradient-to-br from-[#C65B43] to-[#8F3724] border border-white/20 flex items-center justify-center font-display font-black text-white text-xs shadow-[0_0_15px_rgba(198,91,67,0.4)]">
            AX
          </div>
          <span className="font-display font-extrabold tracking-wider text-sm sm:text-base text-white hidden sm:inline">
            ASTRONAUT-X ACADEMY
          </span>
        </div>
      </header>

      {/* Main Split-Screen Layout */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full my-auto py-6 sm:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* ================================================================= */}
          {/* LEFT COLUMN: 3D HOLOGRAPHIC STATION & LIVE TELEMETRY             */}
          {/* ================================================================= */}
          <div className="lg:col-span-6 space-y-6">
            {/* Top Mission Pill */}
            <div className="inline-flex items-center space-x-2 px-3.5 py-1 rounded-full bg-white/5 border border-white/15 backdrop-blur-xl">
              <span className="w-2 h-2 rounded-full bg-[#34D399] animate-ping" />
              <span className="text-xs font-mono tracking-widest text-[#34D399] uppercase font-bold">
                NASA SPACE APPS // STUDENT CLEARANCE GATEWAY
              </span>
            </div>

            {/* Headline */}
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight uppercase leading-[0.95]">
              STUDENT FLIGHT
              <span className="block text-gradient-mars text-3xl sm:text-4xl lg:text-5xl font-extrabold mt-1">
                ACCESS & ACADEMY PORTAL
              </span>
            </h1>

            <p className="text-sm sm:text-base text-[#94A3B8] leading-relaxed max-w-lg font-normal">
              Sign in with your verified Student ID to unlock your personalized astronaut dossier, 6 interactive physics simulators, 10-step certification quizzes, and official Flight Wings.
            </p>

            {/* Interactive 3D Mini Mars Globe Viewport */}
            <div className="relative rounded-3xl overflow-hidden glass-panel-card p-5 h-64 border border-white/15 shadow-2xl flex flex-col justify-between">
              <div className="absolute inset-0 z-0 opacity-80">
                <MarsCanvas interactive={false} />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-[#030712] via-transparent to-transparent z-10 pointer-events-none" />

              <div className="relative z-20 flex justify-between items-start">
                <span className="px-2.5 py-1 rounded-full bg-black/60 border border-white/10 text-[10px] font-mono text-[#38BDF8]">
                  STATION ORBIT: 418 KM
                </span>
                <span className="px-2.5 py-1 rounded-full bg-emerald-950/40 border border-emerald-500/30 text-[10px] font-mono text-emerald-400 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  AUTHENTICATION GATEWAY: LIVE
                </span>
              </div>

              <div className="relative z-20 flex items-center justify-between text-xs font-mono border-t border-white/10 pt-3 bg-black/40 backdrop-blur-md px-3 py-2 rounded-2xl">
                <span className="text-[#94A3B8]">Active Space Cadets:</span>
                <span className="text-white font-bold">14,820 Enrolled</span>
                <span className="text-white/20">•</span>
                <span className="text-[#38BDF8]">100% Offline Capable</span>
              </div>
            </div>

            {/* Fast 1-Click Demo Accounts Strip */}
            <div className="glass-panel-card rounded-2xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono text-[#FBBF24] uppercase tracking-wider font-bold flex items-center gap-1.5">
                  <Zap size={13} />
                  1-CLICK DEMO STUDENT ACCOUNTS (FOR JUDGES):
                </span>
                <span className="text-[10px] font-mono text-[#94A3B8]">Tap to auto-fill</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {DEMO_STUDENTS.map((demo) => {
                  const isSelected = studentId === demo.studentId;
                  return (
                    <button
                      key={demo.studentId}
                      type="button"
                      onClick={() => handleSelectDemoStudent(demo)}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-[#38BDF8]/20 border-[#38BDF8] shadow-[0_0_15px_rgba(56,189,248,0.3)]'
                          : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.08]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-sm">{demo.avatar}</span>
                        <span className="text-[9px] font-mono font-bold text-[#FBBF24]">{demo.xp} XP</span>
                      </div>
                      <div className="font-display font-bold text-xs text-white truncate">
                        {demo.name}
                      </div>
                      <div className="text-[10px] font-mono text-[#38BDF8] truncate">
                        {demo.studentId}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ================================================================= */}
          {/* RIGHT COLUMN: DRIBBLE GLASSMORPHIC STUDENT LOGIN CARD             */}
          {/* ================================================================= */}
          <div className="lg:col-span-6">
            <div className="relative rounded-3xl bg-[#060B18]/90 border border-white/15 p-6 sm:p-8 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] backdrop-blur-2xl">
              
              {/* Tab Switcher: Sign In vs Enroll */}
              <div className="flex bg-white/5 p-1 rounded-2xl border border-white/10 mb-6 font-mono text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('signin');
                    setErrorMessage('');
                  }}
                  className={`flex-1 py-2.5 rounded-xl transition-all cursor-pointer font-bold flex items-center justify-center space-x-1.5 ${
                    activeTab === 'signin'
                      ? 'bg-gradient-to-r from-[#C65B43] to-[#E07A5F] text-white shadow-lg'
                      : 'text-[#94A3B8] hover:text-white'
                  }`}
                >
                  <Lock size={13} />
                  <span>STUDENT SIGN IN</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('register');
                    setErrorMessage('');
                  }}
                  className={`flex-1 py-2.5 rounded-xl transition-all cursor-pointer font-bold flex items-center justify-center space-x-1.5 ${
                    activeTab === 'register'
                      ? 'bg-gradient-to-r from-[#38BDF8] to-[#818CF8] text-black shadow-lg'
                      : 'text-[#94A3B8] hover:text-white'
                  }`}
                >
                  <GraduationCap size={14} />
                  <span>ENROLL NEW CADET</span>
                </button>
              </div>

              {/* Error Alert Box */}
              {errorMessage && (
                <div className="mb-4 p-3 rounded-xl bg-red-950/40 border border-red-500/50 text-red-200 text-xs font-mono flex items-center space-x-2">
                  <AlertCircle size={15} className="text-red-400 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* ============================================================= */}
              {/* FORM 1: STUDENT SIGN IN (STUDENT ID & PASSWORD)               */}
              {/* ============================================================= */}
              {activeTab === 'signin' && (
                <form onSubmit={handleSignInSubmit} className="space-y-4">
                  {/* Student ID Field */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs font-mono">
                      <label className="text-[#94A3B8] uppercase">Student ID (Cadet Code):</label>
                      <span className="text-[10px] text-[#38BDF8]">Format: NASA-CADET-XX</span>
                    </div>
                    <div className="relative">
                      <User size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
                      <input
                        type="text"
                        required
                        value={studentId}
                        onChange={(e) => setStudentId(e.target.value)}
                        placeholder="e.g. NASA-CADET-01"
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-[#38BDF8] transition-colors"
                      />
                    </div>
                  </div>

                  {/* Password Field */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs font-mono">
                      <label className="text-[#94A3B8] uppercase">Flight Security Passcode:</label>
                      <span className="text-[10px] text-[#FBBF24]">Demo: astronaut2026</span>
                    </div>
                    <div className="relative">
                      <Key size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className="w-full pl-10 pr-10 py-3 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs tracking-wider focus:outline-none focus:border-[#C65B43] transition-colors"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-white cursor-pointer"
                      >
                        {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                      </button>
                    </div>
                  </div>

                  {/* Biometric Scan Simulation Strip */}
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={handleBiometricScan}
                      disabled={isBiometricScanning}
                      className={`w-full p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer ${
                        biometricVerified
                          ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-400'
                          : isBiometricScanning
                          ? 'bg-blue-950/30 border-blue-500/40 text-blue-400 animate-pulse'
                          : 'bg-white/[0.03] border-white/10 text-[#94A3B8] hover:bg-white/[0.06] hover:text-white'
                      }`}
                    >
                      <div className="flex items-center space-x-2.5 font-mono text-xs">
                        <Fingerprint size={18} className={biometricVerified ? 'text-[#34D399]' : 'text-[#38BDF8]'} />
                        <span>
                          {isBiometricScanning
                            ? 'SCANNING STUDENT BIOMETRICS...'
                            : biometricVerified
                            ? 'BIOMETRICS RECOGNIZED: CADET VERIFIED'
                            : 'CLICK TO SIMULATE BIOMETRIC FINGERPRINT SCAN'}
                        </span>
                      </div>
                      {biometricVerified && <CheckCircle2 size={16} className="text-[#34D399]" />}
                    </button>
                  </div>

                  {/* Remember Me Checkbox */}
                  <div className="flex items-center justify-between text-xs font-mono text-[#94A3B8] pt-1">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="accent-[#38BDF8] rounded"
                      />
                      <span>Remember Student Credentials</span>
                    </label>

                    <button
                      type="button"
                      onClick={() => {
                        setStudentId('NASA-CADET-01');
                        setPassword('astronaut2026');
                      }}
                      className="text-[#38BDF8] hover:underline cursor-pointer"
                    >
                      Reset to Demo
                    </button>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={authStatus === 'authorizing'}
                      className="w-full py-3.5 rounded-full bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#C65B43] hover:brightness-110 text-white font-mono text-xs font-bold tracking-wider uppercase shadow-[0_0_35px_rgba(198,91,67,0.5)] hover:shadow-[0_0_50px_rgba(198,91,67,0.7)] transition-all flex items-center justify-center space-x-2 cursor-pointer active:scale-95"
                    >
                      <Sparkles size={15} />
                      <span>
                        {authStatus === 'authorizing'
                          ? 'AUTHORIZING FLIGHT DECK...'
                          : authStatus === 'success'
                          ? 'ACCESS GRANTED // LAUNCHING...'
                          : 'SIGN IN TO ASTRONAUT ACADEMY'}
                      </span>
                    </button>
                  </div>
                </form>
              )}

              {/* ============================================================= */}
              {/* FORM 2: ENROLL NEW CADET (REGISTRATION)                       */}
              {/* ============================================================= */}
              {activeTab === 'register' && (
                <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] font-mono text-[#94A3B8] uppercase block">Full Cadet Name:</label>
                      <input
                        type="text"
                        required
                        value={regName}
                        onChange={(e) => setRegName(e.target.value)}
                        placeholder="e.g. Leo Skywalker"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-[#38BDF8]"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-mono text-[#94A3B8] uppercase block">Assigned Student ID:</label>
                      <input
                        type="text"
                        readOnly
                        value={regStudentId}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/10 border border-white/15 text-[#38BDF8] font-mono text-xs font-bold"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-mono text-[#94A3B8] uppercase block">School / Organization:</label>
                    <div className="relative">
                      <School size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#94A3B8]" />
                      <input
                        type="text"
                        required
                        value={regSchool}
                        onChange={(e) => setRegSchool(e.target.value)}
                        placeholder="e.g. International Space Academy"
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-[#38BDF8]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] font-mono text-[#94A3B8] uppercase block">Academy Grade Level:</label>
                      <select
                        value={regGrade}
                        onChange={(e) => setRegGrade(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-[#0B132B] border border-white/15 text-white font-mono text-xs focus:outline-none"
                      >
                        {GRADES.map((g) => (
                          <option key={g} value={g} className="bg-[#060B18]">
                            {g}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-mono text-[#94A3B8] uppercase block">Mission Specialty:</label>
                      <select
                        value={regSpecialisation}
                        onChange={(e) => setRegSpecialisation(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-xl bg-[#0B132B] border border-white/15 text-white font-mono text-xs focus:outline-none"
                      >
                        {SPECIALIZATIONS.map((s) => (
                          <option key={s} value={s} className="bg-[#060B18]">
                            {s}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] font-mono text-[#94A3B8] uppercase block">Create Passcode:</label>
                      <input
                        type="password"
                        required
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder="••••"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-[#38BDF8]"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[11px] font-mono text-[#94A3B8] uppercase block">Confirm Passcode:</label>
                      <input
                        type="password"
                        required
                        value={regConfirmPassword}
                        onChange={(e) => setRegConfirmPassword(e.target.value)}
                        placeholder="••••"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-[#38BDF8]"
                      />
                    </div>
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      disabled={authStatus === 'authorizing'}
                      className="w-full py-3.5 rounded-full bg-gradient-to-r from-[#38BDF8] via-[#818CF8] to-[#C084FC] hover:brightness-110 text-black font-mono text-xs font-bold tracking-wider uppercase shadow-[0_0_35px_rgba(56,189,248,0.4)] transition-all flex items-center justify-center space-x-2 cursor-pointer active:scale-95"
                    >
                      <GraduationCap size={16} />
                      <span>
                        {authStatus === 'authorizing'
                          ? 'COMMISSIONING CADET PROFILE...'
                          : 'ENROLL & RECEIVE 500 XP WELCOME BONUS'}
                      </span>
                    </button>
                  </div>
                </form>
              )}

              {/* Guest Access Link */}
              <div className="mt-5 pt-4 border-t border-white/10 text-center">
                <button
                  type="button"
                  onClick={onBackToMission}
                  className="text-xs font-mono text-[#94A3B8] hover:text-white transition-colors flex items-center justify-center space-x-1.5 mx-auto cursor-pointer"
                >
                  <span>Continue as Guest Astronaut (No Account Required)</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer Disclaimer */}
      <footer className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-[11px] font-mono text-[#94A3B8]">
        ASTRONAUT-X • NASA Resource-Powered Educational Space Exploration Platform • COPPA/FERPA Educational Compliance (Zero PII Tracked)
      </footer>
    </div>
  );
}
