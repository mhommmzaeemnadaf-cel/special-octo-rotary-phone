import React, { useState, useEffect, useRef } from 'react';
import {
  Orbit, Compass, Play, X, User, Users, Calendar, Clock,
  ChevronLeft, ChevronRight, Activity, Shield, Sparkles,
  Zap, Heart, Thermometer, Wind, AlertTriangle, CheckCircle2,
  Maximize2, Volume2, Info, ArrowRight, Dna, Radio
} from 'lucide-react';
import { soundManager } from '../../utils/audio';
import { useProgress } from '../../context/ProgressContext';

// --- DATA STRUCTURES ---

interface SpaceSuit {
  id: string;
  name: string;
  earthWeightLbs: number;
  continuousUseHours: number;
  motionResistanceKg: string;
  torsoType: string;
  operationalEnvironment: string;
  oxygenCapacityHours: number;
  thermalRange: string;
  pressurePsi: number;
  description: string;
  suitModelSvg: 'emu' | 'xemu' | 'aces' | 'biosuit';
}

const SPACE_SUITS: SpaceSuit[] = [
  {
    id: 'emu',
    name: 'EMU',
    earthWeightLbs: 224,
    continuousUseHours: 8.0,
    motionResistanceKg: '20-28 kg motion resistance',
    torsoType: 'Rear entry hard upper torso',
    operationalEnvironment: 'Low Earth Orbit (ISS Extravehicular Spacewalks)',
    oxygenCapacityHours: 8.5,
    thermalRange: '-150°C to +120°C',
    pressurePsi: 4.3,
    description: 'NASA Extravehicular Mobility Unit. Two-piece semi-rigid suit used aboard the Space Shuttle and International Space Station for complex orbital assembly and maintenance.',
    suitModelSvg: 'emu'
  },
  {
    id: 'xemu',
    name: 'xEMU (Artemis)',
    earthWeightLbs: 268,
    continuousUseHours: 8.5,
    motionResistanceKg: '12-16 kg low-torque bearings',
    torsoType: 'Rear entry modular composite torso',
    operationalEnvironment: 'Lunar South Pole & Deep Space Artemis Missions',
    oxygenCapacityHours: 9.0,
    thermalRange: '-180°C to +130°C',
    pressurePsi: 4.8,
    description: 'Next-Generation Exploration Extravehicular Mobility Unit engineered for Artemis lunar south pole exploration, featuring advanced waist bearings for natural walking and kneeling.',
    suitModelSvg: 'xemu'
  },
  {
    id: 'aces',
    name: 'ACES / MACES',
    earthWeightLbs: 42,
    continuousUseHours: 4.0,
    motionResistanceKg: '8-12 kg high dexterity',
    torsoType: 'Full-pressure soft entry suit',
    operationalEnvironment: 'Launch, Ascent, Abort & Atmospheric Entry',
    oxygenCapacityHours: 4.5,
    thermalRange: '-40°C to +90°C',
    pressurePsi: 3.5,
    description: 'Advanced Crew Escape Suit worn by astronauts during critical dynamic flight phases (launch and landing) providing full cabin depressurization survival and parachute flotation.',
    suitModelSvg: 'aces'
  },
  {
    id: 'biosuit',
    name: 'Mars BioSuit MCP',
    earthWeightLbs: 48,
    continuousUseHours: 12.0,
    motionResistanceKg: '4-8 kg active polymer elastic',
    torsoType: 'Mechanical counter-pressure elastic matrix',
    operationalEnvironment: 'Martian Surface Expeditionary Planetary Geology',
    oxygenCapacityHours: 12.0,
    thermalRange: '-125°C to +20°C',
    pressurePsi: 4.5,
    description: 'Second-skin mechanical counter-pressure spacesuit applying physical pressure directly to the body with memory alloy lines of non-extension, allowing sprint-level Martian field mobility.',
    suitModelSvg: 'biosuit'
  }
];

interface CrewMember {
  id: string;
  name: string;
  callsign: string;
  rank: string;
  role: string;
  evaCount: number;
  evaTime: string;
  avatarUrl: string;
  vitals: {
    heartRate: number;
    oxygenSat: number;
    coreTemp: number;
    metabolicKcalHr: number;
  };
}

const CREW_ROSTER: CrewMember[] = [
  {
    id: 'scott',
    name: 'Scott Kelly',
    callsign: 'SCOTT',
    rank: 'Captain / Commander',
    role: 'Lead EVA Spacewalk Specialist',
    evaCount: 3,
    evaTime: '18 hrs 20 mins',
    avatarUrl: 'https://images.nasa.gov/details/jsc2014e042211',
    vitals: { heartRate: 72, oxygenSat: 99, coreTemp: 36.8, metabolicKcalHr: 285 }
  },
  {
    id: 'christina',
    name: 'Christina Koch',
    callsign: 'CHRISTINA',
    rank: 'Flight Engineer',
    role: 'Historical All-Female EVA Lead',
    evaCount: 6,
    evaTime: '42 hrs 15 mins',
    avatarUrl: 'https://images.nasa.gov/details/jsc2019e054452',
    vitals: { heartRate: 68, oxygenSat: 99, coreTemp: 36.7, metabolicKcalHr: 260 }
  },
  {
    id: 'victor',
    name: 'Victor Glover',
    callsign: 'IKE',
    rank: 'Pilot',
    role: 'Artemis II Lunar Orbit Pilot',
    evaCount: 4,
    evaTime: '26 hrs 07 mins',
    avatarUrl: 'https://images.nasa.gov/details/jsc2020e038812',
    vitals: { heartRate: 74, oxygenSat: 98, coreTemp: 36.9, metabolicKcalHr: 295 }
  },
  {
    id: 'jessica',
    name: 'Jessica Watkins',
    callsign: 'WATKINS',
    rank: 'Mission Specialist',
    role: 'Planetary Geologist & Crew Scientist',
    evaCount: 2,
    evaTime: '14 hrs 32 mins',
    avatarUrl: 'https://images.nasa.gov/details/jsc2021e065518',
    vitals: { heartRate: 66, oxygenSat: 100, coreTemp: 36.6, metabolicKcalHr: 245 }
  }
];

const GALLERY_PHOTOS = [
  {
    id: 'photo-1',
    title: 'ISS Truss Servicing with Canadarm2',
    caption: 'Astronaut conducts an 8-hour EVA installing solar array modification kits 260 miles above the azure waters of the Pacific.',
    url: 'https://images-assets.nasa.gov/image/iss065e000456/iss065e000456~thumb.jpg',
    location: 'Starboard Truss S6',
    orbitSol: 'Expedition 65'
  },
  {
    id: 'photo-2',
    title: 'Canadarm2 Robotic Foot Restraint Flight',
    caption: 'Flight engineer anchored to the robotic Canadarm2 end effector maneuvers large orbital replacement units into position.',
    url: 'https://images-assets.nasa.gov/image/iss056e201323/iss056e201323~thumb.jpg',
    location: 'Mobile Servicing System',
    orbitSol: 'Expedition 56'
  },
  {
    id: 'photo-3',
    title: 'Helmet Visor Orbital Sunrise Reflection',
    caption: 'The gold-coated helmet visor reflects the curving blue horizon of Earth, ISS solar wings, and intense unfiltered solar light.',
    url: 'https://images-assets.nasa.gov/image/iss063e031024/iss063e031024~thumb.jpg',
    location: 'Quest Airlock Egress',
    orbitSol: 'Expedition 63'
  },
  {
    id: 'photo-4',
    title: 'Deep Space Tether & Tool Bag Verification',
    caption: 'Verification of multi-layer thermal insulation blankets and safety tether reels before high-apogee orbital transfer operations.',
    url: 'https://images-assets.nasa.gov/image/iss059e000511/iss059e000511~thumb.jpg',
    location: 'Columbus External Payload Facility',
    orbitSol: 'Expedition 59'
  },
  {
    id: 'photo-5',
    title: 'Artemis Lunar South Pole EVA Mobility Test',
    caption: 'Next-gen xEMU mobility test demonstrating kneeling and soil core sampling under simulated 0.165G lunar gravitational loading.',
    url: 'https://images-assets.nasa.gov/image/art001e000672/art001e000672~thumb.jpg',
    location: 'Shackleton Crater Simulation',
    orbitSol: 'Artemis Field Trial'
  }
];

const TIME_SLOTS = [
  '09:00',
  '09:15',
  '09:30',
  '09:45',
  '10:00',
  '10:15',
  '10:30',
  '10:45',
  '11:00'
];

export default function EvaMissionOperationsHub() {
  const { awardXp } = useProgress();

  // Top Module Selection
  const [activeTab, setActiveTab] = useState<'Internal' | 'Lunar' | 'Mars' | 'Fitness' | 'EVA' | 'PT'>('EVA');

  // Spacesuit Index
  const [suitIndex, setSuitIndex] = useState(0);
  const currentSuit = SPACE_SUITS[suitIndex];

  // Gravity dial value (0.00 to 1.50)
  const [gravityG, setGravityG] = useState(0.44);

  // Calendar & Time selection
  const [selectedDay, setSelectedDay] = useState(12);
  const [selectedMonth, setSelectedMonth] = useState('June 2027');
  const [selectedTime, setSelectedTime] = useState('10:00');

  // Active Gallery Photo
  const [photoIndex, setPhotoIndex] = useState(0);

  // Active Crew Member
  const [crewIndex, setCrewIndex] = useState(0);
  const currentCrew = CREW_ROSTER[crewIndex];
  const [isCrewPickerOpen, setIsCrewPickerOpen] = useState(false);

  // Simulation Modal State
  const [isSimModalOpen, setIsSimModalOpen] = useState(false);
  const [simState, setSimState] = useState<'docked' | 'tethered' | 'repairing' | 'completed'>('docked');
  const [simTimer, setSimTimer] = useState(180); // 3-minute mini simulation
  const [oxygenLevel, setOxygenLevel] = useState(98);
  const [tetherTension, setTetherTension] = useState(42);
  const [repairProgress, setRepairProgress] = useState(0);
  const [showSimSuccessToast, setShowSimSuccessToast] = useState(false);

  // Handle dial rotation drag / click
  const dialRef = useRef<SVGSVGElement | null>(null);
  const [isDraggingDial, setIsDraggingDial] = useState(false);

  const calculateAngleFromPoint = (clientX: number, clientY: number) => {
    if (!dialRef.current) return;
    const rect = dialRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const dx = clientX - centerX;
    const dy = clientY - centerY;

    let deg = Math.atan2(dy, dx) * (180 / Math.PI);
    if (deg < 0) deg += 360;

    // Dial spans 135 deg to 405 deg (270 degrees sweep)
    // 135 deg = 0.0G, 405 (or 45) deg = 1.0G
    let normalized = deg - 135;
    if (normalized < 0) normalized += 360;

    if (normalized <= 270) {
      const g = (normalized / 270) * 1.0;
      setGravityG(parseFloat(g.toFixed(2)));
    }
  };

  const handleDialMouseDown = (e: React.MouseEvent) => {
    setIsDraggingDial(true);
    calculateAngleFromPoint(e.clientX, e.clientY);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDraggingDial) {
        calculateAngleFromPoint(e.clientX, e.clientY);
      }
    };
    const handleMouseUp = () => {
      if (isDraggingDial) {
        setIsDraggingDial(false);
      }
    };
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDraggingDial]);

  // Next / Prev Suit
  const handlePrevSuit = () => {
    soundManager.playClick();
    setSuitIndex((prev) => (prev === 0 ? SPACE_SUITS.length - 1 : prev - 1));
  };

  const handleNextSuit = () => {
    soundManager.playClick();
    setSuitIndex((prev) => (prev === SPACE_SUITS.length - 1 ? 0 : prev + 1));
  };

  // Gallery Navigation
  const handlePrevPhoto = () => {
    soundManager.playClick();
    setPhotoIndex((prev) => (prev === 0 ? GALLERY_PHOTOS.length - 1 : prev - 1));
  };

  const handleNextPhoto = () => {
    soundManager.playClick();
    setPhotoIndex((prev) => (prev === GALLERY_PHOTOS.length - 1 ? 0 : prev + 1));
  };

  // Launch Live Simulation
  const handleStartSimulation = () => {
    soundManager.playLaunch();
    setIsSimModalOpen(true);
    setSimState('tethered');
    setSimTimer(180);
    setRepairProgress(0);
    setOxygenLevel(98);
  };

  // Sim countdown timer
  useEffect(() => {
    if (!isSimModalOpen || simState === 'completed') return;
    const interval = setInterval(() => {
      setSimTimer((prev) => {
        if (prev <= 1) {
          setSimState('completed');
          return 0;
        }
        return prev - 1;
      });

      setOxygenLevel((prev) => Math.max(10, prev - 0.1));
      setTetherTension(Math.floor(35 + Math.random() * 15));
    }, 1000);
    return () => clearInterval(interval);
  }, [isSimModalOpen, simState]);

  // Execute Repair Action in Sim
  const handleExecuteRepairStep = () => {
    soundManager.playClick();
    setRepairProgress((prev) => {
      const next = prev + 25;
      if (next >= 100) {
        setSimState('completed');
        soundManager.playSuccess();
        awardXp(350);
        setShowSimSuccessToast(true);
        setTimeout(() => setShowSimSuccessToast(false), 4500);
        return 100;
      }
      return next;
    });
  };

  // Apparent Weight calculations
  const totalEarthLbs = currentSuit.earthWeightLbs + 175; // Suit + Crew Member
  const apparentWeightLbs = (totalEarthLbs * gravityG).toFixed(1);
  const fallAcceleration = (9.81 * gravityG).toFixed(2);
  const jumpHeightMeters = gravityG > 0 ? (0.55 / gravityG).toFixed(2) : 'Infinite (Orbital Tether)';

  // Calculate arc stroke offset for dial
  // 270 deg full sweep on radius 80 => Circumference of 270 deg = 2 * PI * 80 * (270 / 360) = 376.99
  const arcLength = 2 * Math.PI * 80 * (270 / 360);
  const strokeOffset = arcLength - (arcLength * Math.min(1.0, gravityG / 1.0));

  // Angle in radians for knob handle
  const knobAngleDeg = 135 + Math.min(1.0, gravityG / 1.0) * 270;
  const knobAngleRad = (knobAngleDeg * Math.PI) / 180;
  const knobX = 120 + 80 * Math.cos(knobAngleRad);
  const knobY = 120 + 80 * Math.sin(knobAngleRad);

  return (
    <section id="eva-operations-hub" className="relative w-full py-16 bg-[#0D0E12] text-[#FFFFFF] select-none border-t border-b border-white/10 font-sans">
      
      {/* Background High-Altitude Orbit Vignette */}
      <div className="absolute inset-0 pointer-events-none opacity-40 bg-[radial-gradient(ellipse_at_top,_rgba(91,155,255,0.15),transparent_70%)]" />
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(circle_at_bottom_left,_rgba(0,229,255,0.1),transparent_50%)]" />

      <div className="relative max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 space-y-6">
        
        {/* ================================================================= */}
        {/* 1. TOP SEGMENTED NAVIGATION TABS (Internal | Lunar | Mars | EVA)  */}
        {/* ================================================================= */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#00E5FF] animate-pulse" />
            <span className="font-mono text-xs tracking-widest text-[#00E5FF] uppercase font-bold">
              NASA EVA FLIGHT CONTROL DECK • ORBITAL OPERATIONS
            </span>
          </div>

          {/* Segmented Mode Selector matching exact image */}
          <div className="flex bg-[#16181D] border border-white/15 rounded-lg p-1 space-x-1 font-mono text-xs">
            {(['Internal', 'Lunar', 'Mars', 'Fitness', 'EVA', 'PT'] as const).map((tab) => {
              const isActive = activeTab === tab;
              return (
                <button
                  key={tab}
                  type="button"
                  onClick={() => {
                    soundManager.playClick();
                    setActiveTab(tab);
                  }}
                  className={`px-4 sm:px-6 py-1.5 rounded transition-all cursor-pointer font-bold ${
                    isActive
                      ? 'bg-white text-black shadow-md'
                      : 'text-[#8E939E] hover:text-white hover:bg-white/5'
                  }`}
                >
                  {tab}
                </button>
              );
            })}
          </div>
        </div>

        {/* ================================================================= */}
        {/* 2. TOP SPACEWALK PHOTO STRIP & TELEMETRY GALLERY CAROUSEL         */}
        {/* ================================================================= */}
        <div className="relative rounded-2xl bg-[#16181D]/90 border border-white/10 overflow-hidden shadow-2xl p-2 sm:p-3">
          <div className="relative flex items-center justify-between">
            {/* Prev Photo Arrow */}
            <button
              onClick={handlePrevPhoto}
              className="absolute left-2 z-20 p-2 rounded-full bg-black/70 hover:bg-black text-white/70 hover:text-white border border-white/20 transition-all cursor-pointer backdrop-blur-md"
              title="Previous Mission Photo"
            >
              <ChevronLeft size={20} />
            </button>

            {/* Photo Strip Grid (Single row, responsive) */}
            <div className="w-full grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 overflow-hidden px-8">
              {GALLERY_PHOTOS.map((photo, idx) => {
                const isSelected = photoIndex === idx;
                return (
                  <div
                    key={photo.id}
                    onClick={() => {
                      soundManager.playClick();
                      setPhotoIndex(idx);
                    }}
                    className={`relative rounded-xl overflow-hidden cursor-pointer h-24 sm:h-28 border transition-all duration-300 group ${
                      isSelected
                        ? 'border-[#5B9BFF] ring-2 ring-[#5B9BFF]/40 scale-102 shadow-lg shadow-[#5B9BFF]/20'
                        : 'border-white/10 opacity-70 hover:opacity-100 hover:border-white/30'
                    }`}
                  >
                    <img
                      src={photo.url}
                      alt={photo.title}
                      className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                    <span className="absolute bottom-1.5 left-2 right-2 text-[10px] font-mono text-white truncate font-medium">
                      {photo.title}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Next Photo Arrow */}
            <button
              onClick={handleNextPhoto}
              className="absolute right-2 z-20 p-2 rounded-full bg-black/70 hover:bg-black text-white/70 hover:text-white border border-white/20 transition-all cursor-pointer backdrop-blur-md"
              title="Next Mission Photo"
            >
              <ChevronRight size={20} />
            </button>
          </div>

          {/* Active Photo Info Bar */}
          <div className="mt-2 pt-2 px-3 flex flex-wrap items-center justify-between text-xs font-mono text-[#8E939E] border-t border-white/5">
            <span className="text-white font-medium flex items-center gap-1.5">
              <Info size={13} className="text-[#5B9BFF]" />
              {GALLERY_PHOTOS[photoIndex].title} — <span className="text-[#8E939E]">{GALLERY_PHOTOS[photoIndex].location}</span>
            </span>
            <span className="text-[#5B9BFF] font-bold">
              {GALLERY_PHOTOS[photoIndex].orbitSol}
            </span>
          </div>
        </div>

        {/* ================================================================= */}
        {/* 3. MAIN WORKSPACE (3-COLUMN BENCHMARK FLIGHT TILES)               */}
        {/* ================================================================= */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6 items-stretch">
          
          {/* --------------------------------------------------------------- */}
          {/* TILE 1: SPACESUIT SYSTEMS (EMU)                                 */}
          {/* --------------------------------------------------------------- */}
          <div className="lg:col-span-4 rounded-3xl bg-[#16181D]/90 border border-white/10 p-5 sm:p-6 flex flex-col justify-between shadow-2xl relative overflow-hidden group">
            {/* Top Suit Specifications */}
            <div className="relative z-10 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-display text-2xl font-black text-white tracking-wider">
                    {currentSuit.name}
                  </h3>
                  <span className="text-[10px] font-mono text-[#00E5FF] uppercase tracking-widest block">
                    LIFE SUPPORT PRESSURE SUIT
                  </span>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-mono text-[#8E939E]">
                  {suitIndex + 1} / {SPACE_SUITS.length}
                </span>
              </div>

              {/* Specs Bullet List */}
              <div className="space-y-1 font-mono text-xs text-[#8E939E] border-b border-white/10 pb-3">
                <div className="text-white font-medium">{currentSuit.earthWeightLbs} lbs Earth weight</div>
                <div>{currentSuit.continuousUseHours} hour continual use</div>
                <div>{currentSuit.motionResistanceKg}</div>
                <div>{currentSuit.torsoType}</div>
              </div>
            </div>

            {/* Middle Suit Visual Display with Navigation Arrows */}
            <div className="relative my-4 flex items-center justify-between">
              {/* Previous Suit Button */}
              <button
                type="button"
                onClick={handlePrevSuit}
                className="z-20 p-2.5 rounded-full bg-black/60 hover:bg-black border border-white/15 text-white/80 hover:text-white transition-all cursor-pointer backdrop-blur-md"
                title="Previous Suit Model"
              >
                <ChevronLeft size={22} />
              </button>

              {/* High-Tech Vector Astronaut EMU Illustration */}
              <div className="relative mx-auto w-48 sm:w-56 h-64 flex items-center justify-center">
                {/* Orbital Earth Reflection Halo */}
                <div className="absolute w-40 h-40 rounded-full bg-gradient-to-tr from-[#5B9BFF]/20 to-transparent blur-2xl" />

                {/* Vector Astronaut Suit Figure */}
                <svg viewBox="0 0 200 300" className="w-full h-full drop-shadow-[0_15px_30px_rgba(0,0,0,0.8)]">
                  {/* Helmet Dome */}
                  <ellipse cx="100" cy="55" rx="36" ry="40" fill="#E2E8F0" stroke="#94A3B8" strokeWidth="2.5" />
                  
                  {/* Gold-coated Sun Visor */}
                  <ellipse cx="100" cy="56" rx="26" ry="24" fill="#0A0F1D" stroke="#5B9BFF" strokeWidth="2" />
                  <path d="M 85 45 Q 100 38 115 45 Q 100 70 85 45" fill="#5B9BFF" opacity="0.35" />
                  <circle cx="112" cy="48" r="4" fill="#FFFFFF" opacity="0.6" />

                  {/* Hard Upper Torso (HUT) */}
                  <path d="M 65 95 L 135 95 L 130 180 L 70 180 Z" fill="#F1F5F9" stroke="#94A3B8" strokeWidth="2" />
                  <rect x="80" y="105" width="40" height="25" rx="4" fill="#0F172A" stroke="#38BDF8" strokeWidth="1" />
                  <circle cx="90" cy="117" r="3" fill="#00E5FF" />
                  <circle cx="100" cy="117" r="3" fill="#34D399" />
                  <circle cx="110" cy="117" r="3" fill="#FBBF24" />

                  {/* Primary Life Support Backpack (PLSS) behind shoulders */}
                  <rect x="52" y="80" width="16" height="85" rx="5" fill="#CBD5E1" stroke="#64748B" strokeWidth="1.5" />
                  <rect x="132" y="80" width="16" height="85" rx="5" fill="#CBD5E1" stroke="#64748B" strokeWidth="1.5" />

                  {/* Left Arm and Reinforced Glove */}
                  <path d="M 65 98 L 45 150 L 38 200 L 48 205 L 56 160 L 70 115" fill="#E2E8F0" stroke="#94A3B8" strokeWidth="2" />
                  <ellipse cx="43" cy="202" rx="7" ry="9" fill="#0F172A" stroke="#5B9BFF" strokeWidth="1" />

                  {/* Right Arm and Glove */}
                  <path d="M 135 98 L 155 150 L 162 200 L 152 205 L 144 160 L 130 115" fill="#E2E8F0" stroke="#94A3B8" strokeWidth="2" />
                  <ellipse cx="157" cy="202" rx="7" ry="9" fill="#0F172A" stroke="#5B9BFF" strokeWidth="1" />

                  {/* Lower Torso Assembly & Joint Bearings */}
                  <rect x="74" y="180" width="52" height="15" rx="3" fill="#94A3B8" />

                  {/* Left Leg & Thermal Boot */}
                  <path d="M 76 195 L 68 255 L 62 285 L 82 285 L 88 255 L 94 195 Z" fill="#E2E8F0" stroke="#94A3B8" strokeWidth="2" />
                  <rect x="60" y="282" width="24" height="12" rx="3" fill="#1E293B" stroke="#64748B" strokeWidth="1.5" />

                  {/* Right Leg & Boot */}
                  <path d="M 124 195 L 132 255 L 138 285 L 118 285 L 112 255 L 106 195 Z" fill="#E2E8F0" stroke="#94A3B8" strokeWidth="2" />
                  <rect x="116" y="282" width="24" height="12" rx="3" fill="#1E293B" stroke="#64748B" strokeWidth="1.5" />
                </svg>

                {/* Subsystem Real-Time Telemetry Callout Pills */}
                <div className="absolute top-2 right-0 bg-black/60 border border-white/10 px-2 py-0.5 rounded text-[9px] font-mono text-[#00E5FF]">
                  PLSS: 4.3 PSI
                </div>
                <div className="absolute bottom-6 left-0 bg-black/60 border border-white/10 px-2 py-0.5 rounded text-[9px] font-mono text-[#34D399]">
                  O2: 98%
                </div>
              </div>

              {/* Next Suit Button */}
              <button
                type="button"
                onClick={handleNextSuit}
                className="z-20 p-2.5 rounded-full bg-black/60 hover:bg-black border border-white/15 text-white/80 hover:text-white transition-all cursor-pointer backdrop-blur-md"
                title="Next Suit Model"
              >
                <ChevronRight size={22} />
              </button>
            </div>

            {/* Bottom Suit Quick Switcher Indicator */}
            <div className="flex items-center justify-between text-xs font-mono text-[#8E939E] pt-3 border-t border-white/10">
              <span>Environment:</span>
              <span className="text-white font-bold truncate max-w-[200px]">
                {currentSuit.operationalEnvironment}
              </span>
            </div>
          </div>

          {/* --------------------------------------------------------------- */}
          {/* TILE 2: SET GRAVITY PRECISION RADIAL DIAL                       */}
          {/* --------------------------------------------------------------- */}
          <div className="lg:col-span-4 rounded-3xl bg-[#16181D]/90 border border-white/10 p-5 sm:p-6 flex flex-col justify-between shadow-2xl relative overflow-hidden">
            
            {/* Title */}
            <div className="text-center space-y-1">
              <h3 className="font-display text-lg font-bold text-white tracking-wide">
                Set Gravity
              </h3>
              <p className="text-[11px] font-mono text-[#8E939E]">
                Adjust orbital & planetary gravitational constant
              </p>
            </div>

            {/* Radial SVG Dial (Exact Recreation of Image) */}
            <div className="relative my-auto flex flex-col items-center justify-center py-2">
              <div className="relative w-64 h-64 flex items-center justify-center">
                
                <svg
                  ref={dialRef}
                  width="240"
                  height="240"
                  viewBox="0 0 240 240"
                  className="cursor-pointer select-none"
                  onMouseDown={handleDialMouseDown}
                >
                  {/* Subtle Background Radial Grid Arc */}
                  <circle
                    cx="120"
                    cy="120"
                    r="80"
                    fill="none"
                    stroke="#1E222D"
                    strokeWidth="10"
                    strokeDasharray={arcLength}
                    strokeDashoffset="0"
                    transform="rotate(135 120 120)"
                    strokeLinecap="round"
                  />

                  {/* Graduated Circular Tick Marks (Every 5 deg around 270 sweep) */}
                  {Array.from({ length: 55 }).map((_, i) => {
                    const tickAngle = 135 + (i / 54) * 270;
                    const rad = (tickAngle * Math.PI) / 180;
                    const isMajor = i % 9 === 0;
                    const innerR = isMajor ? 66 : 70;
                    const outerR = 76;
                    const x1 = 120 + innerR * Math.cos(rad);
                    const y1 = 120 + innerR * Math.sin(rad);
                    const x2 = 120 + outerR * Math.cos(rad);
                    const y2 = 120 + outerR * Math.sin(rad);
                    return (
                      <line
                        key={i}
                        x1={x1}
                        y1={y1}
                        x2={x2}
                        y2={y2}
                        stroke={isMajor ? '#94A3B8' : '#2A2F3D'}
                        strokeWidth={isMajor ? '2' : '1'}
                      />
                    );
                  })}

                  {/* Active Sky-Blue Gauge Arc */}
                  <circle
                    cx="120"
                    cy="120"
                    r="80"
                    fill="none"
                    stroke="#5B9BFF"
                    strokeWidth="6"
                    strokeDasharray={arcLength}
                    strokeDashoffset={strokeOffset}
                    transform="rotate(135 120 120)"
                    strokeLinecap="round"
                    className="transition-all duration-75"
                  />

                  {/* Active Dial Knob */}
                  <circle
                    cx={knobX}
                    cy={knobY}
                    r="9"
                    fill="#FFFFFF"
                    stroke="#5B9BFF"
                    strokeWidth="3.5"
                    className="shadow-lg drop-shadow-[0_0_12px_#5B9BFF] cursor-grab active:cursor-grabbing transition-all duration-75"
                  />
                </svg>

                {/* Central Readout matching image: .44G */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                  <div className="flex items-baseline text-[#5B9BFF]">
                    <span className="font-display font-black text-4xl sm:text-5xl tracking-tight text-white">
                      .{Math.floor(gravityG * 100).toString().padStart(2, '0')}
                    </span>
                    <span className="font-mono text-2xl font-bold text-[#5B9BFF] ml-0.5">
                      G
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-[#8E939E] uppercase tracking-wider mt-0.5">
                    {gravityG === 0
                      ? 'Microgravity (0G)'
                      : gravityG === 0.17 || gravityG === 0.16
                      ? 'Moon Gravity'
                      : gravityG === 0.38
                      ? 'Mars Gravity'
                      : gravityG >= 1.0
                      ? 'Earth Surface (1G)'
                      : 'Orbital Delta'}
                  </span>
                </div>

                {/* Outer Perimeter Labels matching exact image */}
                {/* .38G Mars */}
                <button
                  type="button"
                  onClick={() => {
                    soundManager.playClick();
                    setGravityG(0.38);
                  }}
                  className="absolute top-8 left-1 text-[11px] font-mono text-[#8E939E] hover:text-[#5B9BFF] transition-colors cursor-pointer text-left"
                >
                  <span className="text-white font-bold block">.38G</span>
                  <span>Mars</span>
                </button>

                {/* .165G Moon */}
                <button
                  type="button"
                  onClick={() => {
                    soundManager.playClick();
                    setGravityG(0.165);
                  }}
                  className="absolute bottom-8 left-1 text-[11px] font-mono text-[#8E939E] hover:text-[#5B9BFF] transition-colors cursor-pointer text-left"
                >
                  <span className="text-white font-bold block">.165G</span>
                  <span>Moon</span>
                </button>

                {/* 1G Earth */}
                <button
                  type="button"
                  onClick={() => {
                    soundManager.playClick();
                    setGravityG(1.0);
                  }}
                  className="absolute bottom-8 right-2 text-[11px] font-mono text-[#8E939E] hover:text-[#5B9BFF] transition-colors cursor-pointer text-right"
                >
                  <span className="text-white font-bold block">1G Earth</span>
                </button>
              </div>

              {/* Real Physics Calculation Summary */}
              <div className="w-full grid grid-cols-2 gap-2 mt-2 px-2 text-[11px] font-mono bg-black/40 border border-white/5 p-2 rounded-xl">
                <div>
                  <span className="text-[#8E939E] block">Apparent Weight:</span>
                  <span className="text-white font-bold">{apparentWeightLbs} lbs</span>
                </div>
                <div>
                  <span className="text-[#8E939E] block">Fall Accel:</span>
                  <span className="text-[#00E5FF] font-bold">{fallAcceleration} m/s²</span>
                </div>
              </div>
            </div>

            {/* Bottom "Continue" Button matching image */}
            <div className="pt-3">
              <button
                type="button"
                onClick={() => {
                  soundManager.playClick();
                  soundManager.playTelemetryBeep();
                }}
                className="w-full py-2.5 rounded-xl bg-black/60 hover:bg-black border border-white/15 text-white hover:border-[#5B9BFF] font-mono text-xs font-bold transition-all cursor-pointer shadow-md"
              >
                Continue
              </button>
            </div>
          </div>

          {/* --------------------------------------------------------------- */}
          {/* TILE 3: MISSION CALENDAR & TIME SCHEDULER                       */}
          {/* --------------------------------------------------------------- */}
          <div className="lg:col-span-4 rounded-3xl bg-[#16181D]/90 border border-white/10 p-5 sm:p-6 flex flex-col justify-between shadow-2xl relative overflow-hidden">
            
            {/* Header: June 2027 with Navigation Arrows */}
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <button
                  type="button"
                  onClick={() => soundManager.playClick()}
                  className="p-1 text-[#8E939E] hover:text-white cursor-pointer"
                >
                  <ChevronLeft size={16} />
                </button>

                <h3 className="font-display text-sm font-bold text-white tracking-wider">
                  {selectedMonth}
                </h3>

                <button
                  type="button"
                  onClick={() => soundManager.playClick()}
                  className="p-1 text-[#8E939E] hover:text-white cursor-pointer"
                >
                  <ChevronRight size={16} />
                </button>
              </div>

              {/* Calendar Grid + Time Selector Layout */}
              <div className="grid grid-cols-12 gap-3 pt-3 items-start">
                
                {/* Left: 7-Day Calendar Grid */}
                <div className="col-span-8">
                  {/* Days of week header */}
                  <div className="grid grid-cols-7 text-center text-[10px] font-mono text-[#8E939E] mb-2">
                    <span>Sun</span>
                    <span>Mon</span>
                    <span>Tue</span>
                    <span>Wed</span>
                    <span>Thu</span>
                    <span>Fri</span>
                    <span>Sat</span>
                  </div>

                  {/* Calendar day numbers */}
                  <div className="grid grid-cols-7 gap-1 text-center font-mono text-xs">
                    {/* June 2027 starts on Tuesday (offset 2 empty slots) */}
                    <span className="opacity-0">0</span>
                    <span className="opacity-0">0</span>
                    
                    {Array.from({ length: 30 }).map((_, i) => {
                      const day = i + 1;
                      const isSelected = selectedDay === day;
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => {
                            soundManager.playClick();
                            setSelectedDay(day);
                          }}
                          className={`w-7 h-7 sm:w-8 sm:h-8 mx-auto flex items-center justify-center rounded-full text-xs font-medium transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#5B9BFF] text-white font-bold shadow-[0_0_15px_rgba(91,155,255,0.6)]'
                              : 'text-white/80 hover:bg-white/10 hover:text-white'
                          }`}
                        >
                          {day}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Right: Vertical Time Slot List */}
                <div className="col-span-4 space-y-1.5 max-h-56 overflow-y-auto pr-1">
                  {TIME_SLOTS.map((time) => {
                    const isTimeSelected = selectedTime === time;
                    return (
                      <button
                        key={time}
                        type="button"
                        onClick={() => {
                          soundManager.playClick();
                          setSelectedTime(time);
                        }}
                        className={`w-full py-1.5 px-2 rounded-lg text-xs font-mono text-center transition-all cursor-pointer border ${
                          isTimeSelected
                            ? 'bg-[#5B9BFF] border-[#5B9BFF] text-white font-bold shadow-md'
                            : 'bg-black/40 border-white/5 text-[#8E939E] hover:text-white hover:border-white/20'
                        }`}
                      >
                        {time}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Bottom Status Sentence matching image */}
            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#8E939E]">
                  Set EVA for <span className="text-white font-bold">{selectedTime} GMT</span>, on <span className="text-white font-bold">{selectedDay} June, 2027</span>
                </span>
              </div>

              {/* Continue Button */}
              <button
                type="button"
                onClick={handleStartSimulation}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#5B9BFF] to-[#38BDF8] hover:brightness-110 text-white font-mono text-xs font-bold transition-all cursor-pointer shadow-[0_0_20px_rgba(91,155,255,0.35)] flex items-center justify-center space-x-1.5"
              >
                <span>Continue & Lock In EVA Schedule</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* ================================================================= */}
        {/* 4. BOTTOM FLIGHT CONTROL BAR (CREW | SUIT | GRAVITY | PLAY / STOP)*/}
        {/* ================================================================= */}
        <div className="rounded-2xl bg-[#16181D] border border-white/15 p-3 sm:p-4 shadow-2xl flex flex-wrap items-center justify-between gap-3">
          
          {/* Left Cluster: Astronaut Profile & Crew Selector */}
          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={() => {
                soundManager.playClick();
                setIsCrewPickerOpen(!isCrewPickerOpen);
              }}
              className="flex items-center space-x-2.5 p-1.5 pr-3 rounded-xl bg-black/60 hover:bg-black border border-white/10 hover:border-[#00E5FF] transition-all cursor-pointer"
              title="Click to Switch Active Spacewalker"
            >
              {/* Profile Avatar Badge */}
              <div className="relative w-9 h-9 rounded-full overflow-hidden bg-gradient-to-tr from-[#5B9BFF] to-[#00E5FF] flex items-center justify-center font-display font-black text-black text-xs">
                {currentCrew.callsign.slice(0, 2)}
              </div>
              <div className="text-left font-mono">
                <span className="text-[10px] text-[#00E5FF] block uppercase font-bold leading-none">
                  {currentCrew.callsign}
                </span>
                <span className="text-[9px] text-[#8E939E]">
                  {currentCrew.rank}
                </span>
              </div>
            </button>

            {/* Crew Members Icon Pill */}
            <div className="hidden sm:flex items-center px-2.5 py-1.5 rounded-xl bg-black/40 border border-white/5 text-[#00E5FF]">
              <Users size={16} />
            </div>
          </div>

          {/* Center Cluster: Telemetry Badges (Suit, Gravity, Calendar) */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* Spacesuit Badge */}
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 font-mono text-xs">
              <Shield size={14} className="text-[#8E939E]" />
              <span className="text-white font-bold">{currentSuit.name}</span>
            </div>

            {/* Gravity (Falling Apple / Arrow Icon) */}
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 font-mono text-xs">
              <Zap size={14} className="text-[#5B9BFF]" />
              <span className="text-[#5B9BFF] font-bold">.{Math.floor(gravityG * 100).toString().padStart(2, '0')}G</span>
            </div>

            {/* Scheduled Date Badge */}
            <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-black/40 border border-white/10 font-mono text-xs">
              <Calendar size={14} className="text-[#FBBF24]" />
              <span className="text-white font-bold">{selectedDay} Jun {selectedTime}</span>
            </div>
          </div>

          {/* Right Cluster: Play / Abort Action Deck matching image */}
          <div className="flex items-center space-x-2">
            {/* Cyan Play Button ▶ (Launch EVA Simulation) */}
            <button
              type="button"
              onClick={handleStartSimulation}
              className="p-3 rounded-2xl bg-black/60 hover:bg-[#00E5FF]/20 border border-[#00E5FF]/50 text-[#00E5FF] hover:text-white shadow-[0_0_20px_rgba(0,229,255,0.3)] transition-all cursor-pointer flex items-center justify-center active:scale-95"
              title="Execute Spacewalk EVA Simulation [Play]"
            >
              <Play size={20} className="fill-current" />
            </button>

            {/* Red Stop / Cancel Button ✕ */}
            <button
              type="button"
              onClick={() => {
                soundManager.playWarning();
                setGravityG(0.44);
                setSelectedDay(12);
                setSelectedTime('10:00');
                setSuitIndex(0);
              }}
              className="p-3 rounded-2xl bg-black/60 hover:bg-[#FF3B30]/20 border border-[#FF3B30]/50 text-[#FF3B30] hover:text-white shadow-[0_0_20px_rgba(255,59,48,0.25)] transition-all cursor-pointer flex items-center justify-center active:scale-95"
              title="Reset Parameters to Default [Abort]"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Crew Picker Drawer / Modal */}
        {isCrewPickerOpen && (
          <div className="p-4 rounded-2xl bg-[#16181D] border border-white/15 space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between border-b border-white/10 pb-2">
              <span className="text-xs font-mono text-[#00E5FF] uppercase font-bold">
                Select Active Astronaut for Mission:
              </span>
              <button
                type="button"
                onClick={() => setIsCrewPickerOpen(false)}
                className="text-[#8E939E] hover:text-white text-xs font-mono"
              >
                Close
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
              {CREW_ROSTER.map((crew, idx) => {
                const isSelected = crewIndex === idx;
                return (
                  <button
                    key={crew.id}
                    type="button"
                    onClick={() => {
                      soundManager.playClick();
                      setCrewIndex(idx);
                      setIsCrewPickerOpen(false);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#5B9BFF]/20 border-[#5B9BFF] shadow-lg'
                        : 'bg-black/40 border-white/10 hover:border-white/30'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-display font-bold text-sm text-white">{crew.name}</span>
                      <span className="text-[10px] font-mono text-[#00E5FF]">{crew.callsign}</span>
                    </div>
                    <div className="text-[10px] font-mono text-[#8E939E]">{crew.role}</div>
                    <div className="mt-2 text-[9px] font-mono text-[#34D399] flex items-center justify-between">
                      <span>EVAs: {crew.evaCount} ({crew.evaTime})</span>
                      <span>HR: {crew.vitals.heartRate} bpm</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

      </div>

      {/* =================================================================== */}
      {/* 5. INTERACTIVE SPACEWALK FLIGHT SIMULATOR MODAL                     */}
      {/* =================================================================== */}
      {isSimModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-2xl">
          <div className="relative w-full max-w-4xl rounded-3xl bg-[#0D0E12] border border-[#5B9BFF]/40 shadow-[0_0_50px_rgba(91,155,255,0.25)] p-5 sm:p-8 flex flex-col justify-between max-h-[92vh] overflow-y-auto">
            
            {/* Modal Top Bar */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 rounded-full bg-[#00E5FF] animate-ping" />
                <div>
                  <h2 className="font-display text-xl sm:text-2xl font-black text-white tracking-wide">
                    EVA MISSION SIMULATOR: QUEST AIRLOCK EGRESS
                  </h2>
                  <span className="text-xs font-mono text-[#8E939E]">
                    Astronaut: <span className="text-[#00E5FF] font-bold">{currentCrew.name}</span> • Suit: <span className="text-white font-bold">{currentSuit.name}</span> • Gravity: <span className="text-[#5B9BFF] font-bold">.{Math.floor(gravityG * 100)}G</span>
                  </span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  soundManager.playClick();
                  setIsSimModalOpen(false);
                }}
                className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-[#8E939E] hover:text-white transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Spacewalk HUD Screen */}
            <div className="relative my-6 rounded-2xl bg-[#16181D] border border-white/10 p-6 sm:p-8 overflow-hidden min-h-[320px] flex flex-col justify-between">
              
              {/* Background Earth Orbit Graphic */}
              <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(circle_at_50%_120%,#00E5FF_0%,transparent_60%)]" />

              {/* HUD Telemetry Overlay */}
              <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
                <div className="bg-black/60 border border-white/10 px-3 py-1.5 rounded-lg">
                  <span className="text-[#8E939E]">Orbital Velocity: </span>
                  <span className="text-white font-bold">27,600 km/h</span>
                </div>

                <div className="bg-black/60 border border-white/10 px-3 py-1.5 rounded-lg flex items-center space-x-2">
                  <span className="text-[#8E939E]">Oxygen Supply: </span>
                  <span className="text-[#34D399] font-bold">{oxygenLevel.toFixed(1)}%</span>
                </div>

                <div className="bg-black/60 border border-white/10 px-3 py-1.5 rounded-lg flex items-center space-x-2">
                  <span className="text-[#8E939E]">Tether Tension: </span>
                  <span className="text-[#5B9BFF] font-bold">{tetherTension} N</span>
                </div>

                <div className="bg-black/60 border border-white/10 px-3 py-1.5 rounded-lg flex items-center space-x-2">
                  <Clock size={13} className="text-[#FBBF24]" />
                  <span className="text-[#FBBF24] font-bold">
                    {Math.floor(simTimer / 60)}:{(simTimer % 60).toString().padStart(2, '0')}
                  </span>
                </div>
              </div>

              {/* Center Objective Workspace */}
              <div className="relative z-10 my-8 text-center space-y-4">
                {simState !== 'completed' ? (
                  <>
                    <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#00E5FF]/10 border border-[#00E5FF]/40 text-[#00E5FF] text-xs font-mono">
                      <span>MISSION SOL TASK: INSTALL ALPHA MAGNETIC SPECTROMETER HEAT SHIELD</span>
                    </div>

                    <div className="max-w-md mx-auto space-y-2">
                      <div className="flex justify-between text-xs font-mono text-[#8E939E]">
                        <span>Repair Completion:</span>
                        <span className="text-white font-bold">{repairProgress}%</span>
                      </div>
                      <div className="w-full bg-white/10 h-3 rounded-full overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-[#5B9BFF] to-[#00E5FF] h-full transition-all duration-300"
                          style={{ width: `${repairProgress}%` }}
                        />
                      </div>
                    </div>

                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={handleExecuteRepairStep}
                        className="px-6 py-3 rounded-full bg-gradient-to-r from-[#5B9BFF] to-[#00E5FF] hover:brightness-110 text-black font-mono text-xs font-bold tracking-wider uppercase transition-all shadow-lg active:scale-95 cursor-pointer"
                      >
                        ⚡ Tighten Truss Bolts & Connect High-Voltage Cable (+25%)
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="space-y-3 py-4 animate-in zoom-in duration-300">
                    <CheckCircle2 size={48} className="text-[#34D399] mx-auto" />
                    <h3 className="font-display text-2xl font-black text-white">
                      MISSION SUCCESS: EVA EXTRAVEHICULAR OBJECTIVE ACHIEVED
                    </h3>
                    <p className="text-sm font-mono text-[#8E939E] max-w-md mx-auto">
                      All truss mounts secured. Canadarm2 grapple point verified. Primary life support telemetry nominal.
                    </p>
                    <div className="inline-block px-4 py-2 rounded-xl bg-[#FBBF24]/20 border border-[#FBBF24] text-[#FBBF24] font-mono text-xs font-bold">
                      🏆 +350 CADET FLIGHT XP AWARDED
                    </div>
                  </div>
                )}
              </div>

              {/* Bottom Comms Feed */}
              <div className="relative z-10 flex items-center justify-between text-[11px] font-mono text-[#8E939E] border-t border-white/5 pt-3">
                <span className="flex items-center gap-1.5 text-white/90">
                  <Radio size={13} className="text-[#00E5FF]" />
                  CAPCOM AUDIO LINK: "Houston copies telemetry. Air lock repressurization ready on your command."
                </span>
                <span className="text-[#34D399]">CHANNEL 1 // SECURE</span>
              </div>
            </div>

            {/* Modal Bottom Actions */}
            <div className="flex items-center justify-end space-x-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  soundManager.playClick();
                  setIsSimModalOpen(false);
                }}
                className="px-5 py-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white font-mono text-xs transition-colors cursor-pointer"
              >
                Return to Deck
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Success Toast */}
      {showSimSuccessToast && (
        <div className="fixed bottom-6 left-6 z-50 animate-in slide-in-from-bottom duration-300">
          <div className="px-4 py-3 rounded-xl bg-[#16181D] border border-[#34D399] shadow-2xl text-white flex items-center space-x-3">
            <CheckCircle2 size={18} className="text-[#34D399]" />
            <div className="text-xs font-mono">
              <span className="text-[#34D399] font-bold block">EVA TELEMETRY LOGGED:</span>
              <span>Spacewalk flight hours credited to Astronaut dossier!</span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
