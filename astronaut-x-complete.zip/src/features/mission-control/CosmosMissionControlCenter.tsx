import React, { useState, useEffect } from 'react';
import {
  Rocket, Home, Grid, MoreHorizontal, Bell, Activity, Clock,
  Thermometer, Wifi, ArrowRight, Eye, Satellite, Zap, BarChart3,
  Compass, Radio, CheckCircle2, AlertCircle, X, ChevronDown,
  Layers, Globe, Shield, RefreshCw, Volume2, Sparkles, User
} from 'lucide-react';
import { soundManager } from '../../utils/audio';
import { useProgress } from '../../context/ProgressContext';

interface MissionModalContent {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  telemetry: { label: string; value: string; status?: string }[];
  imageSrc: string;
  actionText: string;
  xpReward: number;
}

const MISSIONS_DATA: Record<string, MissionModalContent> = {
  iss: {
    id: 'iss',
    title: 'ISS Live Feed & Orbital Station Telemetry',
    subtitle: 'International Space Station • Low Earth Orbit',
    description: 'Flying at 27,600 km/h approximately 418 kilometers above Earth, the International Space Station serves as a global microgravity laboratory for cutting-edge space biology, materials science, and deep space exploration technologies.',
    telemetry: [
      { label: 'Orbital Velocity', value: '27,580 km/h', status: 'Stable' },
      { label: 'Perigee Altitude', value: '418.2 km', status: '+2% delta' },
      { label: 'Active Crew', value: '7 Expedition Cadets', status: 'Nominal' },
      { label: 'Cabin Atmosphere', value: '14.7 psi (21% O2)', status: 'Optimal' },
    ],
    imageSrc: 'https://images-assets.nasa.gov/image/iss065e000456/iss065e000456~thumb.jpg',
    actionText: 'Connect Live NASA TV Orbital Camera',
    xpReward: 150
  },
  lunar: {
    id: 'lunar',
    title: 'Artemis Lunar Base Camp & Outpost Operations',
    subtitle: 'Shackleton Crater • Lunar South Pole',
    description: 'Artemis Base Camp is the primary surface habitat anchor point for sustainable human presence on the Moon. Automated solar power arrays, regolith sintering additive manufacturing, and deep water-ice extraction in permanently shadowed regions operate at peak capacity.',
    telemetry: [
      { label: 'Surface Power Array', value: '98.7% Output', status: 'Optimal' },
      { label: 'Cryogenic Water Ice Cache', value: '4,280 Liters', status: 'Extracting' },
      { label: 'Hab Thermal Regulation', value: '21.5°C', status: 'Controlled' },
      { label: 'Lunar Rover Fleet', value: '3 / 3 Ready', status: 'Standby' },
    ],
    imageSrc: 'https://images-assets.nasa.gov/image/art001e000672/art001e000672~thumb.jpg',
    actionText: 'Authorize Lunar Surface Habitat Telemetry',
    xpReward: 200
  },
  galaxy: {
    id: 'galaxy',
    title: 'Hubble & Roman Ultra-Deep Field Galaxy Survey',
    subtitle: 'Cosmic Dawn & High-Redshift Survey Division',
    description: 'Targeting deep celestial corridors across the cosmos, multi-wavelength spectroscopic sensors record light emitted over 13.4 billion years ago. Today\'s telemetry stream collected 2.8 Terabytes of raw photonic spectral data.',
    telemetry: [
      { label: 'Data Ingestion Rate', value: '2.8 TB / 24 hr', status: '+0.4 TB today' },
      { label: 'Galaxies Cataloged', value: '142,500 Objects', status: 'Verified' },
      { label: 'Focal Plane Temp', value: '-80°C Cryo', status: 'Cooled' },
      { label: 'Redshift Limit', value: 'z = 11.1', status: 'Max Reach' },
    ],
    imageSrc: 'https://images-assets.nasa.gov/image/weic2208a/weic2208a~thumb.jpg',
    actionText: 'Inspect High-Redshift Spectroscopy Cube',
    xpReward: 175
  },
  mars: {
    id: 'mars',
    title: 'Mars Exploration Hub: Perseverance & Ingenuity Operations',
    subtitle: 'Jezero Crater Delta • Western Fan Deposits',
    description: 'Real-time telemetry and scientific returned data from the Perseverance Rover and Ingenuity rotorcraft. Tracking Martian atmospheric weather, geological coring discoveries, MOXIE oxygen generation, and 237 sealed sample tubes cached for Earth return.',
    telemetry: [
      { label: 'Rock Core Samples', value: '237 Cached', status: '+12% this month' },
      { label: 'Martian Sol', value: 'Sol 1,422', status: 'Spring Equinox' },
      { label: 'MOXIE Oxygen Gen', value: '122 grams O2', status: 'Operational' },
      { label: 'Ambient Pressure', value: '612 Pa (0.089 psi)', status: 'CO2 Atmosphere' },
    ],
    imageSrc: 'https://images-assets.nasa.gov/image/PIA24925/PIA24925~thumb.jpg',
    actionText: 'Acquire Jezero Crater Rover Telemetry',
    xpReward: 250
  },
  jwst: {
    id: 'jwst',
    title: 'James Webb Space Telescope Observatory Operations',
    subtitle: 'Sun-Earth L2 Lagrange Point (1.5 Million KM)',
    description: 'Operating at cryogenic temperatures of 6.4 Kelvin (-266.7°C), the 6.5-meter gold-plated beryllium mirror array penetrates dense cosmic dust clouds to observe star formation, protoplanetary disks, and early galactic chemical signatures.',
    telemetry: [
      { label: 'Mirror Array State', value: '18 / 18 Hex Segments', status: 'All Aligned' },
      { label: 'Cryocooler Core Temp', value: '6.4 Kelvin', status: 'Supercooled' },
      { label: 'NIRCam Sensitivity', value: '0.6 - 5.0 µm', status: 'Nominal' },
      { label: 'Pointing Precision', value: '0.001 arcsec', status: 'Locked on L2' },
    ],
    imageSrc: 'https://images-assets.nasa.gov/image/weic2208a/weic2208a~thumb.jpg',
    actionText: 'Review Latest Infrared Cosmic Discoveries',
    xpReward: 300
  }
};

const COMMANDER_PROFILES = [
  { name: 'Commander Mitchell', initials: 'CM', rank: 'Mission Flight Director', station: 'Houston MCC' },
  { name: 'Commander Vance', initials: 'AV', rank: 'Lead Astrodynamics Pilot', station: 'Goddard STEM' },
  { name: 'Dr. Scott Kelly', initials: 'SK', rank: 'ISS Expedition Commander', station: 'Flight Deck' },
  { name: 'Scientist Chen', initials: 'LC', rank: 'Space Biology Specialist', station: 'Kennedy Space Bio' },
];

export default function CosmosMissionControlCenter() {
  const { awardXp } = useProgress();

  // Navigation tab state
  const [activeTab, setActiveTab] = useState<'Dashboard' | 'Missions' | 'More'>('Dashboard');

  // Commander switcher
  const [commanderIndex, setCommanderIndex] = useState(0);
  const [isCommanderDropdownOpen, setIsCommanderDropdownOpen] = useState(false);
  const currentCommander = COMMANDER_PROFILES[commanderIndex];

  // Live Mission Elapsed Time counter (starts at 452:16:33)
  const [missionSeconds, setMissionSeconds] = useState(452 * 3600 + 16 * 60 + 33);
  const [tempUnit, setTempUnit] = useState<'C' | 'F'>('C');
  const [activeModalMission, setActiveModalMission] = useState<MissionModalContent | null>(null);

  // Notification drawer state
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [hasUnreadAlerts, setHasUnreadAlerts] = useState(true);

  // Ticking mission clock
  useEffect(() => {
    const timer = setInterval(() => {
      setMissionSeconds((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatMissionTime = (totalSec: number) => {
    const hrs = Math.floor(totalSec / 3600);
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const dayNumber = Math.floor(missionSeconds / (24 * 3600));

  // Live Updates marquee ticker
  const [tickerOffset, setTickerOffset] = useState(0);
  const TICKER_ITEMS = [
    'Solar flare detected in sector 7G. Communications may be affected.',
    'Artemis lander successfully deployed new seismic instruments on lunar surface.',
    'ISS crew completes critical EVA maintenance on Starboard solar array.',
    'JWST detects atmospheric water vapor signatures on exoplanet K2-18b.',
    'Perseverance caches sample tube #237 containing delta mudstone sediments.'
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setTickerOffset((prev) => (prev + 1) % TICKER_ITEMS.length);
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  // Open modal handler
  const handleOpenMissionModal = (missionKey: string) => {
    soundManager.playClick();
    const data = MISSIONS_DATA[missionKey];
    if (data) {
      setActiveModalMission(data);
    }
  };

  const handleClaimMissionXp = (xp: number) => {
    soundManager.playSuccess();
    awardXp(xp);
    setActiveModalMission(null);
  };

  return (
    <section id="cosmos-mission-control" className="relative w-full py-12 bg-[#080A12] text-[#F8FAFC] select-none font-sans border-b border-white/10">
      
      {/* Background Deep Cosmic Gradients */}
      <div className="absolute inset-0 pointer-events-none opacity-25 bg-[radial-gradient(ellipse_at_top,_rgba(59,130,246,0.18),transparent_70%)]" />
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[radial-gradient(circle_at_bottom_right,_rgba(124,58,237,0.15),transparent_60%)]" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* ================================================================= */}
        {/* 1. TOP HEADER NAVIGATION BAR MATCHING COSMOS IMAGE                */}
        {/* ================================================================= */}
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
          
          {/* Left Brand Emblem: Blue Rocket Icon + COSMOS */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#2563EB] to-[#60A5FA] flex items-center justify-center text-white shadow-[0_0_20px_rgba(37,99,235,0.5)]">
              <Rocket size={20} className="rotate-45 fill-white" />
            </div>
            <div>
              <span className="font-display font-black text-xl tracking-wider text-white">
                COSMOS
              </span>
              <span className="hidden sm:inline-block ml-2 text-[10px] font-mono uppercase tracking-widest text-[#60A5FA] bg-[#2563EB]/20 px-2 py-0.5 rounded-full border border-[#2563EB]/40">
                ASTRONAUT-X FLIGHT COMMAND
              </span>
            </div>
          </div>

          {/* Center Navigation Pill Cluster (Dashboard, Missions, More) */}
          <nav className="flex items-center bg-[#121624] border border-white/10 rounded-full p-1 font-mono text-xs shadow-lg">
            <button
              type="button"
              onClick={() => {
                soundManager.playClick();
                setActiveTab('Dashboard');
              }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all cursor-pointer font-bold ${
                activeTab === 'Dashboard'
                  ? 'bg-[#2563EB] text-white shadow-[0_0_15px_rgba(37,99,235,0.5)]'
                  : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              <Home size={14} />
              <span>Dashboard</span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundManager.playClick();
                setActiveTab('Missions');
              }}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all cursor-pointer font-bold ${
                activeTab === 'Missions'
                  ? 'bg-[#2563EB] text-white shadow-[0_0_15px_rgba(37,99,235,0.5)]'
                  : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              <Rocket size={14} />
              <span>Missions</span>
            </button>

            <button
              type="button"
              onClick={() => {
                soundManager.playClick();
                setActiveTab('More');
              }}
              className={`flex items-center space-x-1.5 px-3 py-2 rounded-full transition-all cursor-pointer font-bold ${
                activeTab === 'More'
                  ? 'bg-[#2563EB] text-white'
                  : 'text-[#94A3B8] hover:text-white'
              }`}
            >
              <MoreHorizontal size={14} />
              <span>More</span>
            </button>
          </nav>

          {/* Right Commander Profile Dropdown matching CM Commander Mitchell ∨ */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                soundManager.playClick();
                setIsCommanderDropdownOpen(!isCommanderDropdownOpen);
              }}
              className="flex items-center space-x-2.5 px-3 py-1.5 rounded-full bg-[#121624] border border-white/15 hover:border-[#60A5FA] transition-all cursor-pointer shadow-md"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center font-display font-black text-white text-xs shadow-[0_0_10px_rgba(59,130,246,0.4)]">
                {currentCommander.initials}
              </div>
              <span className="font-mono text-xs text-white font-bold hidden sm:inline">
                {currentCommander.name}
              </span>
              <ChevronDown size={14} className="text-[#94A3B8]" />
            </button>

            {/* Profile Dropdown Menu */}
            {isCommanderDropdownOpen && (
              <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-[#121624] border border-white/15 shadow-2xl p-2 z-50 font-mono text-xs animate-in fade-in duration-150">
                <div className="px-3 py-2 border-b border-white/10 text-[11px] text-[#94A3B8]">
                  Select Flight Director Clearance:
                </div>
                {COMMANDER_PROFILES.map((prof, idx) => (
                  <button
                    key={prof.name}
                    onClick={() => {
                      soundManager.playClick();
                      setCommanderIndex(idx);
                      setIsCommanderDropdownOpen(false);
                    }}
                    className={`w-full text-left p-2.5 rounded-xl flex items-center space-x-2.5 transition-all cursor-pointer ${
                      commanderIndex === idx
                        ? 'bg-[#2563EB]/20 border border-[#2563EB] text-white'
                        : 'hover:bg-white/5 text-[#94A3B8] hover:text-white'
                    }`}
                  >
                    <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#3B82F6] to-[#8B5CF6] flex items-center justify-center text-[10px] font-bold text-white shrink-0">
                      {prof.initials}
                    </div>
                    <div>
                      <div className="font-bold text-white leading-tight">{prof.name}</div>
                      <div className="text-[10px] text-[#94A3B8]">{prof.rank}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </header>

        {/* ================================================================= */}
        {/* 2. SUB-HEADER: MISSION CONTROL CENTER • SYSTEMS NOMINAL           */}
        {/* ================================================================= */}
        <div className="flex items-center justify-between font-mono text-xs">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-[#3B82F6] animate-pulse" />
            <span className="tracking-widest text-[#94A3B8] uppercase font-bold">
              MISSION CONTROL CENTER
            </span>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-ping" />
              <span className="tracking-widest text-[#10B981] font-bold uppercase">
                SYSTEMS NOMINAL
              </span>
            </div>

            {/* Notification Bell with Red Badge */}
            <button
              type="button"
              onClick={() => {
                soundManager.playClick();
                setIsNotificationsOpen(!isNotificationsOpen);
                setHasUnreadAlerts(false);
              }}
              className="relative p-2 rounded-full bg-[#121624] border border-white/10 hover:border-white/30 text-white transition-all cursor-pointer"
              title="View NASA Telemetry Alerts"
            >
              <Bell size={16} />
              {hasUnreadAlerts && (
                <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-[#EF4444] animate-pulse" />
              )}
            </button>
          </div>
        </div>

        {/* ================================================================= */}
        {/* 3. ROW OF 4 TELEMETRY KPI BENTO CARDS MATCHING EXACT IMAGE        */}
        {/* ================================================================= */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Card 1: Mission Status (Green Accent) */}
          <div className="rounded-2xl bg-[#0D1E1A]/80 border border-[#10B981]/30 p-5 shadow-lg flex items-center space-x-4 hover:border-[#10B981]/60 transition-all">
            <div className="w-12 h-12 rounded-xl bg-[#10B981]/15 border border-[#10B981]/40 flex items-center justify-center text-[#10B981] shrink-0">
              <Activity size={24} />
            </div>
            <div className="font-mono">
              <span className="text-[11px] text-[#94A3B8] block">Mission Status</span>
              <span className="text-xl font-bold text-white block leading-tight">Active</span>
              <span className="text-[11px] text-[#10B981] font-medium">Nominal</span>
            </div>
          </div>

          {/* Card 2: Mission Time (Blue Accent) - Real Ticking Clock! */}
          <div className="rounded-2xl bg-[#0F1B2E]/80 border border-[#3B82F6]/30 p-5 shadow-lg flex items-center space-x-4 hover:border-[#3B82F6]/60 transition-all">
            <div className="w-12 h-12 rounded-xl bg-[#3B82F6]/15 border border-[#3B82F6]/40 flex items-center justify-center text-[#3B82F6] shrink-0">
              <Clock size={24} />
            </div>
            <div className="font-mono">
              <span className="text-[11px] text-[#94A3B8] block">Mission Time</span>
              <span className="text-xl font-bold text-white block leading-tight tracking-wider">
                {formatMissionTime(missionSeconds)}
              </span>
              <span className="text-[11px] text-[#3B82F6] font-medium">Day {dayNumber}</span>
            </div>
          </div>

          {/* Card 3: External Temp (Amber/Orange Accent) */}
          <div 
            onClick={() => setTempUnit(tempUnit === 'C' ? 'F' : 'C')}
            className="rounded-2xl bg-[#241712]/80 border border-[#F59E0B]/30 p-5 shadow-lg flex items-center space-x-4 hover:border-[#F59E0B]/60 transition-all cursor-pointer"
            title="Click to toggle Celsius / Fahrenheit"
          >
            <div className="w-12 h-12 rounded-xl bg-[#F59E0B]/15 border border-[#F59E0B]/40 flex items-center justify-center text-[#F59E0B] shrink-0">
              <Thermometer size={24} />
            </div>
            <div className="font-mono">
              <span className="text-[11px] text-[#94A3B8] block">External Temp</span>
              <span className="text-xl font-bold text-white block leading-tight">
                {tempUnit === 'C' ? '-173°C' : '-279°F'}
              </span>
              <span className="text-[11px] text-[#F59E0B] font-medium">Normal Range</span>
            </div>
          </div>

          {/* Card 4: Signal Strength (Purple Accent) */}
          <div className="rounded-2xl bg-[#1B142E]/80 border border-[#8B5CF6]/30 p-5 shadow-lg flex items-center space-x-4 hover:border-[#8B5CF6]/60 transition-all">
            <div className="w-12 h-12 rounded-xl bg-[#8B5CF6]/15 border border-[#8B5CF6]/40 flex items-center justify-center text-[#8B5CF6] shrink-0">
              <Wifi size={24} />
            </div>
            <div className="font-mono">
              <span className="text-[11px] text-[#94A3B8] block">Signal Strength</span>
              <span className="text-xl font-bold text-white block leading-tight">97.4%</span>
              <span className="text-[11px] text-[#8B5CF6] font-medium">Strong</span>
            </div>
          </div>
        </div>

        {/* ================================================================= */}
        {/* 4. LIVE UPDATES TICKER BAR MATCHING EXACT IMAGE                   */}
        {/* ================================================================= */}
        <div className="rounded-2xl bg-[#121624]/90 border border-white/10 px-4 py-3 flex items-center space-x-3 overflow-hidden shadow-md">
          {/* Red Pulse Badge */}
          <div className="flex items-center space-x-2 shrink-0 bg-red-950/40 border border-red-500/40 px-2.5 py-1 rounded-full text-xs font-mono text-red-400 font-bold">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
            <span>LIVE UPDATES</span>
          </div>

          {/* Scrolling Ticker Text */}
          <div className="overflow-hidden whitespace-nowrap text-xs font-mono text-[#94A3B8] flex items-center space-x-8">
            <span className="animate-in fade-in duration-300 text-white/90">
              {TICKER_ITEMS[tickerOffset]}
            </span>
            <span className="text-white/20 hidden md:inline">•</span>
            <span className="text-[#94A3B8]/70 hidden md:inline">
              {TICKER_ITEMS[(tickerOffset + 1) % TICKER_ITEMS.length]}
            </span>
          </div>
        </div>

        {/* ================================================================= */}
        {/* 5. FEATURED MISSIONS SECTION (BENTO GRID WITH 5 CARDS)            */}
        {/* ================================================================= */}
        <div className="space-y-4 pt-2">
          
          <div className="flex items-center justify-between">
            <h2 className="font-display text-2xl font-black text-white tracking-wide">
              Featured Missions
            </h2>
            <button
              type="button"
              onClick={() => soundManager.playClick()}
              className="text-xs font-mono text-[#3B82F6] hover:text-[#60A5FA] flex items-center space-x-1 cursor-pointer"
            >
              <span>View all</span>
              <ArrowRight size={14} />
            </button>
          </div>

          {/* BENTO GRID ROW 1: 3 CARDS (ISS, LUNAR, GALAXY) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            
            {/* ---------------- CARD 1: ISS LIVE FEED ---------------- */}
            <div className="relative rounded-3xl bg-[#121624] border border-white/10 p-6 overflow-hidden shadow-xl flex flex-col justify-between min-h-[290px] group hover:border-[#3B82F6]/60 transition-all">
              {/* Background NASA Earth at night image */}
              <div 
                className="absolute inset-0 z-0 bg-cover bg-center opacity-40 group-hover:scale-105 transition-transform duration-700"
                style={{ backgroundImage: `url('https://images-assets.nasa.gov/image/iss065e000456/iss065e000456~thumb.jpg')` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#121624] via-[#121624]/80 to-transparent z-0" />

              {/* Card Header */}
              <div className="relative z-10 space-y-1">
                <div className="flex items-center justify-between text-xs font-mono text-[#94A3B8]">
                  <span className="flex items-center space-x-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#3B82F6]" />
                    <span>International Space Station</span>
                  </span>
                  <span className="text-[#94A3B8]">⋮</span>
                </div>
                <h3 className="font-display text-2xl font-bold text-white">
                  ISS Live Feed
                </h3>
              </div>

              {/* Floating HUD Pill inside */}
              <div className="relative z-10 bg-black/60 backdrop-blur-md border border-white/15 p-3 rounded-2xl flex items-center space-x-3 my-4">
                <div className="w-9 h-9 rounded-xl bg-[#3B82F6]/20 border border-[#3B82F6]/40 flex items-center justify-center text-[#3B82F6]">
                  <Satellite size={18} />
                </div>
                <div className="font-mono text-xs">
                  <span className="text-[#94A3B8] block text-[10px]">Orbit Status</span>
                  <span className="text-white font-bold block">Stable</span>
                  <span className="text-[#3B82F6] text-[10px]">+2% altitude</span>
                </div>
              </div>

              {/* Action Button: View Feed */}
              <div className="relative z-10">
                <button
                  type="button"
                  onClick={() => handleOpenMissionModal('iss')}
                  className="px-5 py-2.5 rounded-full bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-mono text-xs font-bold transition-all shadow-[0_0_15px_rgba(37,99,235,0.4)] cursor-pointer"
                >
                  View Feed
                </button>
              </div>
            </div>

            {/* ---------------- CARD 2: LUNAR BASE OPERATIONS ---------------- */}
            <div className="relative rounded-3xl bg-[#121624] border border-white/10 p-6 overflow-hidden shadow-xl flex flex-col justify-between min-h-[290px] group hover:border-[#8B5CF6]/60 transition-all">
              {/* Background Moon Image */}
              <div 
                className="absolute inset-0 z-0 bg-cover bg-center opacity-40 group-hover:scale-105 transition-transform duration-700"
                style={{ backgroundImage: `url('https://images-assets.nasa.gov/image/as11-40-5903/as11-40-5903~thumb.jpg')` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#121624] via-[#121624]/80 to-transparent z-0" />

              {/* Card Header */}
              <div className="relative z-10 space-y-1">
                <div className="flex items-center justify-between text-xs font-mono text-[#94A3B8]">
                  <span className="flex items-center space-x-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#8B5CF6]" />
                    <span>Artemis Outpost</span>
                  </span>
                  <span className="text-[#94A3B8]">⋮</span>
                </div>
                <h3 className="font-display text-2xl font-bold text-white">
                  Lunar Base Operations
                </h3>
              </div>

              {/* Floating HUD Pill inside */}
              <div className="relative z-10 bg-black/60 backdrop-blur-md border border-white/15 p-3 rounded-2xl flex items-center space-x-3 my-4">
                <div className="w-9 h-9 rounded-xl bg-[#F59E0B]/20 border border-[#F59E0B]/40 flex items-center justify-center text-[#F59E0B]">
                  <Zap size={18} />
                </div>
                <div className="font-mono text-xs">
                  <span className="text-[#94A3B8] block text-[10px]">Power Systems</span>
                  <span className="text-white font-bold block">98.7%</span>
                  <span className="text-[#10B981] text-[10px]">Optimal</span>
                </div>
              </div>

              {/* Action Button: Access → */}
              <div className="relative z-10">
                <button
                  type="button"
                  onClick={() => handleOpenMissionModal('lunar')}
                  className="px-5 py-2.5 rounded-full bg-gradient-to-r from-[#3B82F6] to-[#6366F1] hover:brightness-110 text-white font-mono text-xs font-bold transition-all shadow-md cursor-pointer flex items-center space-x-1.5"
                >
                  <span>Access</span>
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>

            {/* ---------------- CARD 3: GALAXY SURVEY ---------------- */}
            <div className="relative rounded-3xl bg-[#121624] border border-white/10 p-6 overflow-hidden shadow-xl flex flex-col justify-between min-h-[290px] group hover:border-[#06B6D4]/60 transition-all">
              {/* Background Deep Galaxy Image */}
              <div 
                className="absolute inset-0 z-0 bg-cover bg-center opacity-40 group-hover:scale-105 transition-transform duration-700"
                style={{ backgroundImage: `url('https://images-assets.nasa.gov/image/weic2208a/weic2208a~thumb.jpg')` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#121624] via-[#121624]/80 to-transparent z-0" />

              {/* Card Header */}
              <div className="relative z-10 space-y-1">
                <div className="flex items-center justify-between text-xs font-mono text-[#94A3B8]">
                  <span className="flex items-center space-x-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#06B6D4]" />
                    <span>Hubble Deep Field</span>
                  </span>
                  <span className="text-[#94A3B8]">⋮</span>
                </div>
                <h3 className="font-display text-2xl font-bold text-white">
                  Galaxy Survey
                </h3>
              </div>

              {/* Floating HUD Pill inside */}
              <div className="relative z-10 bg-black/60 backdrop-blur-md border border-white/15 p-3 rounded-2xl flex items-center space-x-3 my-4">
                <div className="w-9 h-9 rounded-xl bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 flex items-center justify-center text-[#8B5CF6]">
                  <BarChart3 size={18} />
                </div>
                <div className="font-mono text-xs">
                  <span className="text-[#94A3B8] block text-[10px]">Data Collection</span>
                  <span className="text-white font-bold block">2.8 TB</span>
                  <span className="text-[#06B6D4] text-[10px]">+0.4 TB today</span>
                </div>
              </div>

              {/* Action Button: Eye Icon Pill */}
              <div className="relative z-10">
                <button
                  type="button"
                  onClick={() => handleOpenMissionModal('galaxy')}
                  className="w-10 h-10 rounded-full bg-[#2563EB] hover:bg-[#1D4ED8] text-white flex items-center justify-center transition-all shadow-[0_0_15px_rgba(37,99,235,0.4)] cursor-pointer"
                  title="Inspect Galaxy Survey Dataset"
                >
                  <Eye size={18} />
                </button>
              </div>
            </div>
          </div>

          {/* BENTO GRID ROW 2: 2 CARDS (MARS EXPLORATION HUB & JAMES WEBB OBSERVATORY) */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            
            {/* ---------------- CARD 4 (WIDE): MARS EXPLORATION HUB ---------------- */}
            <div className="lg:col-span-7 relative rounded-3xl bg-[#121624] border border-white/10 p-6 sm:p-8 overflow-hidden shadow-xl flex flex-col justify-between min-h-[310px] group hover:border-[#EF4444]/60 transition-all">
              {/* Background Cupola View of Mars/Earth */}
              <div 
                className="absolute inset-0 z-0 bg-cover bg-center opacity-30 group-hover:scale-105 transition-transform duration-700"
                style={{ backgroundImage: `url('https://images-assets.nasa.gov/image/PIA24925/PIA24925~thumb.jpg')` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#121624] via-[#121624]/85 to-transparent z-0" />

              {/* Header & Description */}
              <div className="relative z-10 space-y-2 max-w-xl">
                <div className="flex items-center justify-between text-xs font-mono text-[#94A3B8]">
                  <span className="text-white font-bold tracking-wide">Mars Exploration Hub</span>
                  <span>⋮</span>
                </div>
                <h3 className="font-display text-2xl sm:text-3xl font-black text-white">
                  Mars Exploration Hub
                </h3>
                <p className="text-xs sm:text-sm text-[#94A3B8] font-normal leading-relaxed">
                  Real-time data from Perseverance and Ingenuity missions. Track atmospheric conditions, geological discoveries, and sample collection progress on the Red Planet.
                </p>
              </div>

              {/* Floating HUD Pill inside */}
              <div className="relative z-10 bg-black/60 backdrop-blur-md border border-white/15 p-3 rounded-2xl flex items-center space-x-3 my-4 w-fit">
                <div className="w-9 h-9 rounded-xl bg-[#EF4444]/20 border border-[#EF4444]/40 flex items-center justify-center text-[#EF4444]">
                  <Compass size={18} />
                </div>
                <div className="font-mono text-xs">
                  <span className="text-[#94A3B8] block text-[10px]">Sample Collection</span>
                  <span className="text-white font-bold block">237 samples</span>
                  <span className="text-[#10B981] text-[10px]">+12% from last week</span>
                </div>
              </div>

              {/* Red/Coral Button: Explore > */}
              <div className="relative z-10">
                <button
                  type="button"
                  onClick={() => handleOpenMissionModal('mars')}
                  className="px-6 py-2.5 rounded-full bg-gradient-to-r from-[#DC2626] to-[#EF4444] hover:brightness-110 text-white font-mono text-xs font-bold transition-all shadow-[0_0_20px_rgba(220,38,38,0.4)] flex items-center space-x-1.5 cursor-pointer"
                >
                  <span>Explore</span>
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>

            {/* ---------------- CARD 5: JAMES WEBB OBSERVATORY (VIBRANT VIOLET) ---------------- */}
            <div className="lg:col-span-5 relative rounded-3xl bg-gradient-to-br from-[#7C3AED] via-[#6D28D9] to-[#5B21B6] border border-[#A78BFA]/40 p-6 sm:p-8 overflow-hidden shadow-2xl flex flex-col justify-between min-h-[310px] group text-white">
              {/* Subtle Cosmic Dust Overlay */}
              <div className="absolute inset-0 z-0 opacity-20 pointer-events-none bg-[radial-gradient(circle_at_top_right,_#FFFFFF_0%,transparent_60%)]" />

              {/* Header & Description */}
              <div className="relative z-10 space-y-2">
                <div className="flex items-center justify-between text-xs font-mono text-white/80">
                  <span className="font-bold tracking-wide">Deep Space Observatory</span>
                  <span>⋮</span>
                </div>
                <h3 className="font-display text-2xl sm:text-3xl font-black text-white">
                  James Webb Observatory
                </h3>
                <p className="text-xs sm:text-sm text-white/90 font-normal leading-relaxed">
                  Infrared observations revealing the birth of stars, exoplanets, and the earliest galaxies formed after the Big Bang.
                </p>
              </div>

              {/* Floating HUD Pill inside */}
              <div className="relative z-10 bg-black/40 backdrop-blur-md border border-white/20 p-3 rounded-2xl flex items-center space-x-3 my-4">
                <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-white">
                  <Activity size={18} />
                </div>
                <div className="font-mono text-xs">
                  <span className="text-white/80 block text-[10px]">System Health</span>
                  <span className="text-white font-bold block">Excellent</span>
                  <span className="text-[#6EE7B7] text-[10px]">All mirrors aligned</span>
                </div>
              </div>

              {/* White Button: View discoveries */}
              <div className="relative z-10">
                <button
                  type="button"
                  onClick={() => handleOpenMissionModal('jwst')}
                  className="px-6 py-2.5 rounded-full bg-white hover:bg-white/90 text-[#5B21B6] font-mono text-xs font-bold transition-all shadow-xl cursor-pointer"
                >
                  View discoveries
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* =================================================================== */}
      {/* 6. INTERACTIVE MISSION DETAILS CONTROL ROOM MODAL                   */}
      {/* =================================================================== */}
      {activeModalMission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-xl">
          <div className="relative w-full max-w-3xl rounded-3xl bg-[#121624] border border-white/20 p-6 sm:p-8 shadow-2xl max-h-[90vh] overflow-y-auto space-y-6">
            
            {/* Header */}
            <div className="flex items-start justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-xs font-mono text-[#3B82F6] uppercase tracking-wider font-bold block">
                  {activeModalMission.subtitle}
                </span>
                <h2 className="font-display text-2xl sm:text-3xl font-black text-white mt-1">
                  {activeModalMission.title}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => {
                  soundManager.playClick();
                  setActiveModalMission(null);
                }}
                className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-[#94A3B8] hover:text-white transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* High-res Image Preview */}
            <div className="relative rounded-2xl overflow-hidden h-56 border border-white/10">
              <img
                src={activeModalMission.imageSrc}
                alt={activeModalMission.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#121624] via-transparent to-transparent" />
            </div>

            {/* Description */}
            <p className="text-sm font-mono text-[#94A3B8] leading-relaxed">
              {activeModalMission.description}
            </p>

            {/* 4 Live Telemetry Pillars */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              {activeModalMission.telemetry.map((t) => (
                <div key={t.label} className="bg-black/50 border border-white/10 p-3 rounded-xl">
                  <span className="text-[10px] text-[#94A3B8] block">{t.label}</span>
                  <span className="text-sm font-bold text-white block mt-0.5">{t.value}</span>
                  {t.status && (
                    <span className="text-[10px] text-[#34D399] block mt-0.5">{t.status}</span>
                  )}
                </div>
              ))}
            </div>

            {/* Modal Bottom Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10">
              <span className="text-xs font-mono text-[#FBBF24] flex items-center space-x-1.5">
                <Sparkles size={14} />
                <span>Completion grants +{activeModalMission.xpReward} XP to your Cadet Profile</span>
              </span>

              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => setActiveModalMission(null)}
                  className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-white font-mono text-xs transition-colors cursor-pointer"
                >
                  Close
                </button>

                <button
                  type="button"
                  onClick={() => handleClaimMissionXp(activeModalMission.xpReward)}
                  className="px-5 py-2 rounded-full bg-gradient-to-r from-[#2563EB] to-[#3B82F6] hover:brightness-110 text-white font-mono text-xs font-bold transition-all shadow-lg cursor-pointer"
                >
                  {activeModalMission.actionText}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =================================================================== */}
      {/* 7. NOTIFICATIONS & ALERTS DRAWER                                    */}
      {/* =================================================================== */}
      {isNotificationsOpen && (
        <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-[#121624] border-l border-white/15 p-6 shadow-2xl flex flex-col justify-between font-mono animate-in slide-in-from-right duration-300">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2">
                <Bell size={18} className="text-[#3B82F6]" />
                <h3 className="font-display font-bold text-white text-base">NASA Telemetry Alerts</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsNotificationsOpen(false)}
                className="text-[#94A3B8] hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-3 overflow-y-auto max-h-[70vh] pr-1 text-xs">
              {TICKER_ITEMS.map((item, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-black/40 border border-white/10 space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-[#94A3B8]">
                    <span className="text-[#3B82F6] font-bold">ALERT #{104 + idx}</span>
                    <span>Just now</span>
                  </div>
                  <p className="text-white/90 leading-relaxed">{item}</p>
                </div>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsNotificationsOpen(false)}
            className="w-full py-2.5 rounded-full bg-white/10 hover:bg-white/15 text-white text-xs font-bold"
          >
            Acknowledge All Alerts
          </button>
        </div>
      )}
    </section>
  );
}
