import React, { useState, useEffect } from 'react';
import {
  Globe, Orbit, Eye, ExternalLink, Sparkles, Database,
  Calendar, Info, AlertCircle, Compass, Radio, Layers, Search,
  Zap, Sun, Shield, Activity, MapPin, Mountain, CheckCircle2, ChevronRight
} from 'lucide-react';
import NasaAttribution from '../../components/NasaAttribution';
import { useProgress } from '../../context/ProgressContext';
import {
  fetchDonkiCmes,
  fetchDonkiFlares,
  calculateSpaceRadiationRisk,
  DonkiCmeEvent,
  DonkiSolarFlare,
  BUNDLED_DONKI_CMES,
  BUNDLED_DONKI_FLARES
} from '../../services/nasa/nasaSpaceWeatherService';
import {
  RADLAB_DOSIMETRY_BENCHMARKS,
  RadLabDosimeterRecord
} from '../../services/nasa/nasaOsdrService';
import {
  MARS_TREK_LOCATIONS,
  MarsTrekLocation
} from '../../services/nasa/marsTrekService';

interface Exoplanet {
  id: string;
  name: string;
  hostStar: string;
  discoveryMethod: string;
  orbitalPeriodDays: number;
  radiusEarthRadii: number;
  equilibriumTempK: number;
  distanceLightYears: number;
  habitableZone: boolean;
  desc: string;
}

const EXOPLANETS: Exoplanet[] = [
  {
    id: 'trappist-1e',
    name: 'TRAPPIST-1 e',
    hostStar: 'TRAPPIST-1 (Ultra-cool Red Dwarf)',
    discoveryMethod: 'Transit Photometry',
    orbitalPeriodDays: 6.1,
    radiusEarthRadii: 0.92,
    equilibriumTempK: 251,
    distanceLightYears: 39.5,
    habitableZone: true,
    desc: 'Rocky Earth-sized world orbiting firmly inside the conservative habitable zone of an M-dwarf star.',
  },
  {
    id: 'kepler-452b',
    name: 'Kepler-452 b',
    hostStar: 'Kepler-452 (G2V Yellow Dwarf, Earth Sun twin)',
    discoveryMethod: 'Transit Photometry',
    orbitalPeriodDays: 384.8,
    radiusEarthRadii: 1.63,
    equilibriumTempK: 265,
    distanceLightYears: 1402,
    habitableZone: true,
    desc: 'First near-Earth-size planet discovered in the habitable zone of a star very similar to our Sun.',
  },
  {
    id: 'proxima-b',
    name: 'Proxima Centauri b',
    hostStar: 'Proxima Centauri (M-type Red Dwarf)',
    discoveryMethod: 'Radial Velocity (Doppler)',
    orbitalPeriodDays: 11.2,
    radiusEarthRadii: 1.08,
    equilibriumTempK: 234,
    distanceLightYears: 4.24,
    habitableZone: true,
    desc: 'The closest known exoplanet to Earth, situated in the Alpha Centauri system.',
  },
  {
    id: 'toi-700d',
    name: 'TOI-700 d',
    hostStar: 'TOI-700 (M-dwarf in Dorado)',
    discoveryMethod: 'TESS Transit Photometry',
    orbitalPeriodDays: 37.4,
    radiusEarthRadii: 1.14,
    equilibriumTempK: 269,
    distanceLightYears: 101.4,
    habitableZone: true,
    desc: 'Discovered by NASA’s Transiting Exoplanet Survey Satellite (TESS), receiving 86% of Earth’s solar flux.',
  },
];

export default function NasaScientificResources() {
  const { awardXp, unlockAchievement } = useProgress();
  const [activeTab, setActiveTab] = useState<'donki' | 'radlab' | 'marstrek' | 'exoplanets' | 'apod' | 'eyes' | 'gibs'>('donki');

  // DONKI State
  const [donkiCmes, setDonkiCmes] = useState<DonkiCmeEvent[]>(BUNDLED_DONKI_CMES);
  const [donkiFlares, setDonkiFlares] = useState<DonkiSolarFlare[]>(BUNDLED_DONKI_FLARES);
  const [selectedCme, setSelectedCme] = useState<DonkiCmeEvent>(BUNDLED_DONKI_CMES[0]);
  const [loadingDonki, setLoadingDonki] = useState(false);

  // RadLab State
  const [selectedDosimeter, setSelectedDosimeter] = useState<RadLabDosimeterRecord>(RADLAB_DOSIMETRY_BENCHMARKS[0]);

  // Mars Trek State
  const [selectedTrekLoc, setSelectedTrekLoc] = useState<MarsTrekLocation>(MARS_TREK_LOCATIONS[0]);

  // Exoplanet State
  const [selectedPlanet, setSelectedPlanet] = useState<Exoplanet>(EXOPLANETS[0]);
  const [transitSlider, setTransitSlider] = useState<number>(50);

  // APOD State
  const [apodData, setApodData] = useState<{
    title: string;
    date: string;
    explanation: string;
    url: string;
    mediaType: string;
    copyright?: string;
  } | null>(null);
  const [loadingApod, setLoadingApod] = useState(false);

  // Fetch DONKI Live
  useEffect(() => {
    if (activeTab === 'donki') {
      setLoadingDonki(true);
      Promise.all([fetchDonkiCmes(30), fetchDonkiFlares(30)])
        .then(([cmes, flares]) => {
          if (cmes?.length) {
            setDonkiCmes(cmes);
            setSelectedCme(cmes[0]);
          }
          if (flares?.length) setDonkiFlares(flares);
          awardXp(50);
          unlockAchievement('donki_heliophysicist');
        })
        .finally(() => setLoadingDonki(false));
    }
  }, [activeTab]);

  // Fetch or fallback APOD
  useEffect(() => {
    if (activeTab === 'apod' && !apodData) {
      setLoadingApod(true);
      fetch('https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY')
        .then((res) => {
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          return res.json();
        })
        .then((data) => {
          setApodData({
            title: data.title || 'Astronomy Picture of the Day',
            date: data.date || '',
            explanation: data.explanation || '',
            url: data.hdurl || data.url || 'https://images-assets.nasa.gov/image/weic2208a/weic2208a~thumb.jpg',
            mediaType: data.media_type || 'image',
            copyright: data.copyright,
          });
          setLoadingApod(false);
        })
        .catch(() => {
          setApodData({
            title: 'Cosmic Cliffs in Carina (NASA James Webb Telescope)',
            date: '2026-11-08',
            explanation:
              'NASA’s James Webb Space Telescope reveals emerging stellar nurseries and individual stars in the Carina Nebula previously obscured by cosmic dust. Called the Cosmic Cliffs, the image appears three-dimensional, resembling craggy mountains on a moonlit evening.',
            url: 'https://images-assets.nasa.gov/image/weic2208a/weic2208a~thumb.jpg',
            mediaType: 'image',
            copyright: 'NASA, ESA, CSA, STScI',
          });
          setLoadingApod(false);
        });
    }
  }, [activeTab, apodData]);

  // Compute transit light dip curve
  const isTransiting = transitSlider >= 35 && transitSlider <= 65;
  const transitDepth = isTransiting
    ? (1 - 0.015 * Math.sin(((transitSlider - 35) / 30) * Math.PI)).toFixed(4)
    : '1.0000';

  const cmeRisk = calculateSpaceRadiationRisk(selectedCme.speedKmS, 'X1.1');

  return (
    <section id="scientific-resources" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#38BDF8]/10 border border-[#38BDF8]/20 text-[#38BDF8] text-xs font-mono uppercase tracking-widest mb-4">
          <Database className="w-3.5 h-3.5" />
          <span>AUTHENTIC NASA & SPACE AGENCY SCIENTIFIC REPOSITORIES</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-display font-extrabold text-[#F5F1E8] tracking-tight mb-4">
          Planetary & Space Science Portals
        </h2>
        <p className="text-[#9298A3] text-sm sm:text-base leading-relaxed">
          Direct scientific telemetry from the Space Weather Database (DONKI), RadLab ISS Radiation Dosimetry, NASA Mars Trek MOLA Elevation, Caltech Exoplanet Archive, and NASA Open APIs.
        </p>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {[
          { id: 'donki', label: 'NASA DONKI Space Weather', icon: Sun },
          { id: 'radlab', label: 'RadLab ISS Dosimetry', icon: Activity },
          { id: 'marstrek', label: 'NASA Mars Trek Topography', icon: Mountain },
          { id: 'exoplanets', label: 'Exoplanet Transit Archive', icon: Orbit },
          { id: 'apod', label: 'Astronomy Picture of the Day', icon: Sparkles },
          { id: 'eyes', label: 'NASA Eyes Guided Missions', icon: Eye },
          { id: 'gibs', label: 'NASA GIBS Earth Observation', icon: Globe },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                if (tab.id === 'marstrek') {
                  awardXp(50);
                  unlockAchievement('mars_trekker');
                }
              }}
              className={`px-3.5 py-2 rounded-xl font-mono text-xs flex items-center space-x-2 transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#C65B43] text-white font-bold shadow-lg shadow-[#C65B43]/20 scale-105'
                  : 'bg-white/[0.04] text-[#9298A3] hover:text-white hover:bg-white/[0.08] border border-white/5'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: NASA DONKI SPACE WEATHER (CME & FLARE DATABASE)                    */}
      {/* ========================================================================= */}
      {activeTab === 'donki' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/30 font-mono text-[10px] uppercase">
                  CCMC / GODDARD SPACE FLIGHT CENTER
                </span>
                {loadingDonki && <span className="text-xs text-[#38BDF8] animate-pulse font-mono">Syncing DONKI Feed...</span>}
              </div>
              <h3 className="text-2xl font-display font-bold text-white mt-1">
                Space Weather Database Of Notifications, Knowledge, Information
              </h3>
              <p className="text-xs text-[#9298A3] mt-1 max-w-2xl">
                Real-world coronal mass ejections, solar flare classifications, and interplanetary shocks driving astronaut radiation hazards and geomagnetic storms.
              </p>
            </div>
            <a
              href="https://ccmc.gsfc.nasa.gov/tools/DONKI/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-mono text-xs border border-white/10"
            >
              <span>NASA DONKI Official Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: CME / Flare Event Selector */}
            <div className="lg:col-span-5 space-y-4">
              <span className="text-xs font-mono text-[#9298A3] uppercase block">
                Active & Benchmark Coronal Ejection Events:
              </span>
              <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
                {donkiCmes.map((cme) => {
                  const isSel = selectedCme.activityID === cme.activityID;
                  return (
                    <button
                      key={cme.activityID}
                      onClick={() => setSelectedCme(cme)}
                      className={`w-full p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isSel
                          ? 'bg-[#C65B43]/20 border-[#C65B43] shadow-[0_0_15px_rgba(198,91,67,0.25)]'
                          : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06]'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-mono font-bold text-xs text-white">
                          {cme.activityID.split('-CME')[0]}
                        </span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/10 text-[#F59E0B]">
                          {cme.speedKmS} km/s
                        </span>
                      </div>
                      <div className="text-[11px] text-[#9298A3] flex items-center justify-between">
                        <span>Source: {cme.sourceLocation}</span>
                        <span className={cme.isEarthDirected ? 'text-[#EF4444]' : 'text-[#34D399]'}>
                          {cme.isEarthDirected ? '● Earth Directed' : '○ Flank / Oblique'}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Flare Snapshot Strip */}
              <div className="bg-white/5 p-3.5 rounded-xl border border-white/10">
                <span className="text-[11px] font-mono text-[#F59E0B] uppercase block mb-2">
                  ⚡ Recent High-Energy Solar Flares (GOES X-Ray):
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  {donkiFlares.slice(0, 4).map((f) => (
                    <div key={f.flrID} className="bg-black/30 p-2 rounded border border-white/5">
                      <div className="flex justify-between">
                        <span className="text-white font-bold">{f.classType}</span>
                        <span className="text-[#9298A3] text-[10px]">{f.sourceLocation}</span>
                      </div>
                      <div className="text-[10px] text-[#9298A3] truncate">{f.peakTime}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: In-Depth Space Weather Hazard Telemetry */}
            <div className="lg:col-span-7 bg-black/40 rounded-xl border border-white/10 p-6 space-y-5">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div>
                  <span className="text-[10px] font-mono text-[#F59E0B] uppercase block">
                    EVENT TELEMETRY RECORD
                  </span>
                  <h4 className="text-xl font-display font-bold text-white mt-0.5">
                    {selectedCme.activityID}
                  </h4>
                </div>
                <div className="text-right font-mono">
                  <span className="text-[10px] text-[#9298A3] block">ESTIMATED KP INDEX</span>
                  <span className="text-lg font-bold text-[#EF4444]">
                    Kp {selectedCme.kpIndexEstimated || 8} (Storm)
                  </span>
                </div>
              </div>

              {/* Metric Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">SHOCK SPEED</span>
                  <span className="text-base font-bold text-[#38BDF8]">{selectedCme.speedKmS} km/s</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">HALF-ANGLE</span>
                  <span className="text-base font-bold text-white">{selectedCme.halfAngleDeg}°</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">CATALOG</span>
                  <span className="text-base font-bold text-[#F59E0B]">{selectedCme.catalog}</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">ACTIVE REGION</span>
                  <span className="text-base font-bold text-white">AR {selectedCme.activeRegionNum || 'Quiet'}</span>
                </div>
              </div>

              {/* Scientific Note */}
              <div className="bg-white/[0.02] p-4 rounded-xl border border-white/5 space-y-2">
                <span className="text-xs font-mono text-[#F5F1E8] font-bold block">
                  NASA Heliophysics Analysis Note:
                </span>
                <p className="text-xs text-[#9298A3] leading-relaxed">
                  {selectedCme.note}
                </p>
                {selectedCme.estimatedArrival && (
                  <div className="text-[11px] font-mono text-[#38BDF8] pt-1">
                    ⏱️ Interplanetary shock arrival window: {selectedCme.estimatedArrival}
                  </div>
                )}
              </div>

              {/* Radiation Risk Calculation Box */}
              <div
                className="p-4 rounded-xl border space-y-2"
                style={{ backgroundColor: `${cmeRisk.color}15`, borderColor: `${cmeRisk.color}50` }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2" style={{ color: cmeRisk.color }}>
                    <Shield className="w-4 h-4" />
                    Astronaut Radiation Hazard: {cmeRisk.level}
                  </span>
                  <span className="text-xs font-mono font-bold text-white">
                    ~{cmeRisk.absorbedDoseRateMicroGyPerHour} µGy / hr
                  </span>
                </div>
                <p className="text-xs text-[#F5F1E8]/90 font-mono">
                  {cmeRisk.evaRecommendation}
                </p>
              </div>

              <div className="pt-2 flex justify-between items-center text-xs font-mono text-[#9298A3]">
                <span>Source: NASA Goddard Space Weather Research Center (DONKI)</span>
                <a
                  href="#space-games-arcade"
                  className="text-[#F59E0B] hover:underline flex items-center gap-1 font-bold"
                >
                  <span>Test in Helios Shield Defender Game</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: RADLAB ISS RADIATION DOSIMETRY DATABASE                            */}
      {/* ========================================================================= */}
      {activeTab === 'radlab' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full bg-[#34D399]/20 text-[#34D399] border border-[#34D399]/30 font-mono text-[10px] uppercase">
                NASA OSDR / RADLAB DOSIMETRY ARCHIVE
              </span>
              <h3 className="text-2xl font-display font-bold text-white mt-1">
                Authentic Astronaut Radiation Dosimetry Observatory
              </h3>
              <p className="text-xs text-[#9298A3] mt-1 max-w-2xl">
                Real radiation dose measurements recorded by dosimetry instruments aboard the International Space Station, contributed by NASA, ESA, JAXA, and CSA.
              </p>
            </div>
            <a
              href="https://visualization.osdr.nasa.gov/radlab/gui/data-api/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-mono text-xs border border-white/10"
            >
              <span>RadLab Data API Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Detector Selection List */}
            <div className="lg:col-span-5 space-y-3">
              <span className="text-xs font-mono text-[#9298A3] uppercase block">
                Dosimetry Detector Stations:
              </span>
              {RADLAB_DOSIMETRY_BENCHMARKS.map((dos) => {
                const isSel = selectedDosimeter.detectorName === dos.detectorName;
                return (
                  <button
                    key={dos.detectorName}
                    onClick={() => setSelectedDosimeter(dos)}
                    className={`w-full p-4 rounded-xl border text-left transition-all cursor-pointer ${
                      isSel
                        ? 'bg-[#34D399]/15 border-[#34D399] shadow-[0_0_15px_rgba(52,211,153,0.2)]'
                        : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-display font-bold text-sm text-white">{dos.module}</span>
                      <span className="font-mono text-xs text-[#34D399] font-bold">
                        {dos.doseEquivalentRateMicroSvDay} µSv/day
                      </span>
                    </div>
                    <div className="text-[11px] text-[#9298A3] font-mono flex items-center justify-between">
                      <span>Agency: {dos.spaceAgency}</span>
                      <span>Depth: {dos.shieldingDepthGramsCm2} g/cm²</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Dosimeter Detail View */}
            <div className="lg:col-span-7 bg-black/40 rounded-xl border border-white/10 p-6 space-y-5">
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <div>
                  <span className="text-[10px] font-mono text-[#34D399] uppercase block">
                    INSTRUMENT TELEMETRY PROFILE
                  </span>
                  <h4 className="text-xl font-display font-bold text-white mt-0.5">
                    {selectedDosimeter.detectorName}
                  </h4>
                </div>
                <span className="px-3 py-1 rounded-full bg-white/5 border border-white/10 font-mono text-xs text-white">
                  {selectedDosimeter.spaceAgency}
                </span>
              </div>

              {/* Radiation Exposure Comparison Bar */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-[#9298A3]">Absorbed Dose Rate:</span>
                  <span className="text-white font-bold">{selectedDosimeter.absorbedDoseRateMicroGyDay} µGy / day</span>
                </div>
                <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-[#34D399] via-[#F59E0B] to-[#EF4444] h-full"
                    style={{ width: `${Math.min(100, (selectedDosimeter.doseEquivalentRateMicroSvDay / 2000) * 100)}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] font-mono text-[#9298A3]">
                  <span>Earth Sea Level (~8 µSv/day)</span>
                  <span>ISS Average (~500 µSv/day)</span>
                  <span>Deep Space Mars Transit (~1,900 µSv/day)</span>
                </div>
              </div>

              {/* Telemetry Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">ORBITAL ALTITUDE</span>
                  <span className="text-base font-bold text-white">
                    {selectedDosimeter.orbitalAltitudeKm.toLocaleString()} km
                  </span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">SOLAR CYCLE</span>
                  <span className="text-base font-bold text-[#F59E0B]">{selectedDosimeter.solarCyclePhase}</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">ALUMINUM SHIELDING</span>
                  <span className="text-base font-bold text-[#38BDF8]">
                    {selectedDosimeter.shieldingDepthGramsCm2} g/cm²
                  </span>
                </div>
              </div>

              {/* Significance Box */}
              <div className="bg-white/[0.03] p-4 rounded-xl border border-white/5 space-y-1">
                <span className="text-xs font-mono text-[#34D399] font-bold block">
                  Operational Health Assessment:
                </span>
                <p className="text-xs text-[#9298A3] leading-relaxed">
                  {selectedDosimeter.significance}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs text-[#F5F1E8] font-mono flex items-center justify-between">
                <span>Annual ISS Cumulative Astronaut Dose: ~150 to 180 mSv</span>
                <span className="text-[#34D399] font-bold">Within 500 mSv NASA Career Cap</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: NASA MARS TREK TERRAIN & MOLA TOPOGRAPHY                           */}
      {/* ========================================================================= */}
      {activeTab === 'marstrek' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <span className="px-2.5 py-0.5 rounded-full bg-[#C65B43]/20 text-[#C65B43] border border-[#C65B43]/30 font-mono text-[10px] uppercase">
                NASA MARS TREK / USGS ASTROGEOLOGY
              </span>
              <h3 className="text-2xl font-display font-bold text-white mt-1">
                Martian Surface Topography & Outpost Site Selection
              </h3>
              <p className="text-xs text-[#9298A3] mt-1 max-w-2xl">
                Explore real MOLA elevation data, atmospheric pressure gradients, and terrain hazards to evaluate optimal candidate zones for human habitation.
              </p>
            </div>
            <a
              href={selectedTrekLoc.trekDirectUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#C65B43] hover:bg-[#b04a33] text-white font-mono text-xs shadow-lg shadow-[#C65B43]/30"
            >
              <span>Launch 3D Mars Trek Interactive</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Landing Site Buttons */}
            <div className="lg:col-span-5 space-y-3">
              <span className="text-xs font-mono text-[#9298A3] uppercase block">
                Survey Candidate Sites:
              </span>
              {MARS_TREK_LOCATIONS.map((loc) => {
                const isSel = selectedTrekLoc.id === loc.id;
                return (
                  <button
                    key={loc.id}
                    onClick={() => setSelectedTrekLoc(loc)}
                    className={`w-full p-4 rounded-xl border text-left transition-all cursor-pointer ${
                      isSel
                        ? 'bg-[#C65B43]/20 border-[#C65B43] shadow-[0_0_15px_rgba(198,91,67,0.25)]'
                        : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-display font-bold text-sm text-white">{loc.name}</span>
                      <span className="px-2 py-0.5 rounded font-mono text-[10px] bg-white/10 text-[#38BDF8]">
                        Score: {loc.outpostFeasibilityScore}/100
                      </span>
                    </div>
                    <div className="text-[11px] text-[#9298A3] font-mono flex items-center justify-between">
                      <span>Elev: {loc.elevationMeters > 0 ? `+${loc.elevationMeters}` : loc.elevationMeters} m</span>
                      <span>{loc.lat}°N, {loc.lon}°E</span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Detailed Topographic Profile */}
            <div className="lg:col-span-7 bg-black/40 rounded-xl border border-white/10 p-6 space-y-5">
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <div>
                  <span className="text-[10px] font-mono text-[#C65B43] uppercase block">
                    SITE SURVEY DOSSIER
                  </span>
                  <h4 className="text-xl font-display font-bold text-white mt-0.5">
                    {selectedTrekLoc.name}
                  </h4>
                  <span className="text-xs text-[#9298A3]">{selectedTrekLoc.subheading}</span>
                </div>
                <div className="text-right font-mono">
                  <span className="text-[10px] text-[#9298A3] block">MOLA ELEVATION</span>
                  <span className="text-base font-bold text-[#38BDF8]">
                    {selectedTrekLoc.elevationMeters > 0 ? `+${selectedTrekLoc.elevationMeters}` : selectedTrekLoc.elevationMeters} m
                  </span>
                </div>
              </div>

              {/* Elevation & Climate Telemetry Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">SURFACE PRESSURE</span>
                  <span className="text-base font-bold text-white">{selectedTrekLoc.atmosphericPressurePascals} Pa</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">THERMAL RANGE</span>
                  <span className="text-base font-bold text-[#F59E0B]">
                    {selectedTrekLoc.temperatureRangeC[0]}°C to {selectedTrekLoc.temperatureRangeC[1]}°C
                  </span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">TERRAIN MORPHOLOGY</span>
                  <span className="text-[11px] font-bold text-[#34D399] truncate block">
                    {selectedTrekLoc.terrainType}
                  </span>
                </div>
              </div>

              {/* Scientific Value */}
              <div className="bg-white/[0.03] p-4 rounded-xl border border-white/5 space-y-1">
                <span className="text-xs font-mono text-[#38BDF8] font-bold block">
                  Astrobiology & Geologic Significance:
                </span>
                <p className="text-xs text-[#9298A3] leading-relaxed">
                  {selectedTrekLoc.scientificValue}
                </p>
              </div>

              {/* Outpost Evaluation Pros / Cons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-3 space-y-1.5">
                  <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Habitat Feasibility Pros:
                  </span>
                  <ul className="text-[11px] text-white/80 space-y-1 list-disc pl-4">
                    {selectedTrekLoc.outpostPros.map((pro, idx) => (
                      <li key={idx}>{pro}</li>
                    ))}
                  </ul>
                </div>

                <div className="bg-amber-950/20 border border-amber-500/20 rounded-xl p-3 space-y-1.5">
                  <span className="text-amber-400 font-bold flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5" />
                    Engineering Constraints:
                  </span>
                  <ul className="text-[11px] text-white/80 space-y-1 list-disc pl-4">
                    {selectedTrekLoc.outpostCons.map((con, idx) => (
                      <li key={idx}>{con}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-2 flex justify-between items-center text-xs font-mono text-[#9298A3]">
                <span>Data: Mars Global Surveyor MOLA & MRO HiRISE</span>
                <a
                  href="#hab-builder"
                  className="text-[#C65B43] hover:underline flex items-center gap-1 font-bold"
                >
                  <span>Build Habitat at this site in Hab Builder</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: NASA EXOPLANET ARCHIVE                                             */}
      {/* ========================================================================= */}
      {activeTab === 'exoplanets' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
            <div>
              <span className="text-xs font-mono text-[#38BDF8] uppercase tracking-wider">
                CALTECH / IPAC EXOPLANET ARCHIVE
              </span>
              <h3 className="text-2xl font-display font-bold text-white mt-1">
                Habitable Zone Exoplanet Explorer
              </h3>
            </div>
            <a
              href="https://exoplanetarchive.ipac.caltech.edu/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-mono text-xs border border-white/10"
            >
              <span>Exoplanet Archive Portal</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-5 space-y-3">
              <span className="text-xs font-mono text-[#9298A3] uppercase block">
                Target Exoplanet Catalog:
              </span>
              {EXOPLANETS.map((planet) => (
                <button
                  key={planet.id}
                  onClick={() => setSelectedPlanet(planet)}
                  className={`w-full p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                    selectedPlanet.id === planet.id
                      ? 'bg-white/10 border-[#38BDF8] shadow-[0_0_15px_rgba(56,189,248,0.2)]'
                      : 'bg-white/[0.02] border-white/10 hover:bg-white/[0.05]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-display font-bold text-sm text-white">
                      {planet.name}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#34D399]/15 text-[#34D399]">
                      Habitable Zone
                    </span>
                  </div>
                  <div className="text-xs text-[#9298A3] font-mono flex items-center justify-between">
                    <span>Host: {planet.hostStar.split(' ')[0]}</span>
                    <span>{planet.distanceLightYears} ly away</span>
                  </div>
                </button>
              ))}
            </div>

            <div className="lg:col-span-7 bg-black/40 rounded-xl border border-white/10 p-6 space-y-6">
              <div className="flex justify-between items-start border-b border-white/10 pb-4">
                <div>
                  <h4 className="text-2xl font-display font-bold text-white">
                    {selectedPlanet.name}
                  </h4>
                  <p className="text-xs font-mono text-[#38BDF8] mt-0.5">
                    {selectedPlanet.hostStar}
                  </p>
                </div>
                <div className="text-right font-mono">
                  <span className="text-xs text-[#9298A3] block">EQUILIBRIUM TEMP</span>
                  <span className="text-lg font-bold text-white">
                    {selectedPlanet.equilibriumTempK} K ({selectedPlanet.equilibriumTempK - 273}°C)
                  </span>
                </div>
              </div>

              {/* Transit Light Curve Simulator */}
              <div className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-3 font-mono">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[#38BDF8] font-bold">
                    🔭 TRANSIT PHOTOMETRY LIGHT CURVE
                  </span>
                  <span className="text-white">Relative Flux: {transitDepth}</span>
                </div>

                <div className="relative h-20 bg-black/50 rounded-lg flex items-center justify-center overflow-hidden border border-white/5">
                  <div className="w-12 h-12 rounded-full bg-[#F59E0B] shadow-[0_0_20px_#F59E0B] absolute left-1/2 -translate-x-1/2" />
                  <div
                    className="w-4 h-4 rounded-full bg-slate-900 border border-slate-600 shadow-md absolute transition-all"
                    style={{ left: `${transitSlider}%` }}
                  />
                  {isTransiting && (
                    <div className="absolute top-2 left-2 text-[10px] text-[#34D399] font-bold animate-pulse">
                      TRANSIT IN PROGRESS: FLUX DROP DETECTED
                    </div>
                  )}
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-[#9298A3]">
                    <span>Orbital Phase Ingress</span>
                    <span>Slider: {transitSlider}%</span>
                    <span>Egress</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={transitSlider}
                    onChange={(e) => setTransitSlider(parseInt(e.target.value))}
                    className="w-full accent-[#38BDF8] cursor-pointer"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">ORBITAL PERIOD</span>
                  <span className="text-base font-bold text-white">{selectedPlanet.orbitalPeriodDays} days</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">RADIUS</span>
                  <span className="text-base font-bold text-white">{selectedPlanet.radiusEarthRadii} R⊕</span>
                </div>
                <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                  <span className="text-[10px] text-[#9298A3] block">METHOD</span>
                  <span className="text-base font-bold text-[#34D399]">{selectedPlanet.discoveryMethod}</span>
                </div>
              </div>

              <p className="text-xs text-[#9298A3] leading-relaxed">
                {selectedPlanet.desc}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 5: ASTRONOMY PICTURE OF THE DAY (APOD)                                 */}
      {/* ========================================================================= */}
      {activeTab === 'apod' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
            <div>
              <span className="text-xs font-mono text-[#F59E0B] uppercase tracking-wider">
                NASA OPEN APIS • ASTRONOMY PICTURE OF THE DAY
              </span>
              <h3 className="text-2xl font-display font-bold text-white mt-1">
                {apodData?.title || 'Loading NASA APOD...'}
              </h3>
              {apodData?.date && (
                <div className="flex items-center space-x-2 text-xs font-mono text-[#9298A3] mt-1">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Release Date: {apodData.date}</span>
                </div>
              )}
            </div>
            <a
              href="https://apod.nasa.gov/apod/astropix.html"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-mono text-xs border border-white/10"
            >
              <span>APOD Archive</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          {loadingApod ? (
            <div className="py-20 text-center font-mono text-sm text-[#9298A3]">
              Contacting NASA Open APIs for today’s imagery...
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7 rounded-xl overflow-hidden border border-white/10 bg-black/60 shadow-inner">
                {apodData?.mediaType === 'video' ? (
                  <iframe
                    src={apodData.url}
                    title={apodData.title}
                    className="w-full h-80 sm:h-96"
                    allowFullScreen
                  />
                ) : (
                  <img
                    src={apodData?.url}
                    alt={apodData?.title}
                    className="w-full h-80 sm:h-96 object-cover hover:scale-105 transition-transform duration-700"
                  />
                )}
              </div>

              <div className="lg:col-span-5 space-y-4">
                <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                  <span className="text-xs font-mono text-[#38BDF8] uppercase tracking-wider block mb-2">
                    SCIENTIFIC EXPLANATION
                  </span>
                  <p className="text-xs text-[#9298A3] leading-relaxed max-h-60 overflow-y-auto pr-1">
                    {apodData?.explanation}
                  </p>
                </div>

                <NasaAttribution
                  nasaId="APOD-LIVE"
                  center="NASA Goddard / Michigan Technological University"
                  creator={apodData?.copyright || 'NASA Public Domain'}
                  nasaUrl="https://apod.nasa.gov/"
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 6: NASA EYES GUIDED MISSIONS                                          */}
      {/* ========================================================================= */}
      {activeTab === 'eyes' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="border-b border-white/10 pb-4">
            <span className="text-xs font-mono text-[#34D399] uppercase tracking-wider">
              NASA JET PROPULSION LABORATORY
            </span>
            <h3 className="text-2xl font-display font-bold text-white mt-1">
              NASA Eyes Interactive Planetary Missions
            </h3>
            <p className="text-xs text-[#9298A3] mt-2">
              NASA Eyes on the Solar System combines real trajectory telemetry with 3D visualization. Fly alongside active spacecraft in real time.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              {
                title: 'Eyes on Asteroids',
                desc: 'Real-time 3D tracking of Near-Earth Objects (NEOs), comets, and planetary defense deflection missions like DART.',
                url: 'https://eyes.nasa.gov/apps/asteroids/',
                tag: 'PLANETARY DEFENSE',
              },
              {
                title: 'Eyes on the Solar System',
                desc: 'Travel anywhere in our solar system from 1950 to 2050. Ride along with Voyager, New Horizons, and Perseverance.',
                url: 'https://eyes.nasa.gov/apps/solar-system/',
                tag: 'REAL-TIME 3D ORRERY',
              },
              {
                title: 'Eyes on Earth',
                desc: 'Monitor Earth’s vital signs: air temperature, carbon dioxide, sea level, ozone, and gravity anomalies.',
                url: 'https://eyes.nasa.gov/apps/earth/',
                tag: 'EARTH OBSERVATION',
              },
            ].map((mission, idx) => (
              <div key={idx} className="p-5 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase text-[#34D399] block mb-1">
                    {mission.tag}
                  </span>
                  <h4 className="font-display font-bold text-base text-white mb-2">{mission.title}</h4>
                  <p className="text-xs text-[#9298A3] leading-relaxed">{mission.desc}</p>
                </div>
                <a
                  href={mission.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 pt-3 border-t border-white/5 inline-flex items-center space-x-1.5 text-xs font-mono text-[#38BDF8] hover:text-[#7dd3fc]"
                >
                  <span>Launch 3D Mission</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 7: NASA GIBS EARTH OBSERVATION                                        */}
      {/* ========================================================================= */}
      {activeTab === 'gibs' && (
        <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="border-b border-white/10 pb-4">
            <span className="text-xs font-mono text-[#38BDF8] uppercase tracking-wider">
              NASA EARTH SCIENCE DATA AND INFORMATION SYSTEM (ESDIS)
            </span>
            <h3 className="text-2xl font-display font-bold text-white mt-1">
              Satellite Observation & Environmental Science
            </h3>
            <p className="text-xs text-[#9298A3] mt-2">
              NASA GIBS provides full-resolution satellite imagery across the globe updated within hours of observation from instruments like MODIS, VIIRS, and AIRS.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              {
                name: 'NASA Worldview Web App',
                url: 'https://worldview.earthdata.nasa.gov/',
                tag: 'INTERACTIVE SATELLITE MAP',
                desc: 'Browse over 1,000 global satellite imagery layers in near real-time. View weather, wildfires, and sea ice changes.',
              },
              {
                name: 'NASA Earthdata Search',
                url: 'https://search.earthdata.nasa.gov/',
                tag: 'PRIMARY EARTH SCIENCE REPOSITORY',
                desc: 'Access petabytes of peer-reviewed Earth science telemetry, atmospheric chemistry, and ocean surface topography.',
              },
              {
                name: 'NASA Scientific Visualization Studio',
                url: 'https://svs.gsfc.nasa.gov/',
                tag: 'SCIENTIFIC ANIMATION LAB',
                desc: 'Cinematic scientific visualizations illustrating black hole accretion disks, magnetic reconnections, and climate models.',
              },
            ].map((res, idx) => (
              <div key={idx} className="p-5 rounded-xl bg-white/[0.03] border border-white/10 flex flex-col justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase text-[#38BDF8] block mb-1">
                    {res.tag}
                  </span>
                  <h4 className="font-display font-bold text-base text-white mb-2">{res.name}</h4>
                  <p className="text-xs text-[#9298A3] leading-relaxed">{res.desc}</p>
                </div>
                <a
                  href={res.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 pt-3 border-t border-white/5 inline-flex items-center space-x-1.5 text-xs font-mono text-[#C65B43] hover:text-[#FF7B59]"
                >
                  <span>Explore Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
