import React, { useState, useEffect, useRef, useTransition } from 'react';
import {
  Search, Video, Image as ImageIcon, Filter, Sparkles, ExternalLink,
  Play, Download, Eye, X, AlertCircle, RefreshCw, ChevronRight,
  Compass, Radio, Layers, Volume2, Maximize2, Bot, Bookmark, Check
} from 'lucide-react';
import {
  NasaMediaItem,
  searchNasaMedia,
  getNasaAssetManifest,
  getNasaVideoUrl,
  getNasaHighResImage,
  getNasaCaptions
} from '../../services/nasa/nasaMediaService';
import NasaAttribution from '../../components/NasaAttribution';

interface NasaMediaExplorerProps {
  onAskAstra?: (context: string) => void;
}

interface CategoryGroup {
  id: string;
  name: string;
  icon: string;
  items: { label: string; query: string }[];
}

const CATEGORIES: CategoryGroup[] = [
  {
    id: 'mars',
    name: 'Mars Exploration',
    icon: '🪐',
    items: [
      { label: 'Perseverance Rover', query: 'perseverance rover' },
      { label: 'Curiosity Rover', query: 'curiosity rover' },
      { label: 'Mars Helicopter', query: 'ingenuity mars helicopter' },
      { label: 'Mars Landscapes', query: 'mars surface landscapes' },
      { label: 'Mars Missions', query: 'mars mission' },
    ],
  },
  {
    id: 'moon',
    name: 'Moon Exploration',
    icon: '🌕',
    items: [
      { label: 'Artemis', query: 'artemis moon' },
      { label: 'Apollo', query: 'apollo 11 moon' },
      { label: 'Lunar Surface', query: 'lunar surface crater' },
      { label: 'Moon Missions', query: 'moon landing mission' },
    ],
  },
  {
    id: 'human-flight',
    name: 'Human Spaceflight',
    icon: '🧑‍🚀',
    items: [
      { label: 'International Space Station', query: 'international space station' },
      { label: 'Astronaut Spacewalk', query: 'astronaut spacewalk eva' },
      { label: 'Life in Space', query: 'astronaut microgravity life' },
      { label: 'Space Suits', query: 'spacesuit astronaut xemu' },
    ],
  },
  {
    id: 'deep-space',
    name: 'Deep Space',
    icon: '🌌',
    items: [
      { label: 'James Webb Telescope', query: 'james webb space telescope' },
      { label: 'Hubble Telescope', query: 'hubble space telescope' },
      { label: 'Galaxies', query: 'spiral galaxy hubble webb' },
      { label: 'Nebulae', query: 'stellar nebula pillars' },
      { label: 'Black Holes', query: 'black hole gravitational' },
    ],
  },
  {
    id: 'earth-science',
    name: 'Earth Science',
    icon: '🌍',
    items: [
      { label: 'Earth from Space', query: 'earth from space blue marble' },
      { label: 'Oceans', query: 'earth oceans satellite' },
      { label: 'Forests', query: 'earth vegetation forest' },
      { label: 'Climate', query: 'earth climate weather observation' },
      { label: 'Natural Disasters', query: 'hurricane volcanic eruption earth' },
    ],
  },
  {
    id: 'rocket-engineering',
    name: 'Rocket Engineering',
    icon: '🚀',
    items: [
      { label: 'Rocket Launches', query: 'rocket launch liftoff' },
      { label: 'Spacecraft', query: 'orion spacecraft capsule' },
      { label: 'Engines', query: 'rocket engine test fire' },
      { label: 'Space Stations', query: 'gateway space station' },
    ],
  },
];

export default function NasaMediaExplorer({ onAskAstra }: NasaMediaExplorerProps) {
  const [query, setQuery] = useState('perseverance rover');
  const [searchInputValue, setSearchInputValue] = useState('perseverance rover');
  const [selectedMediaType, setSelectedMediaType] = useState<'image' | 'video' | 'image,video'>('image,video');
  const [activeCategory, setActiveCategory] = useState<string>('mars');
  const [activeSubItem, setActiveSubItem] = useState<string>('Perseverance Rover');

  const [items, setItems] = useState<NasaMediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [isFallback, setIsFallback] = useState(false);
  const [totalHits, setTotalHits] = useState(0);

  // Selected item for modal
  const [activeModalItem, setActiveModalItem] = useState<NasaMediaItem | null>(null);
  const [modalVideoUrl, setModalVideoUrl] = useState<string | null>(null);
  const [modalHighResUrl, setModalHighResUrl] = useState<string | null>(null);
  const [modalCaptionsUrl, setModalCaptionsUrl] = useState<string | null>(null);
  const [modalLoadingAssets, setModalLoadingAssets] = useState(false);
  const [bookmarkedIds, setBookmarkedIds] = useState<Set<string>>(new Set());

  // Search debounce ref
  const searchTimeoutRef = useRef<any>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Load NASA media on query/filter/page change
  useEffect(() => {
    let isCancelled = false;

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setLoading(true);
    setError(null);

    searchNasaMedia(query, selectedMediaType, page, 16, controller.signal)
      .then((res) => {
        if (isCancelled) return;
        if (page === 1) {
          setItems(res.items);
        } else {
          setItems((prev) => {
            const existingIds = new Set(prev.map((i) => i.nasaId));
            const fresh = res.items.filter((i) => !existingIds.has(i.nasaId));
            return [...prev, ...fresh];
          });
        }
        setIsFallback(res.isFallback);
        setTotalHits(res.totalHits);
        setHasMore(res.items.length >= 12 && page < 10);
        setLoading(false);
      })
      .catch((err) => {
        if (isCancelled) return;
        if (err.name !== 'AbortError') {
          setError(err.message || 'Unable to contact NASA image library');
          setLoading(false);
        }
      });

    return () => {
      isCancelled = true;
      controller.abort();
    };
  }, [query, selectedMediaType, page]);

  // Handle category / tag selection
  const handleSelectSubCategory = (group: CategoryGroup, subItem: { label: string; query: string }) => {
    setActiveCategory(group.id);
    setActiveSubItem(subItem.label);
    setSearchInputValue(subItem.query);
    setQuery(subItem.query);
    setPage(1);
  };

  // Handle manual search input with enter or button
  const handleSearchSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (searchInputValue.trim()) {
      setQuery(searchInputValue.trim());
      setActiveSubItem('');
      setPage(1);
    }
  };

  // Open modal and fetch high-res manifest
  const handleOpenDetailModal = async (item: NasaMediaItem) => {
    setActiveModalItem(item);
    setModalVideoUrl(null);
    setModalHighResUrl(null);
    setModalCaptionsUrl(null);
    setModalLoadingAssets(true);

    try {
      if (item.mediaType === 'video') {
        const [videoUrl, captionsUrl] = await Promise.all([
          getNasaVideoUrl(item.nasaId),
          getNasaCaptions(item.nasaId),
        ]);
        setModalVideoUrl(videoUrl);
        setModalCaptionsUrl(captionsUrl);
      } else {
        const highRes = await getNasaHighResImage(item.nasaId);
        setModalHighResUrl(highRes || item.thumbnail);
      }
    } catch (err) {
      console.warn('Failed loading asset manifest:', err);
    } finally {
      setModalLoadingAssets(false);
    }
  };

  const handleToggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setBookmarkedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <section id="nasa-media-explorer" className="relative py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#38BDF8]/10 border border-[#38BDF8]/20 text-[#38BDF8] text-xs font-mono uppercase tracking-widest mb-4">
          <Sparkles className="w-3.5 h-3.5" />
          <span>OFFICIAL NASA MULTIMEDIA ENGINE</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-display font-bold text-[#F5F1E8] tracking-tight mb-4">
          NASA Media Explorer
        </h2>
        <p className="text-[#9298A3] text-sm sm:text-base leading-relaxed">
          Search over 140,000 authentic photographs, robotic rover panoramas, telemetry captures, and high-definition video archives directly from NASA's Image and Video Library.
        </p>
      </div>

      {/* Offline / Cached notice banner */}
      {isFallback && (
        <div className="mb-6 p-3.5 rounded-xl bg-[#FBBF24]/10 border border-[#FBBF24]/30 text-[#FBBF24] text-xs flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Radio className="w-4 h-4 shrink-0 animate-pulse" />
            <span>
              <strong>Archival Mode:</strong> Displaying high-fidelity cached NASA space archive with real scientific metadata.
            </span>
          </div>
          <button
            onClick={() => { setPage(1); setQuery(query); }}
            className="inline-flex items-center space-x-1 underline hover:text-white transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Retry Link</span>
          </button>
        </div>
      )}

      {/* Explorer Search & Control Console */}
      <div className="bg-[#101827]/80 backdrop-blur-md rounded-2xl border border-white/10 p-5 sm:p-6 mb-8 shadow-2xl">
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-[#9298A3]" />
            <input
              type="text"
              value={searchInputValue}
              onChange={(e) => setSearchInputValue(e.target.value)}
              placeholder="Search Mars, Apollo, James Webb, Artemis, rockets, ISS..."
              className="w-full pl-11 pr-4 py-3 rounded-xl bg-white/[0.05] border border-white/10 text-white placeholder-white/40 font-mono text-sm focus:outline-none focus:border-[#C65B43] focus:ring-1 focus:ring-[#C65B43] transition-all"
            />
            {searchInputValue && (
              <button
                type="button"
                onClick={() => { setSearchInputValue(''); }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Media Type Filter */}
          <div className="flex items-center bg-white/[0.04] p-1 rounded-xl border border-white/10">
            <button
              type="button"
              onClick={() => { setSelectedMediaType('image,video'); setPage(1); }}
              className={`px-3 py-2 rounded-lg font-mono text-xs flex items-center space-x-1.5 transition-all ${
                selectedMediaType === 'image,video'
                  ? 'bg-[#C65B43] text-white font-bold shadow'
                  : 'text-[#9298A3] hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>All</span>
            </button>
            <button
              type="button"
              onClick={() => { setSelectedMediaType('image'); setPage(1); }}
              className={`px-3 py-2 rounded-lg font-mono text-xs flex items-center space-x-1.5 transition-all ${
                selectedMediaType === 'image'
                  ? 'bg-[#C65B43] text-white font-bold shadow'
                  : 'text-[#9298A3] hover:text-white'
              }`}
            >
              <ImageIcon className="w-3.5 h-3.5" />
              <span>Images</span>
            </button>
            <button
              type="button"
              onClick={() => { setSelectedMediaType('video'); setPage(1); }}
              className={`px-3 py-2 rounded-lg font-mono text-xs flex items-center space-x-1.5 transition-all ${
                selectedMediaType === 'video'
                  ? 'bg-[#C65B43] text-white font-bold shadow'
                  : 'text-[#9298A3] hover:text-white'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Videos</span>
            </button>
          </div>

          <button
            type="submit"
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-[#C65B43] to-[#E07A5F] hover:from-[#D76951] hover:to-[#EB896E] text-white font-display font-medium text-sm flex items-center justify-center space-x-2 transition-all shadow-lg shadow-[#C65B43]/20 cursor-pointer"
          >
            <span>Search NASA</span>
            <Search className="w-4 h-4" />
          </button>
        </form>

        {/* Curated Scientific Categories Tabs */}
        <div className="space-y-3 pt-2 border-t border-white/5">
          <div className="flex items-center justify-between text-xs font-mono text-[#9298A3]">
            <span className="flex items-center space-x-1">
              <Compass className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span>EXPLORATION DOMAINS:</span>
            </span>
            <span className="text-[11px] text-white/50">{totalHits > 0 ? `${totalHits.toLocaleString()} results found` : ''}</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setActiveCategory(cat.id);
                  const first = cat.items[0];
                  handleSelectSubCategory(cat, first);
                }}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-mono transition-all flex items-center space-x-2 cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-white/15 text-white border border-[#38BDF8]/50 shadow-[0_0_15px_rgba(56,189,248,0.2)]'
                    : 'bg-white/[0.03] text-[#9298A3] hover:text-white hover:bg-white/[0.08] border border-white/5'
                }`}
              >
                <span>{cat.icon}</span>
                <span>{cat.name}</span>
              </button>
            ))}
          </div>

          {/* Subcategory Pills */}
          {activeCategory && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {CATEGORIES.find((c) => c.id === activeCategory)?.items.map((sub) => (
                <button
                  key={sub.label}
                  onClick={() => handleSelectSubCategory(CATEGORIES.find((c) => c.id === activeCategory)!, sub)}
                  className={`px-3 py-1 rounded-md text-[11px] font-mono transition-all cursor-pointer ${
                    activeSubItem === sub.label
                      ? 'bg-[#C65B43]/20 text-[#FF7B59] border border-[#C65B43]/50'
                      : 'bg-white/[0.02] text-white/60 hover:text-white hover:bg-white/[0.06] border border-white/5'
                  }`}
                >
                  {sub.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Error state */}
      {error && !loading && (
        <div className="p-6 rounded-2xl bg-red-500/10 border border-red-500/20 text-center mb-8">
          <AlertCircle className="w-8 h-8 text-red-400 mx-auto mb-2" />
          <h3 className="text-white font-bold mb-1">NASA API Link Interrupted</h3>
          <p className="text-white/70 text-xs mb-4">{error}</p>
          <button
            onClick={() => { setPage(1); setQuery('mars'); }}
            className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs font-mono"
          >
            Load Curated Mars Library
          </button>
        </div>
      )}

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {loading && page === 1 ? (
          // Loading Skeletons
          Array.from({ length: 8 }).map((_, idx) => (
            <div key={idx} className="rounded-xl overflow-hidden bg-white/[0.03] border border-white/5 animate-pulse">
              <div className="w-full h-52 bg-white/5" />
              <div className="p-4 space-y-3">
                <div className="h-4 bg-white/10 rounded w-3/4" />
                <div className="h-3 bg-white/5 rounded w-full" />
                <div className="h-3 bg-white/5 rounded w-1/2" />
              </div>
            </div>
          ))
        ) : items.length === 0 ? (
          // Empty state
          <div className="col-span-full py-16 text-center">
            <Compass className="w-12 h-12 text-[#9298A3] mx-auto mb-3 opacity-60" />
            <p className="text-white font-display text-lg mb-1">No NASA Assets Found for "{query}"</p>
            <p className="text-[#9298A3] text-xs">Try searching for broader keywords like "mars", "earth", "apollo", or "webb".</p>
          </div>
        ) : (
          items.map((item) => (
            <div
              key={item.nasaId}
              onClick={() => handleOpenDetailModal(item)}
              className="group relative rounded-xl overflow-hidden bg-[#101827]/90 border border-white/10 hover:border-[#C65B43]/60 transition-all duration-300 hover:shadow-[0_8px_30px_rgba(198,91,67,0.2)] cursor-pointer flex flex-col"
            >
              {/* Media Thumbnail */}
              <div className="relative w-full h-52 bg-black/60 overflow-hidden">
                {item.thumbnail ? (
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    loading="lazy"
                    onError={(e) => {
                      // Fallback placeholder image on broken NASA link
                      (e.target as HTMLImageElement).src =
                        'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300"><rect width="400" height="300" fill="%230c121e"/><text x="50%" y="50%" fill="%239298A3" font-family="monospace" font-size="14" text-anchor="middle">NASA Image Archive</text></svg>';
                    }}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-[#0c121e] text-[#9298A3]">
                    {item.mediaType === 'video' ? <Video className="w-10 h-10" /> : <ImageIcon className="w-10 h-10" />}
                  </div>
                )}

                {/* Media Type Badge */}
                <div className="absolute top-2.5 left-2.5 flex items-center space-x-1.5 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[10px] font-mono uppercase text-white/90 border border-white/10">
                  {item.mediaType === 'video' ? (
                    <>
                      <Video className="w-3 h-3 text-[#38BDF8]" />
                      <span>VIDEO</span>
                    </>
                  ) : (
                    <>
                      <ImageIcon className="w-3 h-3 text-[#34D399]" />
                      <span>IMAGE</span>
                    </>
                  )}
                </div>

                {/* Bookmark Button */}
                <button
                  type="button"
                  onClick={(e) => handleToggleBookmark(item.nasaId, e)}
                  aria-label="Bookmark item"
                  className="absolute top-2.5 right-2.5 p-1.5 rounded-full bg-black/60 backdrop-blur-md text-white/70 hover:text-white hover:bg-black/80 transition-all border border-white/10"
                >
                  <Bookmark
                    className={`w-3.5 h-3.5 ${
                      bookmarkedIds.has(item.nasaId) ? 'fill-[#C65B43] text-[#C65B43]' : ''
                    }`}
                  />
                </button>

                {/* Video Play Overlay */}
                {item.mediaType === 'video' && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/10 transition-colors">
                    <div className="w-11 h-11 rounded-full bg-[#C65B43]/90 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <Play className="w-5 h-5 ml-0.5 fill-white" />
                    </div>
                  </div>
                )}
              </div>

              {/* Card Metadata */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono text-[#9298A3] mb-1.5">
                    <span>{item.nasaCenter || 'NASA'}</span>
                    <span>
                      {item.dateCreated
                        ? new Date(item.dateCreated).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })
                        : ''}
                    </span>
                  </div>
                  <h3 className="font-display font-bold text-sm text-[#F5F1E8] line-clamp-2 mb-2 group-hover:text-[#FF7B59] transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-[#9298A3] line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Attribution link preview */}
                <div className="mt-4 pt-2.5 border-t border-white/5 flex items-center justify-between text-[11px] font-mono">
                  <span className="text-[#38BDF8] text-[10px]">NASA ID: {item.nasaId}</span>
                  <span className="text-[#C65B43] flex items-center space-x-1 group-hover:translate-x-0.5 transition-transform">
                    <span>Inspect</span>
                    <ChevronRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Pagination / Load More Button */}
      {hasMore && !loading && items.length > 0 && (
        <div className="mt-12 text-center">
          <button
            onClick={() => setPage((p) => p + 1)}
            className="px-8 py-3 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/15 text-white font-mono text-xs uppercase tracking-wider transition-all inline-flex items-center space-x-2 cursor-pointer"
          >
            <span>Load More NASA Results</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {loading && page > 1 && (
        <div className="mt-8 text-center text-xs font-mono text-[#9298A3]">
          Loading additional NASA archives...
        </div>
      )}

      {/* ======================================================== */}
      {/* IMPRESSIVE MEDIA DETAIL MODAL WITH VIDEO PLAYER & ATTRIBUTION */}
      {/* ======================================================== */}
      {activeModalItem && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200"
          onClick={() => setActiveModalItem(null)}
        >
          <div
            className="relative w-full max-w-4xl bg-[#0F172A] border border-white/20 rounded-2xl overflow-hidden shadow-2xl my-auto text-left flex flex-col max-h-[92vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#0A0F1D]">
              <div className="flex items-center space-x-3 truncate">
                <span className="px-2.5 py-1 rounded text-[10px] font-mono uppercase font-bold tracking-wider bg-[#C65B43]/20 text-[#FF7B59] border border-[#C65B43]/40">
                  {activeModalItem.mediaType.toUpperCase()}
                </span>
                <span className="font-mono text-xs text-[#9298A3] truncate">
                  NASA ID: {activeModalItem.nasaId}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActiveModalItem(null)}
                aria-label="Close modal"
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content Scroll Area */}
            <div className="p-6 overflow-y-auto space-y-6">
              {/* Media Player / Display Box */}
              <div className="relative rounded-xl overflow-hidden bg-black border border-white/10 flex items-center justify-center min-h-[300px] max-h-[500px]">
                {modalLoadingAssets ? (
                  <div className="flex flex-col items-center space-x-2 text-xs font-mono text-[#9298A3] py-16">
                    <RefreshCw className="w-6 h-6 animate-spin text-[#C65B43] mb-3" />
                    <span>Resolving high-resolution NASA asset manifest...</span>
                  </div>
                ) : activeModalItem.mediaType === 'video' ? (
                  modalVideoUrl ? (
                    <video
                      controls
                      autoPlay
                      playsInline
                      className="w-full max-h-[480px] object-contain rounded-lg"
                      poster={activeModalItem.thumbnail}
                    >
                      <source src={modalVideoUrl} type="video/mp4" />
                      {modalCaptionsUrl && (
                        <track src={modalCaptionsUrl} kind="subtitles" srcLang="en" label="English" default />
                      )}
                      Your browser does not support HTML5 video playback.
                    </video>
                  ) : (
                    <div className="p-8 text-center text-xs font-mono text-[#9298A3]">
                      <Video className="w-8 h-8 mx-auto mb-2 opacity-50 text-[#C65B43]" />
                      <p className="text-white mb-2">Video manifest does not have direct MP4 stream available.</p>
                      <a
                        href={activeModalItem.nasaUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-1 px-3 py-1.5 rounded bg-[#C65B43] text-white hover:bg-[#D76951]"
                      >
                        <span>Open Video on NASA Portal</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  )
                ) : (
                  <img
                    src={modalHighResUrl || activeModalItem.thumbnail}
                    alt={activeModalItem.title}
                    className="w-full max-h-[480px] object-contain rounded-lg"
                  />
                )}
              </div>

              {/* Title & Description */}
              <div>
                <h3 id="modal-title" className="text-xl sm:text-2xl font-display font-bold text-[#F5F1E8] mb-3 leading-snug">
                  {activeModalItem.title}
                </h3>
                <p className="text-sm text-[#9298A3] leading-relaxed whitespace-pre-line">
                  {activeModalItem.description}
                </p>
              </div>

              {/* Keywords */}
              {activeModalItem.keywords && activeModalItem.keywords.length > 0 && (
                <div>
                  <div className="text-[11px] font-mono text-[#9298A3] mb-2 uppercase tracking-wider">
                    Scientific Keywords:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {activeModalItem.keywords.slice(0, 10).map((kw, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-0.5 rounded-full bg-white/[0.04] border border-white/10 text-white/80 font-mono text-[10px]"
                      >
                        {kw}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Interactive Educational Actions */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-[#C65B43]/15 to-[#38BDF8]/15 border border-white/10 flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="font-display font-bold text-sm text-white flex items-center space-x-2">
                    <Bot className="w-4 h-4 text-[#38BDF8]" />
                    <span>Want to learn more about this discovery?</span>
                  </div>
                  <div className="text-xs text-[#9298A3]">
                    Ask ASTRA AI to explain the astrophysics or engineering behind this NASA asset.
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const ctx = `Can you explain the NASA asset "${activeModalItem.title}" (NASA ID: ${activeModalItem.nasaId})? Here is its description: ${activeModalItem.description.slice(0, 300)}...`;
                    if (onAskAstra) onAskAstra(ctx);
                    setActiveModalItem(null);
                  }}
                  className="px-4 py-2 rounded-lg bg-[#38BDF8] hover:bg-[#0284C7] text-[#080B12] font-mono font-bold text-xs flex items-center space-x-2 transition-all cursor-pointer"
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>Explain with ASTRA AI</span>
                </button>
              </div>

              {/* Full Attribution & Rights Component */}
              <NasaAttribution
                nasaId={activeModalItem.nasaId}
                nasaUrl={activeModalItem.nasaUrl}
                photographer={activeModalItem.photographer}
                nasaCenter={activeModalItem.nasaCenter}
                dateCreated={activeModalItem.dateCreated}
                compact={false}
                showDisclaimer={true}
              />
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-4 border-t border-white/10 bg-[#0A0F1D] flex flex-wrap items-center justify-between gap-2">
              <span className="font-mono text-[11px] text-[#9298A3]">
                NASA Image & Video Library Public Domain Archive
              </span>
              <div className="flex items-center space-x-2">
                <a
                  href={modalHighResUrl || modalVideoUrl || activeModalItem.thumbnail}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-xs flex items-center space-x-1.5 transition-colors"
                >
                  <Download className="w-3 h-3" />
                  <span>Download File</span>
                </a>
                <a
                  href={activeModalItem.nasaUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-1.5 rounded-lg bg-[#C65B43] hover:bg-[#D76951] text-white font-mono text-xs flex items-center space-x-1.5 transition-colors font-medium"
                >
                  <span>Open NASA Page</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
