import React, { useState, useRef, useEffect } from 'react';
import {
  Bot, Send, Sparkles, X, ChevronDown, BookOpen, Lightbulb,
  CheckCircle2, AlertTriangle, ShieldCheck, HelpCircle, Layers,
  Flame, RefreshCw, Zap, Compass, Star
} from 'lucide-react';
import { useProgress } from '../../context/ProgressContext';

export type ExplanationLevel = 'BEGINNER' | 'EXPLORER' | 'SCIENTIST';

export type ResponseBadge =
  | 'VERIFIED_SCIENTIFIC'
  | 'SIMPLIFIED_EDUCATIONAL'
  | 'SIMULATED_GAME'
  | 'AI_GENERATED';

interface AstraMessage {
  id: string;
  sender: 'user' | 'astra';
  text: string;
  level?: ExplanationLevel;
  badge?: ResponseBadge;
  quiz?: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
  suggestedAction?: {
    label: string;
    onClick: () => void;
  };
}

interface AstraAssistantProps {
  isOpen: boolean;
  onClose: () => void;
  initialPrompt?: string;
  onNavigateSection?: (sectionId: string) => void;
}

// Local Knowledge Base for Offline & Deterministic Child-Safe Intelligence
interface KnowledgeEntry {
  keywords: string[];
  beginner: string;
  explorer: string;
  scientist: string;
  badge: ResponseBadge;
}

const KNOWLEDGE_BASE: KnowledgeEntry[] = [
  {
    keywords: ['gravity', '0.38g', 'fall', 'weight', 'jump', 'mass'],
    beginner:
      'On Mars, gravity is like wearing super-bouncy shoes! Mars is smaller than Earth, so it pulls you down with only 38% of the force. If you weigh 100 pounds on Earth, you weigh only 38 pounds on Mars, and you can jump almost three times as high!',
    explorer:
      'Martian gravitational acceleration is 3.72 m/s², compared to Earth’s 9.81 m/s² (0.38g). This reduced gravity decreases ballistic descent velocity, meaning rovers encounter less traction and astronauts risk bone and muscle atrophy during long stays.',
    scientist:
      'Surface gravitational acceleration g = G*M/r². With Mars having mass M ≈ 6.417 × 10²³ kg and mean radius r ≈ 3389.5 km, g_Mars ≈ 3.721 m/s² (0.3794g). Escape velocity is 5.03 km/s compared to Earth’s 11.19 km/s, significantly reducing orbital insertion Delta-V budgets.',
    badge: 'VERIFIED_SCIENTIFIC',
  },
  {
    keywords: ['moxie', 'oxygen', 'air', 'breathe', 'eclss', 'atmosphere'],
    beginner:
      'Mars air is 95% carbon dioxide, which we cannot breathe! But NASA built a toaster-sized machine called MOXIE on the Perseverance rover. MOXIE acts like a mechanical tree: it breathes in Martian air, heats it to 800°C, and breathes out pure oxygen!',
    explorer:
      'MOXIE (Mars Oxygen ISRU Experiment) uses solid-oxide electrolysis. At 800°C, it strips oxygen atoms from carbon dioxide molecules (2 CO₂ → 2 CO + O₂). It produces up to 12 grams of breathable oxygen per hour, crucial for life support and future rocket propellant.',
    scientist:
      'Solid Oxide Electrolysis Cells (SOEC) catalyze the endothermic reaction 2CO₂ ⇌ 2CO + O₂ across yttria-stabilized zirconia (YSZ) ceramic membranes at 800°C. Scaling MOXIE to 25–30 kW would produce 2–3 kg/hr of liquid O₂, satisfying the Mars Ascent Vehicle (MAV) oxidizer requirement of 30 metric tons.',
    badge: 'VERIFIED_SCIENTIFIC',
  },
  {
    keywords: ['perseverance', 'rover', 'jezero', 'curiosity', 'mars 2020'],
    beginner:
      'Perseverance is a car-sized robot explorer searching for signs that tiny ancient life once lived on Mars! It landed inside Jezero Crater, which used to be an enormous lake with a flowing river billions of years ago.',
    explorer:
      'Perseverance landed in Jezero Crater on Feb 18, 2021 via the Sky Crane maneuver. Equipped with Mastcam-Z, SuperCam laser spectrometer, PIXL, and SHERLOC, it drills and caches sedimentary rock cores to be returned to Earth by the Mars Sample Return mission.',
    scientist:
      'Perseverance utilizes a 1025 kg chassis powered by an MMRTG (Pu-238). Jezero Crater features an ancient fluvio-lacustrine delta sequence rich in smectite and carbonate minerals with high biosignature preservation potential. 38 hermetically sealed sample tubes will undergo isotopic analysis on Earth.',
    badge: 'VERIFIED_SCIENTIFIC',
  },
  {
    keywords: ['rocket', 'propulsion', 'thrust', 'fuel', 'delta-v', 'engine'],
    beginner:
      'Rockets work by throwing super-hot burning gas out of their back so fast that the rocket shoots forward into the sky! It is just like blowing up a balloon and letting it go.',
    explorer:
      'Rocket engines obey Newton’s Third Law. The Tsiolkovsky rocket equation states Δv = Isp * g₀ * ln(m₀/mf). Higher Specific Impulse (Isp) means more efficiency. Staging drops empty fuel tanks so the remaining rocket is lighter and reaches higher speeds.',
    scientist:
      'Delta-V = v_e * ln(m_initial / m_final). Reaching Low Earth Orbit (LEO) requires ~9,400 m/s accounting for atmospheric drag and gravity losses. Sea-level staged combustion methalox engines (like Raptor) achieve Isp ~330s sea level and 380s in vacuum at 300 bar chamber pressure.',
    badge: 'VERIFIED_SCIENTIFIC',
  },
  {
    keywords: ['webb', 'jwst', 'hubble', 'telescope', 'deep space', 'galaxy', 'infrared'],
    beginner:
      'The James Webb Space Telescope has a giant golden honeycomb mirror that floats 1 million miles away from Earth. It uses infrared night-vision glasses to look through dusty space clouds and see the very first stars born in the universe!',
    explorer:
      'JWST orbits the Sun-Earth Lagrange Point 2 (L2). Because the expansion of the universe redshifts light from early galaxies into the infrared spectrum, Webb’s NIRCam and MIRI instruments can observe cosmic dawn ~13.5 billion years in the past, cooled by a 5-layer tennis-court-sized sunshield.',
    scientist:
      'JWST features a 6.5-meter segmented beryllium-gold primary mirror with diffraction-limited resolution at 2 microns. Positioned in a halo orbit around L2, passive radiative cooling maintains the instruments below 50 K (MIRI cryo-cooled to 6.7 K) to suppress thermal background emissions across 0.6–28 μm.',
    badge: 'VERIFIED_SCIENTIFIC',
  },
  {
    keywords: ['exoplanet', 'habitable', 'trappist', 'goldilocks', 'life'],
    beginner:
      'An exoplanet is a planet orbiting another star far outside our solar system! Astronomers search for planets in the "Goldilocks Zone" where it is not too hot and not too cold, so liquid water lakes can exist.',
    explorer:
      'Most exoplanets are detected via the Transit Method (detecting the tiny dip in starlight as the planet crosses its star) or Radial Velocity (detecting the star wobbling). The Habitable Zone depends on stellar luminosity and effective planetary greenhouse atmospheres.',
    scientist:
      'Transit photometry measures fractional flux decrement ΔF/F ≈ (R_p / R_star)². Atmospheric transmission spectroscopy during transit permits detection of biosignature pairs (e.g., CH₄ + O₂ out of chemical equilibrium) via absorption features in stellar spectral lines.',
    badge: 'VERIFIED_SCIENTIFIC',
  },
];

export default function AstraAssistant({
  isOpen,
  onClose,
  initialPrompt,
  onNavigateSection,
}: AstraAssistantProps) {
  const { progress, rank, addXp } = useProgress();
  const [level, setLevel] = useState<ExplanationLevel>('EXPLORER');
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [messages, setMessages] = useState<AstraMessage[]>([
    {
      id: 'init-1',
      sender: 'astra',
      text: `Greetings, ${progress.callsign}! I am ASTRA, your mission AI flight advisor. I can explain astrophysics, review real NASA imagery, generate flight quizzes, or give hints for your simulations. Which scientific domain shall we explore?`,
      level: 'EXPLORER',
      badge: 'VERIFIED_SCIENTIFIC',
    },
  ]);

  // Handle external prompts (e.g. from NASA Media Explorer "Explain this asset")
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      handleUserSubmit(initialPrompt);
    }
  }, [initialPrompt]);

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const findKnowledge = (query: string): KnowledgeEntry | null => {
    const clean = query.toLowerCase();
    for (const entry of KNOWLEDGE_BASE) {
      if (entry.keywords.some((kw) => clean.includes(kw))) {
        return entry;
      }
    }
    return null;
  };

  const handleUserSubmit = (userText: string) => {
    const trimmed = userText.trim();
    if (!trimmed) return;

    const userMsg: AstraMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: trimmed,
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      generateAstraResponse(trimmed);
      setIsTyping(false);
    }, 700);
  };

  const generateAstraResponse = (query: string) => {
    const qLower = query.toLowerCase();

    // Check for quiz generation request
    if (qLower.includes('quiz') || qLower.includes('test')) {
      const quizMsg: AstraMessage = {
        id: `ast-${Date.now()}`,
        sender: 'astra',
        text: `Here is a flight readiness knowledge check for you:`,
        level,
        badge: 'SIMPLIFIED_EDUCATIONAL',
        quiz: {
          question: 'What percentage of Earth gravity does an astronaut experience on Mars?',
          options: ['16% (0.16g)', '38% (0.38g)', '72% (0.72g)', '100% (1.00g)'],
          correctIndex: 1,
          explanation:
            'Mars has 38% of Earth’s surface gravity (3.72 m/s²). If you weigh 100 kg on Earth, you weigh only 38 kg on Mars!',
        },
      };
      setMessages((prev) => [...prev, quizMsg]);
      return;
    }

    // Check for next lesson recommendation
    if (qLower.includes('next lesson') || qLower.includes('recommend')) {
      const lessonMsg: AstraMessage = {
        id: `ast-${Date.now()}`,
        sender: 'astra',
        text: `Based on your rank as ${rank.title} and specialization in ${progress.specialisation}, I recommend: "ECLSS & Closed-Loop Martian Life Support". This module details MOXIE CO2 electrolysis and Sabatier water recovery loops!`,
        level,
        badge: 'SIMULATED_GAME',
        suggestedAction: {
          label: 'Launch Astronaut Academy',
          onClick: () => {
            if (onNavigateSection) onNavigateSection('astronaut-academy');
            onClose();
          },
        },
      };
      setMessages((prev) => [...prev, lessonMsg]);
      return;
    }

    // Check knowledge base
    const matched = findKnowledge(query);
    if (matched) {
      let responseText = matched.explorer;
      if (level === 'BEGINNER') responseText = matched.beginner;
      if (level === 'SCIENTIST') responseText = matched.scientist;

      const astraMsg: AstraMessage = {
        id: `ast-${Date.now()}`,
        sender: 'astra',
        text: responseText,
        level,
        badge: matched.badge,
      };
      setMessages((prev) => [...prev, astraMsg]);
      addXp(15, 'Consulted ASTRA Educational Intelligence');
      return;
    }

    // Fallback response with helpful learning hints
    let fallbackText = `I have logged your inquiry regarding "${query}". In space science, systems must be verified against orbital physics and life support constraints. Try asking me about "0.38g gravity", "MOXIE oxygen", "Perseverance rover", "Rocket propulsion", or "James Webb telescope"!`;
    if (level === 'BEGINNER') {
      fallbackText = `Great space question! Space is huge and full of exciting mysteries. You can ask me how rockets fly, what jumping on Mars feels like, or how astronauts breathe in space!`;
    } else if (level === 'SCIENTIST') {
      fallbackText = `Query parameters received. Atmospheric, astrobiological, and orbital mechanics datasets are available. Inquire regarding delta-V calculations, SOEC electrolysis, NIRCam infrared photometry, or Jezero fluvio-lacustrine strata.`;
    }

    setMessages((prev) => [
      ...prev,
      {
        id: `ast-${Date.now()}`,
        sender: 'astra',
        text: fallbackText,
        level,
        badge: 'AI_GENERATED',
      },
    ]);
  };

  const handleQuizAnswer = (quizIdx: number, selectedIdx: number) => {
    const isCorrect = selectedIdx === 1; // based on our question
    if (isCorrect) {
      addXp(50, 'Passed ASTRA In-Flight Knowledge Check');
      setMessages((prev) => [
        ...prev,
        {
          id: `ast-ans-${Date.now()}`,
          sender: 'astra',
          text: `🎉 Correct! 0.38g is the exact gravitational ratio of Mars compared to Earth. You earned +50 XP!`,
          badge: 'VERIFIED_SCIENTIFIC',
        },
      ]);
    } else {
      setMessages((prev) => [
        ...prev,
        {
          id: `ast-ans-${Date.now()}`,
          sender: 'astra',
          text: `Not quite. Mars has 38% (0.38g) of Earth gravity. (The Moon has 16% / 0.16g). Review the 0.38g Gravity Lab to test ballistic trajectories!`,
          badge: 'SIMPLIFIED_EDUCATIONAL',
          suggestedAction: {
            label: 'Open Gravity Playground',
            onClick: () => {
              if (onNavigateSection) onNavigateSection('gravity-lab');
              onClose();
            },
          },
        },
      ]);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="astra-title"
      className="fixed inset-0 z-50 flex items-center justify-end p-3 sm:p-6 bg-black/60 backdrop-blur-sm animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg h-[90vh] bg-[#0A0F1D] border border-white/20 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* ASTRA HUD Header */}
        <div className="px-5 py-4 border-b border-white/10 bg-[#0F172A] flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative w-9 h-9 rounded-xl bg-gradient-to-tr from-[#38BDF8] to-[#C65B43] p-0.5 flex items-center justify-center shadow-[0_0_15px_rgba(56,189,248,0.3)]">
              <div className="w-full h-full bg-[#080B12] rounded-[10px] flex items-center justify-center">
                <Bot className="w-5 h-5 text-[#38BDF8]" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 id="astra-title" className="font-display font-bold text-sm text-white">ASTRA</h3>
                <span className="px-1.5 py-0.5 rounded bg-[#38BDF8]/20 text-[#38BDF8] text-[9px] font-mono tracking-wider uppercase border border-[#38BDF8]/40">
                  AI MENTOR
                </span>
              </div>
              <p className="text-[10px] font-mono text-[#9298A3]">
                NASA-Aligned Educational Copilot
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Close ASTRA"
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white/70 hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Level Selector Bar */}
        <div className="px-4 py-2.5 bg-[#080D18] border-b border-white/10 flex items-center justify-between text-xs font-mono">
          <span className="text-[#9298A3] text-[11px] flex items-center space-x-1">
            <Layers className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>DEPTH TIER:</span>
          </span>
          <div className="flex items-center space-x-1 bg-white/[0.04] p-0.5 rounded-lg border border-white/5">
            {(['BEGINNER', 'EXPLORER', 'SCIENTIST'] as ExplanationLevel[]).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setLevel(lvl)}
                className={`px-2.5 py-1 rounded text-[10px] font-mono font-bold transition-all cursor-pointer ${
                  level === lvl
                    ? 'bg-[#C65B43] text-white shadow'
                    : 'text-[#9298A3] hover:text-white'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              {/* Badge indicator */}
              {m.badge && (
                <div className="mb-1 flex items-center space-x-1 text-[9px] font-mono uppercase tracking-wider text-[#9298A3]">
                  {m.badge === 'VERIFIED_SCIENTIFIC' && (
                    <span className="text-[#34D399] flex items-center space-x-1">
                      <ShieldCheck className="w-3 h-3" />
                      <span>Verified Scientific Physics</span>
                    </span>
                  )}
                  {m.badge === 'SIMPLIFIED_EDUCATIONAL' && (
                    <span className="text-[#38BDF8] flex items-center space-x-1">
                      <BookOpen className="w-3 h-3" />
                      <span>Simplified Educational Model</span>
                    </span>
                  )}
                  {m.badge === 'SIMULATED_GAME' && (
                    <span className="text-[#FBBF24] flex items-center space-x-1">
                      <Sparkles className="w-3 h-3" />
                      <span>Simulated Game Scenario</span>
                    </span>
                  )}
                  {m.badge === 'AI_GENERATED' && (
                    <span className="text-white/60 flex items-center space-x-1">
                      <Bot className="w-3 h-3" />
                      <span>Educational Suggestion</span>
                    </span>
                  )}
                </div>
              )}

              {/* Message Bubble */}
              <div
                className={`max-w-[88%] p-3.5 rounded-2xl text-xs leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-gradient-to-r from-[#C65B43] to-[#E07A5F] text-white rounded-br-none shadow-md font-sans'
                    : 'bg-white/[0.05] border border-white/10 text-white/90 rounded-bl-none shadow'
                }`}
              >
                <div className="whitespace-pre-line">{m.text}</div>

                {/* Optional Quiz Card */}
                {m.quiz && (
                  <div className="mt-3 p-3 rounded-xl bg-black/40 border border-white/10 space-y-2">
                    <div className="font-display font-bold text-xs text-white">
                      {m.quiz.question}
                    </div>
                    <div className="grid grid-cols-1 gap-1.5 pt-1">
                      {m.quiz.options.map((opt, oIdx) => (
                        <button
                          key={oIdx}
                          onClick={() => handleQuizAnswer(0, oIdx)}
                          className="px-3 py-1.5 rounded bg-white/5 hover:bg-white/15 text-left text-[11px] font-mono text-white/90 border border-white/10 transition-colors cursor-pointer"
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Optional Action Button */}
                {m.suggestedAction && (
                  <div className="mt-3 pt-2 border-t border-white/10">
                    <button
                      onClick={m.suggestedAction.onClick}
                      className="px-3 py-1.5 rounded-lg bg-[#38BDF8] text-[#080B12] font-mono text-[10px] font-bold flex items-center space-x-1.5 hover:bg-[#0284C7] transition-all cursor-pointer shadow"
                    >
                      <span>{m.suggestedAction.label}</span>
                      <Compass className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center space-x-2 text-xs font-mono text-[#9298A3] bg-white/[0.03] p-3 rounded-2xl w-fit">
              <Bot className="w-4 h-4 text-[#38BDF8] animate-bounce" />
              <span>ASTRA synthesizing astrophysics telemetry...</span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Pills */}
        <div className="px-4 py-2 bg-[#080D18] border-t border-white/5 flex items-center space-x-1.5 overflow-x-auto no-scrollbar">
          {[
            'Explain 0.38g Gravity',
            'How does MOXIE make O₂?',
            'Generate a Quiz',
            'Recommend next lesson',
            'Explain Rocket staging',
          ].map((promptText) => (
            <button
              key={promptText}
              onClick={() => handleUserSubmit(promptText)}
              className="px-2.5 py-1 rounded-full bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-[10px] font-mono text-white/70 hover:text-white whitespace-nowrap transition-colors cursor-pointer"
            >
              {promptText}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleUserSubmit(input);
          }}
          className="p-3 bg-[#0F172A] border-t border-white/10 flex items-center space-x-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask ASTRA a space question..."
            maxLength={350}
            className="flex-1 px-3.5 py-2.5 rounded-xl bg-white/[0.05] border border-white/10 text-white placeholder-white/40 font-mono text-xs focus:outline-none focus:border-[#38BDF8]"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="p-2.5 rounded-xl bg-gradient-to-r from-[#38BDF8] to-[#0284C7] disabled:opacity-40 text-[#080B12] hover:scale-105 active:scale-95 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        {/* Safety Disclaimer */}
        <div className="px-4 py-1.5 bg-[#060912] text-center text-[9px] font-sans text-white/40 border-t border-white/5">
          ASTRA is an independent educational AI mentor. Not official NASA communication. No personal data collected.
        </div>
      </div>
    </div>
  );
}
