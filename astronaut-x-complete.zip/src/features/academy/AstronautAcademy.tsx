import React, { useState } from 'react';
import {
  BookOpen, Award, CheckCircle2, ChevronRight, Play, Sparkles,
  HelpCircle, ExternalLink, RefreshCw, Star, ShieldCheck, Microscope,
  Rocket, Compass, Flame, Droplets, Atom, Eye
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useProgress } from '../../context/ProgressContext';
import NasaAttribution from '../../components/NasaAttribution';

interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

interface Lesson {
  id: string;
  title: string;
  category: string;
  estimatedMinutes: number;
  xpReward: number;
  objective: string;
  intro: string;
  scientificExplanation: string;
  visualExample: {
    title: string;
    imageUrl: string;
    nasaId: string;
    caption: string;
  };
  realMission: {
    name: string;
    agency: string;
    detail: string;
  };
  experiment: {
    title: string;
    description: string;
    interactiveType: 'slider' | 'toggle' | 'formula';
    unit: string;
    min: number;
    max: number;
    defaultVal: number;
    formulaDesc: string;
  };
  knowledgeCheck: string;
  quiz: QuizQuestion[];
  sourceReference: string;
}

const LESSONS: Lesson[] = [
  {
    id: 'lesson-orbital-mechanics',
    title: 'Orbital Mechanics & 0.38g Gravity',
    category: 'Astrophysics & Flight Dynamics',
    estimatedMinutes: 10,
    xpReward: 200,
    objective: 'Understand how reduced gravitational acceleration (3.72 m/s²) affects ballistic trajectory and calculate circular orbital velocity.',
    intro: 'Mars is approximately half the diameter of Earth with about 11% of Earth’s mass. Because gravity is proportional to mass and inversely proportional to the square of radius, you experience 0.38g on the surface.',
    scientificExplanation: `Gravitational force follows Newton’s Law of Universal Gravitation: F = G * (m₁ * m₂) / r².
On Mars, surface acceleration g_Mars = 3.721 m/s², which is approximately 38% of terrestrial gravity (9.81 m/s²).

Circular orbital velocity at low Martian altitude (300 km) is given by:
v_orbit = √(G * M_mars / (R_mars + h)) ≈ 3.4 km/s.
This is significantly lower than Low Earth Orbit (~7.8 km/s), meaning spacecraft require far less propellant (Delta-V) to enter or depart Martian orbit.`,
    visualExample: {
      title: 'MRO Orbiting Mars Reconnaissance',
      imageUrl: 'https://images-assets.nasa.gov/image/PIA08000/PIA08000~thumb.jpg',
      nasaId: 'PIA08000',
      caption: 'NASA Mars Reconnaissance Orbiter uses aerodynamic aerobraking in Mars upper atmosphere to settle into its low polar science orbit.',
    },
    realMission: {
      name: 'Mars Reconnaissance Orbiter (MRO)',
      agency: 'NASA / JPL-Caltech',
      detail: 'MRO entered Martian orbit in 2006 using 445 N main thrusters and performed 426 aerobraking passes to shrink its orbit using Martian atmospheric drag.',
    },
    experiment: {
      title: 'Orbital Altitude vs Velocity Calculator',
      description: 'Adjust the orbital altitude above Mars to see how orbital velocity decreases according to Kepler’s Third Law.',
      interactiveType: 'slider',
      unit: 'km altitude',
      min: 150,
      max: 2000,
      defaultVal: 350,
      formulaDesc: 'v = √(μ / (R + h)) where μ_Mars = 42,828 km³/s²',
    },
    knowledgeCheck: 'Why can rovers and astronauts launch objects 2.6× higher on Mars for the same upward throw velocity?',
    quiz: [
      {
        question: 'What is the surface gravity of Mars relative to Earth?',
        options: ['16% (0.16g)', '38% (0.38g)', '65% (0.65g)', '100% (1.00g)'],
        correctIndex: 1,
        explanation: 'Mars gravity is 3.72 m/s², which equals roughly 38% of Earth’s 9.81 m/s².',
      },
      {
        question: 'What happens to the required circular orbital velocity as your orbit altitude increases?',
        options: ['It increases', 'It decreases', 'It stays strictly constant', 'It doubles immediately'],
        correctIndex: 1,
        explanation: 'Orbital speed is inversely proportional to the square root of orbital radius: v = √(G*M/r). Higher orbits require slower orbital velocities.',
      },
      {
        question: 'What is the approximate circular orbital speed required for Low Mars Orbit (300 km)?',
        options: ['1.2 km/s', '3.4 km/s', '7.8 km/s', '11.2 km/s'],
        correctIndex: 1,
        explanation: 'Low Mars Orbit velocity is ~3.4 km/s, compared to Low Earth Orbit which requires ~7.8 km/s.',
      },
      {
        question: 'Which method did the Mars Reconnaissance Orbiter use to save fuel when shaping its orbit?',
        options: ['Solar sails', 'Nuclear thermal detonation', 'Aerobraking through the upper atmosphere', 'Gravitational slingshot from Phobos'],
        correctIndex: 2,
        explanation: 'Aerobraking uses atmospheric friction over hundreds of orbits to circularize an eccentric orbit without burning precious rocket fuel.',
      },
      {
        question: 'How high does a basketball reach on Mars compared to Earth if thrown with the same vertical impulse?',
        options: ['Same height', 'About 2.6 times higher', '10 times higher', 'It never comes down'],
        correctIndex: 1,
        explanation: 'Max height h = v²/(2g). Since g_Mars is 1/2.6 of Earth gravity, the height reached is 2.6× higher.',
      },
    ],
    sourceReference: 'NASA JPL Planetary Fact Sheet: Mars. https://nssdc.gsfc.nasa.gov/planetary/factsheet/marsfact.html',
  },
  {
    id: 'lesson-eclss-life-support',
    title: 'ECLSS: Closed-Loop Martian Life Support',
    category: 'Environmental Control & ISRU',
    estimatedMinutes: 12,
    xpReward: 250,
    objective: 'Master the chemical processes of MOXIE solid-oxide electrolysis and Sabatier water recovery loops necessary for human survival on Mars.',
    intro: 'Human astronauts consume roughly 0.84 kg of oxygen and 2.5 liters of water daily while generating carbon dioxide. Resupply from Earth takes 6 to 9 months, necessitating a 98%+ closed-loop life support system.',
    scientificExplanation: `Martian atmospheric pressure averages ~610 Pa (less than 1% of Earth’s sea level pressure) and consists of 95.3% CO₂, 2.6% N₂, and 1.9% Ar.
    
Two primary chemical loops sustain life and fuel ascent rockets:
1. MOXIE Solid-Oxide Electrolysis:
   2 CO₂ (g) + heat (800°C) + electricity → 2 CO (g) + O₂ (g)
   Oxygen ions migrate through a heated scandia-stabilized zirconia membrane, forming pure breathable O₂ gas.
   
2. Sabatier Carbon Dioxide Hydrogenation:
   CO₂ + 4 H₂ → CH₄ (methane) + 2 H₂O (water) + heat
   The produced water is subsequently electrolyzed back into breathable oxygen and recyclable hydrogen: 2 H₂O → 2 H₂ + O₂.`,
    visualExample: {
      title: 'MOXIE Instrument on Perseverance',
      imageUrl: 'https://images-assets.nasa.gov/image/PIA24176/PIA24176~thumb.jpg',
      nasaId: 'PIA24176',
      caption: 'The gold-coated MOXIE instrument inside Perseverance was designed to test producing breathable oxygen directly from the Martian atmosphere.',
    },
    realMission: {
      name: 'Mars Oxygen ISRU Experiment (MOXIE)',
      agency: 'NASA / MIT / JPL',
      detail: 'Between 2021 and 2023, MOXIE completed 16 successful test runs on Mars, producing a total of 122 grams of 98%+ pure oxygen.',
    },
    experiment: {
      title: 'MOXIE Thermal Electrolysis Simulator',
      description: 'Adjust the Solid Oxide Electrolysis operating temperature. Observe the catalytic threshold required to produce pure oxygen.',
      interactiveType: 'slider',
      unit: '°C Core Temperature',
      min: 400,
      max: 950,
      defaultVal: 800,
      formulaDesc: 'Electrolysis efficiency peaks at 800°C for ScSZ ceramic membranes.',
    },
    knowledgeCheck: 'Why is In-Situ Resource Utilization (ISRU) essential for bringing astronauts back home from Mars?',
    quiz: [
      {
        question: 'What is the primary gas composing the Martian atmosphere?',
        options: ['Nitrogen (78%)', 'Oxygen (21%)', 'Carbon Dioxide (95%)', 'Methane (50%)'],
        correctIndex: 2,
        explanation: 'Mars atmosphere is roughly 95.3% carbon dioxide, with traces of nitrogen and argon.',
      },
      {
        question: 'At what temperature does MOXIE operate to break apart CO₂ molecules?',
        options: ['20°C', '100°C', '800°C', '3000°C'],
        correctIndex: 2,
        explanation: 'MOXIE heats Martian CO2 to 800°C (1,470°F) to enable catalytic solid-oxide electrolysis.',
      },
      {
        question: 'What valuable byproducts does the Sabatier reaction produce from CO₂ and H₂?',
        options: ['Argon and helium', 'Methane (CH₄) and water (H₂O)', 'Pure nitrogen gas', 'Liquid carbon monoxide'],
        correctIndex: 1,
        explanation: 'The Sabatier reaction combines CO₂ and H₂ over a nickel catalyst to create methane (rocket fuel) and water.',
      },
      {
        question: 'Approximately how much oxygen does an active human astronaut consume per day?',
        options: ['0.84 kg (approx. 550 liters)', '10.5 kg', '50 kg', '100 grams'],
        correctIndex: 0,
        explanation: 'An average human astronaut consumes ~0.84 kg of O₂ per day under standard metabolic conditions.',
      },
      {
        question: 'Why did MOXIE have a gold outer coating?',
        options: ['To make it look valuable', 'To reflect infrared heat and protect adjacent rover electronics', 'To attract solar radiation', 'To repel Martian dust storms'],
        correctIndex: 1,
        explanation: 'Gold has high infrared reflectivity, preventing the 800°C core heat from damaging sensitive rover instruments nearby.',
      },
    ],
    sourceReference: 'NASA MOXIE Mission Results: Hecht et al., Science Advances 2022. https://mars.nasa.gov/technology/moxie/gui/',
  },
  {
    id: 'lesson-jezero-geology',
    title: 'Martian Geology, Jezero Crater & Astrobiology',
    category: 'Planetary Science & Astrobiology',
    estimatedMinutes: 10,
    xpReward: 200,
    objective: 'Investigate how ancient river delta formations in Jezero Crater preserve biosignatures and learn how Perseverance samples rock cores.',
    intro: 'Four billion years ago during the Noachian period, Mars had a thicker atmosphere, active magnetic field, and liquid lakes. Jezero Crater was a 45-km wide crater lake fed by an inflow river delta.',
    scientificExplanation: `Jezero Crater preserves fine-grained clay minerals (smectites) and carbonates deposited in quiet deltaic water. On Earth, these sedimentary environments are the most effective at preserving microfossils and organic molecules.
    
Perseverance uses an abrasion tool and coring drill to collect 38 sealed rock cores:
- Smectite clays trap organic macromolecules between microscopic silicate sheets.
- Carbonates precipitate directly from aqueous solutions, capturing isotopic signatures of ancient climate and water pH.
- Perchlorates (ClO₄⁻) present in Martian surface soil pose chemical toxicity risks to human crews and alter organic compound detection.`,
    visualExample: {
      title: 'Jezero Delta Remnant (Kodiak Butte)',
      imageUrl: 'https://images-assets.nasa.gov/image/PIA24836/PIA24836~thumb.jpg',
      nasaId: 'PIA24836',
      caption: 'Perseverance SuperCam captured layered deltaic sediments at Kodiak Butte, confirming that Jezero Crater once held a deep, active lake.',
    },
    realMission: {
      name: 'Mars 2020 Perseverance Rover',
      agency: 'NASA / JPL-Caltech',
      detail: 'Equipped with 7 science instruments and 43 sample collection tubes, Perseverance is currently ascending the Jezero delta rim.',
    },
    experiment: {
      title: 'Sedimentary Core Inspection',
      description: 'Select between Basaltic Regolith, Deltaic Clay Mudstone, and Carbonate Rock to compare biosignature preservation ratings.',
      interactiveType: 'toggle',
      unit: 'Target Rock Layer',
      min: 1,
      max: 3,
      defaultVal: 2,
      formulaDesc: 'Delta mudstones provide the highest biosignature preservation potential.',
    },
    knowledgeCheck: 'Why are delta formations preferred over volcanic lava plains when searching for ancient microbial life?',
    quiz: [
      {
        question: 'What geographical feature made Jezero Crater the prime landing site for Perseverance?',
        options: ['An active volcanic caldera', 'An ancient river delta and paleolake bed', 'An underground lava tube entrance', 'The highest mountain peak on Mars'],
        correctIndex: 1,
        explanation: 'Jezero Crater contains a preserved river delta where ancient sediments accumulated in a quiet lake.',
      },
      {
        question: 'What type of minerals in Jezero are best suited for preserving organic biosignatures?',
        options: ['Quartz crystals', 'Smectite clays and carbonates', 'Pure iron meteorites', 'Dry ice deposits'],
        correctIndex: 1,
        explanation: 'Fine-grained smectite clay minerals and carbonate rocks preserve delicate organic compounds on Earth and Mars.',
      },
      {
        question: 'What toxic chemical compound widespread in Martian regolith must astronauts filter out?',
        options: ['Sodium chloride', 'Perchlorates', 'Ethanol', 'Liquid ammonia'],
        correctIndex: 1,
        explanation: 'Perchlorate salts (ClO₄⁻) are prevalent in Martian soil and can disrupt human thyroid function if ingested or inhaled.',
      },
      {
        question: 'How are Perseverance’s core samples intended to be analyzed with ultimate precision?',
        options: ['Blown into space immediately', 'Returned to Earth via the Mars Sample Return campaign', 'Burned for rocket fuel', 'Left permanently on Mars'],
        correctIndex: 1,
        explanation: 'The Mars Sample Return mission will retrieve the hermetically sealed sample tubes and bring them to Earth laboratories for atomic-scale analysis.',
      },
      {
        question: 'What is the name of the prominent delta remnant butte photographed by Perseverance in Jezero?',
        options: ['Olympus Peak', 'Kodiak Butte', 'Hellas Butte', 'Gale Bluff'],
        correctIndex: 1,
        explanation: 'Kodiak Butte is a prominent isolated delta outcrop showing horizontal and dipping sediment beds created by an ancient river.',
      },
    ],
    sourceReference: 'NASA Mars 2020 Mission Science Objectives. https://mars.nasa.gov/mars2020/mission/science/',
  },
];

export default function AstronautAcademy() {
  const { progress, completeLesson, submitQuizScore, addXp } = useProgress();
  const [selectedLesson, setSelectedLesson] = useState<Lesson>(LESSONS[0]);
  const [activeStep, setActiveStep] = useState<number>(1);
  const [experimentVal, setExperimentVal] = useState<number>(LESSONS[0].experiment.defaultVal);

  // Quiz state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  const isCompleted = progress.completedLessons.includes(selectedLesson.id);

  const handleSelectLesson = (lesson: Lesson) => {
    setSelectedLesson(lesson);
    setActiveStep(1);
    setExperimentVal(lesson.experiment.defaultVal);
    setSelectedAnswers({});
    setQuizSubmitted(false);
  };

  const handleSelectAnswer = (qIdx: number, optIdx: number) => {
    if (quizSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [qIdx]: optIdx }));
  };

  const handleGradeQuiz = () => {
    let score = 0;
    selectedLesson.quiz.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        score += 1;
      }
    });

    setQuizScore(score);
    setQuizSubmitted(true);
    submitQuizScore(selectedLesson.id, score, selectedLesson.quiz.length, selectedLesson.xpReward);

    if (score >= 4) {
      completeLesson(selectedLesson.id, selectedLesson.xpReward);
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
      });
    }
  };

  return (
    <section id="astronaut-academy" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#C65B43]/10 border border-[#C65B43]/20 text-[#C65B43] text-xs font-mono uppercase tracking-widest mb-4">
          <BookOpen className="w-3.5 h-3.5" />
          <span>ASTRONAUT-X FLIGHT CURRICULUM</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-display font-bold text-[#F5F1E8] tracking-tight mb-4">
          Astronaut Academy
        </h2>
        <p className="text-[#9298A3] text-sm sm:text-base leading-relaxed">
          Rigorous, primary-source NASA educational modules. Master orbital mechanics, closed-loop life support, and Martian geology with interactive physics experiments and certified knowledge checks.
        </p>
      </div>

      {/* Main Academy Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Lesson Selector */}
        <div className="lg:col-span-4 space-y-3">
          <div className="text-xs font-mono text-[#9298A3] uppercase tracking-wider mb-2 flex items-center justify-between">
            <span>TRAINING SYLLABUS</span>
            <span className="text-[#38BDF8]">
              {progress.completedLessons.length} / {LESSONS.length} Completed
            </span>
          </div>

          {LESSONS.map((l) => {
            const done = progress.completedLessons.includes(l.id);
            const isSelected = selectedLesson.id === l.id;
            return (
              <button
                key={l.id}
                onClick={() => handleSelectLesson(l)}
                className={`w-full text-left p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#101827] border-[#C65B43] shadow-[0_0_20px_rgba(198,91,67,0.25)]'
                    : 'bg-white/[0.02] border-white/10 hover:border-white/20 hover:bg-white/[0.05]'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-white/5 text-[#9298A3]">
                    {l.category}
                  </span>
                  {done ? (
                    <span className="flex items-center space-x-1 text-[#34D399] text-xs font-mono">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Passed</span>
                    </span>
                  ) : (
                    <span className="text-[10px] font-mono text-[#FBBF24]">+{l.xpReward} XP</span>
                  )}
                </div>
                <div className="font-display font-bold text-sm text-[#F5F1E8] mb-1">
                  {l.title}
                </div>
                <div className="text-xs text-[#9298A3] line-clamp-1">{l.objective}</div>
              </button>
            );
          })}
        </div>

        {/* Right Column: 10-Step Interactive Lesson Viewer */}
        <div className="lg:col-span-8 bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 shadow-2xl space-y-8">
          {/* Step 1 & 2: Header & Learning Objective */}
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-4 mb-4">
              <div>
                <span className="text-xs font-mono text-[#38BDF8] uppercase tracking-wider">
                  MODULE {selectedLesson.id}
                </span>
                <h3 className="text-2xl font-display font-bold text-white mt-1">
                  {selectedLesson.title}
                </h3>
              </div>
              <div className="flex items-center space-x-2">
                <span className="px-3 py-1 rounded-lg bg-white/5 border border-white/10 font-mono text-xs text-[#9298A3]">
                  ⏱️ {selectedLesson.estimatedMinutes} min
                </span>
                <span className="px-3 py-1 rounded-lg bg-[#C65B43]/20 border border-[#C65B43]/40 font-mono text-xs text-[#FF7B59] font-bold">
                  +{selectedLesson.xpReward} XP
                </span>
              </div>
            </div>

            {/* Step 1: Learning Objective Box */}
            <div className="p-4 rounded-xl bg-[#38BDF8]/10 border border-[#38BDF8]/20 text-xs text-white/90 space-y-1">
              <span className="font-mono text-[10px] text-[#38BDF8] uppercase tracking-wider font-bold block">
                🎯 STEP 1 — LEARNING OBJECTIVE:
              </span>
              <p className="leading-relaxed font-sans">{selectedLesson.objective}</p>
            </div>
          </div>

          {/* Step 2 & 3: Introduction & Scientific Explanation */}
          <div className="space-y-4">
            <div>
              <span className="font-mono text-xs text-[#9298A3] uppercase tracking-wider block mb-1">
                STEP 2 — INTRODUCTION:
              </span>
              <p className="text-sm text-white/80 leading-relaxed font-sans">
                {selectedLesson.intro}
              </p>
            </div>

            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
              <span className="font-mono text-xs text-[#34D399] uppercase tracking-wider block font-bold">
                🔬 STEP 3 — SCIENTIFIC PRINCIPLE & MATHEMATICS:
              </span>
              <div className="text-xs text-white/90 leading-relaxed font-mono whitespace-pre-line bg-black/50 p-3 rounded-lg border border-white/5">
                {selectedLesson.scientificExplanation}
              </div>
            </div>
          </div>

          {/* Step 4 & 5: Visual Example & Real Space Mission */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Step 4: Visual Example */}
            <div className="rounded-xl overflow-hidden border border-white/10 bg-black/50 flex flex-col justify-between">
              <div className="p-3 border-b border-white/5 font-mono text-[11px] text-[#9298A3] uppercase">
                STEP 4 — VISUAL NASA EVIDENCE
              </div>
              <div className="h-44 bg-black overflow-hidden relative">
                <img
                  src={selectedLesson.visualExample.imageUrl}
                  alt={selectedLesson.visualExample.title}
                  className="w-full h-full object-cover"
                />
                <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded bg-black/70 text-[9px] font-mono text-white">
                  NASA ID: {selectedLesson.visualExample.nasaId}
                </span>
              </div>
              <div className="p-3 text-[11px] text-[#9298A3] leading-relaxed">
                {selectedLesson.visualExample.caption}
              </div>
            </div>

            {/* Step 5: Real-World Mission */}
            <div className="rounded-xl border border-white/10 bg-black/40 p-4 flex flex-col justify-between">
              <div>
                <span className="font-mono text-[11px] text-[#C65B43] uppercase tracking-wider block mb-2 font-bold">
                  🚀 STEP 5 — REAL-WORLD FLIGHT TEST
                </span>
                <h4 className="font-display font-bold text-sm text-white mb-1">
                  {selectedLesson.realMission.name}
                </h4>
                <div className="text-[10px] font-mono text-[#38BDF8] mb-3">
                  Agency: {selectedLesson.realMission.agency}
                </div>
                <p className="text-xs text-white/80 leading-relaxed">
                  {selectedLesson.realMission.detail}
                </p>
              </div>
              <div className="mt-4 pt-3 border-t border-white/5 text-[10px] font-mono text-[#9298A3]">
                Empirical Telemetry Verified
              </div>
            </div>
          </div>

          {/* Step 6: Interactive Experiment */}
          <div className="p-5 rounded-xl bg-gradient-to-r from-white/[0.04] to-white/[0.01] border border-white/15 space-y-4">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-[#FBBF24] uppercase tracking-wider font-bold flex items-center space-x-1.5">
                <Atom className="w-4 h-4 text-[#FBBF24]" />
                <span>STEP 6 — INTERACTIVE EXPERIMENT</span>
              </span>
              <span className="font-mono text-xs text-white/70">
                {experimentVal} {selectedLesson.experiment.unit}
              </span>
            </div>
            <div>
              <h4 className="font-display font-bold text-sm text-white mb-1">
                {selectedLesson.experiment.title}
              </h4>
              <p className="text-xs text-[#9298A3] mb-3 leading-relaxed">
                {selectedLesson.experiment.description}
              </p>

              {/* Slider Input */}
              <input
                type="range"
                min={selectedLesson.experiment.min}
                max={selectedLesson.experiment.max}
                value={experimentVal}
                onChange={(e) => setExperimentVal(Number(e.target.value))}
                className="w-full accent-[#C65B43] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] font-mono text-[#9298A3] mt-1">
                <span>{selectedLesson.experiment.min} {selectedLesson.experiment.unit}</span>
                <span>{selectedLesson.experiment.max} {selectedLesson.experiment.unit}</span>
              </div>
            </div>
            <div className="text-[11px] font-mono text-white/60 p-2.5 rounded bg-black/30 border border-white/5">
              💡 Theoretical model: {selectedLesson.experiment.formulaDesc}
            </div>
          </div>

          {/* Step 7: Knowledge Check */}
          <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 space-y-1">
            <span className="font-mono text-[10px] text-[#38BDF8] uppercase tracking-wider font-bold block">
              🤔 STEP 7 — KNOWLEDGE CHECK DISCUSSION:
            </span>
            <p className="text-xs text-white/90 leading-relaxed font-sans italic">
              "{selectedLesson.knowledgeCheck}"
            </p>
          </div>

          {/* Step 8 & 9: 5-Question Quiz & Answer Explanations */}
          <div className="space-y-6 pt-4 border-t border-white/10">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-[#34D399] uppercase tracking-wider font-bold flex items-center space-x-1.5">
                <Award className="w-4 h-4 text-[#34D399]" />
                <span>STEP 8 & 9 — 5-QUESTION CERTIFICATION QUIZ</span>
              </span>
              {quizSubmitted && (
                <span className="font-mono text-xs text-[#FBBF24]">
                  Score: {quizScore} / {selectedLesson.quiz.length}
                </span>
              )}
            </div>

            <div className="space-y-5">
              {selectedLesson.quiz.map((q, qIdx) => {
                const userChoice = selectedAnswers[qIdx];
                const hasAnswered = userChoice !== undefined;
                const isCorrect = userChoice === q.correctIndex;

                return (
                  <div
                    key={qIdx}
                    className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3"
                  >
                    <div className="font-display font-medium text-xs sm:text-sm text-white">
                      <span className="font-mono text-[#38BDF8] mr-2">Q{qIdx + 1}.</span>
                      {q.question}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {q.options.map((opt, optIdx) => {
                        const isSelected = userChoice === optIdx;
                        let btnStyle = 'bg-white/[0.03] border-white/10 text-white/80 hover:bg-white/[0.08]';

                        if (quizSubmitted) {
                          if (optIdx === q.correctIndex) {
                            btnStyle = 'bg-[#34D399]/20 border-[#34D399] text-[#34D399] font-bold';
                          } else if (isSelected && !isCorrect) {
                            btnStyle = 'bg-red-500/20 border-red-500 text-red-300';
                          }
                        } else if (isSelected) {
                          btnStyle = 'bg-[#C65B43]/20 border-[#C65B43] text-white font-medium';
                        }

                        return (
                          <button
                            key={optIdx}
                            type="button"
                            onClick={() => handleSelectAnswer(qIdx, optIdx)}
                            className={`p-2.5 rounded-lg border text-left text-xs font-mono transition-all cursor-pointer ${btnStyle}`}
                          >
                            <span className="mr-1.5 opacity-60">[{String.fromCharCode(65 + optIdx)}]</span>
                            {opt}
                          </button>
                        );
                      })}
                    </div>

                    {/* Step 9: Detailed Explanation of answers */}
                    {quizSubmitted && (
                      <div className="mt-2 pt-2 border-t border-white/5 text-[11px] leading-relaxed">
                        <span className={isCorrect ? 'text-[#34D399]' : 'text-red-400'}>
                          {isCorrect ? '✓ Correct.' : '✗ Incorrect.'}
                        </span>{' '}
                        <span className="text-[#9298A3]">{q.explanation}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Quiz Submit Button */}
            {!quizSubmitted ? (
              <button
                type="button"
                onClick={handleGradeQuiz}
                disabled={Object.keys(selectedAnswers).length < selectedLesson.quiz.length}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#C65B43] to-[#E07A5F] disabled:opacity-40 text-white font-display font-medium text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg"
              >
                <span>Submit Flight Quiz for Certification</span>
                <CheckCircle2 className="w-4 h-4" />
              </button>
            ) : (
              <div className="p-4 rounded-xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
                <div>
                  <div className="font-display font-bold text-sm text-white">
                    {quizScore >= 4 ? '🎉 Flight Certification Passed!' : 'Requires Review (Need ≥ 4/5)'}
                  </div>
                  <div className="text-xs text-[#9298A3]">
                    {quizScore >= 4
                      ? `Full XP awarded to your Astronaut Dossier.`
                      : `Review the scientific explanations and retake the quiz.`}
                  </div>
                </div>
                <button
                  onClick={() => {
                    setQuizSubmitted(false);
                    setSelectedAnswers({});
                  }}
                  className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-mono text-xs flex items-center space-x-1.5 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Retake Quiz</span>
                </button>
              </div>
            )}
          </div>

          {/* Step 10: Learning Completion Status & Primary Source Reference */}
          <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs font-mono text-[#9298A3]">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-[#34D399]" />
              <span>
                STEP 10 STATUS: {isCompleted ? 'COMPLETED & ACCREDITED' : 'IN PROGRESS'}
              </span>
            </div>
            <div className="text-[10px] text-right text-white/50 truncate max-w-sm" title={selectedLesson.sourceReference}>
              Source: {selectedLesson.sourceReference}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
