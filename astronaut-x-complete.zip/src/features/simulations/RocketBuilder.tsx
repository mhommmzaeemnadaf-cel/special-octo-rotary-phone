import React, { useState, useEffect, useRef } from 'react';
import {
  Rocket, Play, RotateCcw, AlertTriangle, CheckCircle2, Flame,
  Zap, Scale, Gauge, Compass, Award, Sparkles, HelpCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useProgress } from '../../context/ProgressContext';

interface EngineOption {
  id: string;
  name: string;
  thrustKn: number;
  ispVacuum: number;
  ispSeaLevel: number;
  massKg: number;
  fuelType: 'RP-1/LOX' | 'Hydrolox' | 'Methalox' | 'Solid';
  cost: number;
  desc: string;
}

const ENGINES: EngineOption[] = [
  {
    id: 'merlin',
    name: 'Merlin 1D (RP-1/LOX)',
    thrustKn: 845,
    ispVacuum: 311,
    ispSeaLevel: 282,
    massKg: 470,
    fuelType: 'RP-1/LOX',
    cost: 15,
    desc: 'Dense, reliable kerosene/liquid oxygen workhorse engine.',
  },
  {
    id: 'raptor',
    name: 'Raptor 3 (Full-Flow Methalox)',
    thrustKn: 2750,
    ispVacuum: 380,
    ispSeaLevel: 350,
    massKg: 1525,
    fuelType: 'Methalox',
    cost: 35,
    desc: 'Deep cryogenic methane/oxygen engine designed for Mars reuse.',
  },
  {
    id: 'rs25',
    name: 'RS-25 (Hydrolox Staged Combustion)',
    thrustKn: 2279,
    ispVacuum: 452,
    ispSeaLevel: 366,
    massKg: 3527,
    fuelType: 'Hydrolox',
    cost: 50,
    desc: 'High specific-impulse hydrogen engine used on the Space Shuttle and SLS.',
  },
  {
    id: 'srb',
    name: 'Solid Rocket Booster (HTPB)',
    thrustKn: 3600,
    ispVacuum: 268,
    ispSeaLevel: 242,
    massKg: 4200,
    fuelType: 'Solid',
    cost: 20,
    desc: 'Massive liftoff thrust boost; cannot be throttled or restarted.',
  },
];

interface PayloadOption {
  id: string;
  name: string;
  massKg: number;
  icon: string;
  targetOrbit: 'LEO' | 'GTO' | 'Mars TMI';
  requiredDeltaV: number;
  desc: string;
}

const PAYLOADS: PayloadOption[] = [
  {
    id: 'cubesat',
    name: 'Deep Space CubeSat Constellation',
    massKg: 180,
    icon: '📡',
    targetOrbit: 'LEO',
    requiredDeltaV: 9200,
    desc: 'Micro-satellites for orbital telemetry and solar wind monitoring.',
  },
  {
    id: 'rover',
    name: 'Mars Science Laboratory Rover',
    massKg: 1025,
    icon: '🏎️',
    targetOrbit: 'Mars TMI',
    requiredDeltaV: 13100,
    desc: 'Next-generation nuclear rover with sample caching system.',
  },
  {
    id: 'hab',
    name: 'Martian Habitation Core Module',
    massKg: 14000,
    icon: '🏛️',
    targetOrbit: 'Mars TMI',
    requiredDeltaV: 13400,
    desc: 'Pressurized crew habitat with closed-loop ECLSS life support.',
  },
];

export default function RocketBuilder() {
  const { completeMission, addXp } = useProgress();
  const [selectedEngine, setSelectedEngine] = useState<EngineOption>(ENGINES[1]);
  const [engineCount, setEngineCount] = useState<number>(3);
  const [fuelTons, setFuelTons] = useState<number>(180); // Metric tons
  const [selectedPayload, setSelectedPayload] = useState<PayloadOption>(PAYLOADS[1]);
  const [hasUpperStage, setHasUpperStage] = useState<boolean>(true);

  // Simulation run state
  const [isLaunching, setIsLaunching] = useState<boolean>(false);
  const [launchProgress, setLaunchProgress] = useState<number>(0);
  const [flightTelemetry, setFlightTelemetry] = useState<{ altitude: number; velocity: number; maxQ: number } | null>(null);
  const [launchOutcome, setLaunchOutcome] = useState<'success' | 'failure' | null>(null);
  const [outcomeReason, setOutcomeReason] = useState<string>('');

  // PHYSICS CALCULATIONS (Tsiolkovsky Rocket Equation)
  // m0 = total liftoff mass, mf = dry mass + payload
  const g0 = 9.80665;
  const engineDryMassKg = selectedEngine.massKg * engineCount;
  const tankStructuralMassKg = fuelTons * 1000 * 0.08; // 8% structural mass fraction
  const fuelMassKg = fuelTons * 1000;
  const upperStageMassKg = hasUpperStage ? 12000 : 0;
  const upperStageFuelKg = hasUpperStage ? 10000 : 0;
  const payloadMassKg = selectedPayload.massKg;

  const totalLiftoffMassKg = engineDryMassKg + tankStructuralMassKg + fuelMassKg + upperStageMassKg + payloadMassKg;
  const stage1DryMassKg = engineDryMassKg + tankStructuralMassKg + upperStageMassKg + payloadMassKg;

  // Total Thrust
  const totalThrustKn = selectedEngine.thrustKn * engineCount;
  const totalThrustN = totalThrustKn * 1000;

  // Thrust-to-Weight Ratio at Liftoff
  const twr = totalThrustN / (totalLiftoffMassKg * g0);

  // Stage 1 Delta-V (Average of sea level and vacuum Isp)
  const avgIsp = (selectedEngine.ispSeaLevel + selectedEngine.ispVacuum) / 2;
  const stage1DeltaV = avgIsp * g0 * Math.log(totalLiftoffMassKg / stage1DryMassKg);

  // Stage 2 Delta-V (Vacuum engine RL10 assumption)
  let stage2DeltaV = 0;
  if (hasUpperStage) {
    const s2Total = upperStageMassKg + payloadMassKg;
    const s2Dry = (upperStageMassKg - upperStageFuelKg) + payloadMassKg;
    stage2DeltaV = 450 * g0 * Math.log(s2Total / s2Dry);
  }

  const totalDeltaV = Math.round(stage1DeltaV + stage2DeltaV);

  // Run Animated Launch Simulation
  const handleLaunch = () => {
    setIsLaunching(true);
    setLaunchProgress(0);
    setLaunchOutcome(null);
    setOutcomeReason('');

    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += 5;
      setLaunchProgress(currentProgress);

      const simAltitude = Math.round((currentProgress / 100) ** 2 * 280); // km
      const simVelocity = Math.round((currentProgress / 100) * totalDeltaV); // m/s
      const simMaxQ = Math.round(Math.sin((currentProgress / 100) * Math.PI) * 38); // kPa
      setFlightTelemetry({ altitude: simAltitude, velocity: simVelocity, maxQ: simMaxQ });

      if (currentProgress >= 100) {
        clearInterval(interval);
        setIsLaunching(false);
        evaluateLaunch();
      }
    }, 120);
  };

  const evaluateLaunch = () => {
    if (twr < 1.15) {
      setLaunchOutcome('failure');
      setOutcomeReason(`TWR FAILURE: Thrust-to-Weight ratio is ${twr.toFixed(2)}. Minimum requirement is > 1.20 to overcome gravitational inertia and atmospheric drag.`);
    } else if (totalDeltaV < selectedPayload.requiredDeltaV) {
      setLaunchOutcome('failure');
      setOutcomeReason(`DELTA-V DEFICIT: Rocket generated ${totalDeltaV.toLocaleString()} m/s Δv, but reaching ${selectedPayload.targetOrbit} for ${selectedPayload.name} requires ${selectedPayload.requiredDeltaV.toLocaleString()} m/s Δv.`);
    } else {
      setLaunchOutcome('success');
      setOutcomeReason(`MISSION SUCCESS! Nominal orbital insertion. Rocket generated ${totalDeltaV.toLocaleString()} m/s Δv with a healthy liftoff TWR of ${twr.toFixed(2)}. ${selectedPayload.name} injected into trajectory.`);
      completeMission('rocket-launch', 300);
      confetti({
        particleCount: 90,
        spread: 80,
        origin: { y: 0.6 },
      });
    }
  };

  return (
    <section id="rocket-builder" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#38BDF8]/10 border border-[#38BDF8]/20 text-[#38BDF8] text-xs font-mono uppercase tracking-widest mb-4">
          <Rocket className="w-3.5 h-3.5" />
          <span>INNOVATION PROPULSION LAB</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-display font-bold text-[#F5F1E8] tracking-tight mb-4">
          Rocket Engineering & Launch Simulator
        </h2>
        <p className="text-[#9298A3] text-sm sm:text-base leading-relaxed">
          Configure stage engines, propellant mass, upper stages, and payload fractions. Solve Tsiolkovsky's Rocket Equation to reach Low Earth Orbit or inject payloads directly into Mars Transfer Orbit.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Staging Controls */}
        <div className="lg:col-span-7 bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          {/* Step 1: Engine Selection */}
          <div>
            <label className="text-xs font-mono text-[#38BDF8] uppercase tracking-wider block mb-2 font-bold flex items-center justify-between">
              <span>STAGE 1 MAIN ENGINES</span>
              <span className="text-white/60">{selectedEngine.fuelType}</span>
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {ENGINES.map((eng) => (
                <button
                  key={eng.id}
                  type="button"
                  onClick={() => setSelectedEngine(eng)}
                  className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                    selectedEngine.id === eng.id
                      ? 'bg-white/10 border-[#38BDF8] shadow-[0_0_15px_rgba(56,189,248,0.2)]'
                      : 'bg-white/[0.02] border-white/10 hover:bg-white/[0.05]'
                  }`}
                >
                  <div className="font-display font-bold text-xs text-white mb-1">
                    {eng.name}
                  </div>
                  <div className="flex justify-between text-[11px] font-mono text-[#9298A3]">
                    <span>Thrust: {eng.thrustKn} kN</span>
                    <span>Isp: {eng.ispVacuum}s</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Engine Count Slider */}
            <div className="mt-4 p-3 rounded-xl bg-white/[0.02] border border-white/5 space-y-2">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-[#9298A3]">Cluster Configuration:</span>
                <span className="text-white font-bold">{engineCount} Engines ({totalThrustKn.toLocaleString()} kN)</span>
              </div>
              <input
                type="range"
                min={1}
                max={9}
                value={engineCount}
                onChange={(e) => setEngineCount(Number(e.target.value))}
                className="w-full accent-[#38BDF8] cursor-pointer"
              />
            </div>
          </div>

          {/* Step 2: Propellant Tank Sizing */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#FBBF24] uppercase tracking-wider font-bold">STAGE 1 PROPELLANT MASS:</span>
              <span className="text-white font-bold">{fuelTons} Metric Tons</span>
            </div>
            <input
              type="range"
              min={40}
              max={600}
              step={10}
              value={fuelTons}
              onChange={(e) => setFuelTons(Number(e.target.value))}
              className="w-full accent-[#FBBF24] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] font-mono text-[#9298A3]">
              <span>40 t (Light booster)</span>
              <span>600 t (Super Heavy booster)</span>
            </div>
          </div>

          {/* Step 3: Upper Stage Toggle */}
          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 flex items-center justify-between">
            <div>
              <div className="font-display font-bold text-xs text-white">Vacuum Upper Stage (Stage 2)</div>
              <div className="text-[11px] text-[#9298A3]">
                Adds dedicated high-Isp vacuum engine and 10t fuel for orbital circularization.
              </div>
            </div>
            <button
              type="button"
              onClick={() => setHasUpperStage(!hasUpperStage)}
              className={`px-4 py-2 rounded-lg font-mono text-xs font-bold transition-all cursor-pointer ${
                hasUpperStage
                  ? 'bg-[#34D399] text-[#080B12]'
                  : 'bg-white/10 text-white/60'
              }`}
            >
              {hasUpperStage ? 'ENABLED' : 'DISABLED'}
            </button>
          </div>

          {/* Step 4: Mission Payload Selection */}
          <div>
            <label className="text-xs font-mono text-[#C65B43] uppercase tracking-wider block mb-2 font-bold">
              EXPEDITIONARY MISSION PAYLOAD
            </label>
            <div className="space-y-2">
              {PAYLOADS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setSelectedPayload(p)}
                  className={`w-full p-3.5 rounded-xl border text-left transition-all flex items-center justify-between cursor-pointer ${
                    selectedPayload.id === p.id
                      ? 'bg-[#C65B43]/20 border-[#C65B43] shadow-[0_0_15px_rgba(198,91,67,0.2)]'
                      : 'bg-white/[0.02] border-white/10 hover:bg-white/[0.05]'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className="text-xl">{p.icon}</span>
                    <div>
                      <div className="font-display font-bold text-xs text-white">{p.name}</div>
                      <div className="text-[11px] text-[#9298A3]">{p.desc}</div>
                    </div>
                  </div>
                  <div className="text-right font-mono text-xs">
                    <div className="text-white font-bold">{p.massKg.toLocaleString()} kg</div>
                    <div className="text-[10px] text-[#38BDF8]">Req: {p.requiredDeltaV.toLocaleString()} m/s</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Live Physics Telemetry & Launch Tower */}
        <div className="lg:col-span-5 bg-[#0A0F1D] rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
              <span className="font-mono text-xs text-[#9298A3] uppercase tracking-wider">
                FLIGHT COMPUTATION RADAR
              </span>
              <span className="flex items-center space-x-1.5 text-xs font-mono text-[#34D399]">
                <Gauge className="w-3.5 h-3.5" />
                <span>ONLINE</span>
              </span>
            </div>

            {/* Key Telemetry Readouts */}
            <div className="grid grid-cols-2 gap-3 mb-6">
              <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                <div className="text-[10px] font-mono text-[#9298A3] uppercase">Total Delta-V (Δv)</div>
                <div className="text-xl font-mono font-bold text-[#38BDF8]">
                  {totalDeltaV.toLocaleString()} <span className="text-xs text-white/60">m/s</span>
                </div>
                <div className="text-[10px] font-mono text-white/50">
                  Target: {selectedPayload.requiredDeltaV.toLocaleString()} m/s
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                <div className="text-[10px] font-mono text-[#9298A3] uppercase">Liftoff TWR</div>
                <div className={`text-xl font-mono font-bold ${twr >= 1.2 ? 'text-[#34D399]' : 'text-red-400'}`}>
                  {twr.toFixed(2)}
                </div>
                <div className="text-[10px] font-mono text-white/50">
                  {twr >= 1.2 ? 'Nominal Lift (>1.20)' : 'Insufficient (<1.20)'}
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                <div className="text-[10px] font-mono text-[#9298A3] uppercase">Gross Liftoff Mass</div>
                <div className="text-base font-mono font-bold text-white">
                  {(totalLiftoffMassKg / 1000).toFixed(1)} <span className="text-xs text-white/60">tons</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/5 space-y-1">
                <div className="text-[10px] font-mono text-[#9298A3] uppercase">Total Liftoff Thrust</div>
                <div className="text-base font-mono font-bold text-[#FBBF24]">
                  {totalThrustKn.toLocaleString()} <span className="text-xs text-white/60">kN</span>
                </div>
              </div>
            </div>

            {/* Launch Animation Viewport */}
            <div className="relative h-48 rounded-xl bg-black border border-white/10 overflow-hidden flex items-end justify-center pb-4">
              {/* Space / Sky gradient */}
              <div
                className="absolute inset-0 transition-opacity duration-1000"
                style={{
                  background: isLaunching
                    ? `linear-gradient(to top, #0A0F1D 0%, #000000 100%)`
                    : 'linear-gradient(to top, #0A192F 0%, #080B12 100%)',
                }}
              />

              {/* Rocket graphic */}
              <div
                className="relative z-10 flex flex-col items-center transition-all duration-300"
                style={{
                  transform: isLaunching ? `translateY(-${launchProgress * 1.5}px)` : 'translateY(0)',
                }}
              >
                <div className="w-4 h-6 bg-white rounded-t-full border border-black/20" />
                <div className="w-6 h-16 bg-slate-200 border-x border-slate-400 flex items-center justify-center text-[8px] font-mono font-bold text-black rotate-90">
                  AX-1
                </div>
                {/* Engine fire */}
                {isLaunching && (
                  <div className="w-4 h-8 bg-gradient-to-b from-yellow-300 via-orange-500 to-transparent rounded-b-full animate-pulse" />
                )}
              </div>

              {/* Launch Telemetry Overlay */}
              {isLaunching && flightTelemetry && (
                <div className="absolute top-3 left-3 right-3 flex justify-between text-[10px] font-mono text-[#38BDF8] bg-black/70 p-2 rounded-lg border border-white/10">
                  <span>ALT: {flightTelemetry.altitude} km</span>
                  <span>VEL: {flightTelemetry.velocity} m/s</span>
                  <span>Max-Q: {flightTelemetry.maxQ} kPa</span>
                </div>
              )}
            </div>

            {/* Launch Outcome Feedback */}
            {launchOutcome && (
              <div
                className={`mt-4 p-4 rounded-xl border text-xs leading-relaxed ${
                  launchOutcome === 'success'
                    ? 'bg-[#34D399]/15 border-[#34D399]/40 text-[#34D399]'
                    : 'bg-red-500/15 border-red-500/40 text-red-300'
                }`}
              >
                <div className="font-bold flex items-center space-x-1.5 mb-1 font-display">
                  {launchOutcome === 'success' ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>ORBITAL FLIGHT CERTIFIED</span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-4 h-4" />
                      <span>MISSION FLIGHT ABORTED</span>
                    </>
                  )}
                </div>
                <p className="font-sans">{outcomeReason}</p>
              </div>
            )}
          </div>

          {/* Launch Button */}
          <div className="pt-4">
            <button
              type="button"
              onClick={handleLaunch}
              disabled={isLaunching}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#FF7B59] hover:from-[#D76951] hover:to-[#EB896E] disabled:opacity-50 text-white font-display font-bold text-sm tracking-wide uppercase flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-[#C65B43]/30"
            >
              <Flame className="w-4 h-4" />
              <span>{isLaunching ? `IGNITION SEQUENCE (${launchProgress}%)...` : 'IGNITE MAIN ENGINES & LAUNCH'}</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
