import React, { useState } from 'react';
import {
  Sprout, Sun, Droplets, Thermometer, Wind, Zap, Award,
  CheckCircle2, AlertTriangle, RefreshCw, Sparkles, Scale
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useProgress } from '../../context/ProgressContext';

interface CropType {
  id: string;
  name: string;
  icon: string;
  growthCycleSols: number;
  idealTemp: number; // °C
  idealWaterPerSol: number; // liters
  idealLightHours: number; // hours
  caloricYieldPerKg: number;
  expectedBiomassKg: number;
  o2YieldGrams: number;
  desc: string;
}

const CROPS: CropType[] = [
  {
    id: 'radish',
    name: 'Martian Cherry Radish',
    icon: '🌱',
    growthCycleSols: 25,
    idealTemp: 20,
    idealWaterPerSol: 1.8,
    idealLightHours: 16,
    caloricYieldPerKg: 160,
    expectedBiomassKg: 8.5,
    o2YieldGrams: 420,
    desc: 'Fast-cycle root vegetable ideal for early crew vitamin supplementation.',
  },
  {
    id: 'wheat',
    name: 'Apogee Dwarf Wheat',
    icon: '🌾',
    growthCycleSols: 60,
    idealTemp: 22,
    idealWaterPerSol: 4.2,
    idealLightHours: 20,
    caloricYieldPerKg: 3400,
    expectedBiomassKg: 24.0,
    o2YieldGrams: 1650,
    desc: 'High-calorie carbohydrate staple developed for closed-loop space habitats.',
  },
  {
    id: 'potato',
    name: 'Red Norland Potato',
    icon: '🥔',
    growthCycleSols: 75,
    idealTemp: 18,
    idealWaterPerSol: 3.5,
    idealLightHours: 14,
    caloricYieldPerKg: 770,
    expectedBiomassKg: 32.0,
    o2YieldGrams: 1200,
    desc: 'Caloric powerhouse capable of growing in treated Martian regolith simulants.',
  },
];

export default function SpaceAgriculture() {
  const { completeMission, addXp } = useProgress();
  const [selectedCrop, setSelectedCrop] = useState<CropType>(CROPS[0]);

  // Environmental Dials
  const [lightHours, setLightHours] = useState<number>(16);
  const [waterPerSol, setWaterPerSol] = useState<number>(2.0);
  const [temperature, setTemperature] = useState<number>(21);
  const [nutrientMix, setNutrientMix] = useState<'hydroponic' | 'aeroponic' | 'regolith'>('hydroponic');
  const [co2Level, setCo2Level] = useState<number>(800); // ppm

  // Simulation run state
  const [isSimulating, setIsSimulating] = useState(false);
  const [simSol, setSimSol] = useState(0);
  const [harvestResult, setHarvestResult] = useState<{
    success: boolean;
    yieldKg: number;
    calories: number;
    o2Grams: number;
    healthPercent: number;
    energyKwh: number;
    feedback: string;
  } | null>(null);

  const runAgricultureSim = () => {
    setIsSimulating(true);
    setHarvestResult(null);

    let sol = 0;
    const targetSols = selectedCrop.growthCycleSols;

    const interval = setInterval(() => {
      sol += 5;
      setSimSol(Math.min(targetSols, sol));

      if (sol >= targetSols) {
        clearInterval(interval);
        setIsSimulating(false);
        calculateHarvest();
      }
    }, 100);
  };

  const calculateHarvest = () => {
    // Environmental stress calculations
    const tempDiff = Math.abs(temperature - selectedCrop.idealTemp);
    const tempHealth = Math.max(0.3, 1 - (tempDiff * 0.08));

    const waterDiff = Math.abs(waterPerSol - selectedCrop.idealWaterPerSol);
    const waterHealth = Math.max(0.2, 1 - (waterDiff * 0.25));

    const lightDiff = Math.abs(lightHours - selectedCrop.idealLightHours);
    const lightHealth = Math.max(0.4, 1 - (lightDiff * 0.06));

    let nutrientBonus = 1.0;
    if (nutrientMix === 'aeroponic') nutrientBonus = 1.15; // +15% aeroponic root oxygenation
    if (nutrientMix === 'regolith') nutrientBonus = 0.85; // -15% salt/perchlorate stress

    const overallHealth = Math.min(1.0, tempHealth * waterHealth * lightHealth * nutrientBonus);
    const healthPercent = Math.round(overallHealth * 100);

    const actualYieldKg = +(selectedCrop.expectedBiomassKg * overallHealth).toFixed(1);
    const totalCalories = Math.round(actualYieldKg * selectedCrop.caloricYieldPerKg);
    const totalO2 = Math.round(selectedCrop.o2YieldGrams * overallHealth);
    const totalEnergy = Math.round(lightHours * 0.85 * selectedCrop.growthCycleSols);

    const success = healthPercent >= 65;

    let feedback = '';
    if (healthPercent >= 85) {
      feedback = `BUMPER CROP! Optimal balance of LED photoperiod, temperature, and nutrient delivery produced ${actualYieldKg} kg of ${selectedCrop.name}. Substantial O₂ recovery bonus.`;
    } else if (healthPercent >= 65) {
      feedback = `VIABLE HARVEST. Modest stress detected: slight environmental variance from ideal crop parameters. Produced ${actualYieldKg} kg biomass.`;
    } else {
      feedback = `CROP BLIGHT / WITHER: High physiological stress! ${waterDiff > 1.2 ? 'Water stress' : ''} ${tempDiff > 4 ? 'Thermal shock' : ''} compromised chlorophyll synthesis. Adjust dials to match ideal botanical requirements.`;
    }

    setHarvestResult({
      success,
      yieldKg: actualYieldKg,
      calories: totalCalories,
      o2Grams: totalO2,
      healthPercent,
      energyKwh: totalEnergy,
      feedback,
    });

    if (success) {
      completeMission('space-agri', 250);
      unlockAchievement('csa_food_pioneer');
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  return (
    <section id="space-agriculture" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#34D399]/10 border border-[#34D399]/20 text-[#34D399] text-xs font-mono uppercase tracking-widest mb-4">
          <Sprout className="w-3.5 h-3.5" />
          <span>CONTROLLED ENVIRONMENT AGRICULTURE • CSA & NASA GUIDELINES</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-display font-bold text-[#F5F1E8] tracking-tight mb-4">
          Space Agriculture Simulator
        </h2>
        <p className="text-[#9298A3] text-sm sm:text-base leading-relaxed">
          Sustain astronauts on Mars with bio-regenerative life support. Calibrate LED photoperiods, hydroponic mineral delivery, and closed-loop water cycles following NASA Advanced Plant Habitat and Canadian Space Agency (CSA) deep space food production standards.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Crop & Environmental Controls */}
        <div className="lg:col-span-7 bg-[#101827]/90 rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl">
          {/* Crop Selector */}
          <div>
            <label className="text-xs font-mono text-[#34D399] uppercase tracking-wider block mb-2 font-bold">
              1. SELECT MARTIAN BOTANICAL SPECIMEN
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {CROPS.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedCrop(c)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    selectedCrop.id === c.id
                      ? 'bg-[#34D399]/15 border-[#34D399] shadow-[0_0_15px_rgba(52,211,153,0.2)]'
                      : 'bg-white/[0.02] border-white/10 hover:bg-white/[0.05]'
                  }`}
                >
                  <div className="text-2xl mb-1">{c.icon}</div>
                  <div className="font-display font-bold text-xs text-white mb-0.5">{c.name}</div>
                  <div className="text-[10px] font-mono text-[#9298A3]">Cycle: {c.growthCycleSols} Sols</div>
                </button>
              ))}
            </div>
          </div>

          {/* Environmental Dials */}
          <div className="space-y-4 pt-2 border-t border-white/10">
            <span className="text-xs font-mono text-[#FBBF24] uppercase tracking-wider block font-bold">
              2. CALIBRATE BIOME TELEMETRY
            </span>

            {/* Light Hours */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white/80 flex items-center space-x-1.5">
                  <Sun className="w-3.5 h-3.5 text-[#FBBF24]" />
                  <span>LED Photoperiod:</span>
                </span>
                <span className="text-white font-bold">{lightHours} Hours/Sol (Ideal: {selectedCrop.idealLightHours}h)</span>
              </div>
              <input
                type="range"
                min={8}
                max={24}
                value={lightHours}
                onChange={(e) => setLightHours(Number(e.target.value))}
                className="w-full accent-[#FBBF24] cursor-pointer"
              />
            </div>

            {/* Water Supply */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white/80 flex items-center space-x-1.5">
                  <Droplets className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Water Irrigation:</span>
                </span>
                <span className="text-white font-bold">{waterPerSol} L/Sol (Ideal: {selectedCrop.idealWaterPerSol}L)</span>
              </div>
              <input
                type="range"
                min={0.5}
                max={6.0}
                step={0.1}
                value={waterPerSol}
                onChange={(e) => setWaterPerSol(Number(e.target.value))}
                className="w-full accent-[#38BDF8] cursor-pointer"
              />
            </div>

            {/* Temperature */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-white/80 flex items-center space-x-1.5">
                  <Thermometer className="w-3.5 h-3.5 text-[#C65B43]" />
                  <span>Chamber Temperature:</span>
                </span>
                <span className="text-white font-bold">{temperature}°C (Ideal: {selectedCrop.idealTemp}°C)</span>
              </div>
              <input
                type="range"
                min={12}
                max={30}
                value={temperature}
                onChange={(e) => setTemperature(Number(e.target.value))}
                className="w-full accent-[#C65B43] cursor-pointer"
              />
            </div>

            {/* Nutrient Delivery Mode */}
            <div>
              <label className="text-[11px] font-mono text-[#9298A3] block mb-2">
                Nutrient Delivery Medium:
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                {[
                  { id: 'hydroponic', label: 'Hydroponic Loop', desc: 'Standard nutrient bath' },
                  { id: 'aeroponic', label: 'Aeroponic Mist', desc: '+15% O₂ root uptake' },
                  { id: 'regolith', label: 'Treated Regolith', desc: 'Leached Martian soil' },
                ].map((n) => (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => setNutrientMix(n.id as any)}
                    className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                      nutrientMix === n.id
                        ? 'bg-white/10 border-[#34D399] text-[#34D399]'
                        : 'bg-white/[0.02] border-white/5 text-white/60 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-[11px]">{n.label}</div>
                    <div className="text-[9px] text-white/50">{n.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Growth Canvas & Harvest Results */}
        <div className="lg:col-span-5 bg-[#0A0F1D] rounded-2xl border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
              <span className="font-mono text-xs text-[#9298A3] uppercase tracking-wider">
                MARTIAN GREENHOUSE TELEMETRY
              </span>
              <span className="text-xs font-mono text-[#34D399] font-bold">
                SOL {simSol} / {selectedCrop.growthCycleSols}
              </span>
            </div>

            {/* Greenhouse Visual Chamber */}
            <div className="relative h-48 rounded-xl bg-gradient-to-b from-[#0F172A] to-[#080B12] border border-white/10 overflow-hidden flex flex-col items-center justify-end p-4">
              {/* Pink/Purple LED lighting glow */}
              <div className="absolute inset-0 bg-gradient-to-b from-purple-500/10 via-transparent to-transparent pointer-events-none" />

              <div className="relative z-10 flex flex-col items-center">
                <span className="text-5xl mb-2 transition-transform duration-300" style={{ transform: `scale(${Math.max(0.6, (simSol / selectedCrop.growthCycleSols))})` }}>
                  {selectedCrop.icon}
                </span>
                <div className="text-xs font-mono text-white/80 bg-black/50 px-3 py-1 rounded-full border border-white/10">
                  {selectedCrop.name}
                </div>
              </div>
            </div>

            {/* Harvest Debrief */}
            {harvestResult && (
              <div
                className={`mt-4 p-4 rounded-xl border text-xs leading-relaxed space-y-3 ${
                  harvestResult.success
                    ? 'bg-[#34D399]/15 border-[#34D399]/40 text-white'
                    : 'bg-red-500/15 border-red-500/40 text-white'
                }`}
              >
                <div className="font-display font-bold text-sm flex items-center space-x-1.5">
                  {harvestResult.success ? (
                    <CheckCircle2 className="w-4 h-4 text-[#34D399]" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                  )}
                  <span>{harvestResult.success ? 'HARVEST CYCLE SUCCESSFUL' : 'HARVEST CYCLE STRESSED'}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                  <div className="bg-black/30 p-2 rounded">Yield: {harvestResult.yieldKg} kg</div>
                  <div className="bg-black/30 p-2 rounded">Calories: {harvestResult.calories.toLocaleString()} kcal</div>
                  <div className="bg-black/30 p-2 rounded">O₂ Produced: {harvestResult.o2Grams} g</div>
                  <div className="bg-black/30 p-2 rounded">Health Rating: {harvestResult.healthPercent}%</div>
                </div>

                <p className="text-white/80 font-sans text-xs">{harvestResult.feedback}</p>
              </div>
            )}
          </div>

          {/* Action Button */}
          <div className="pt-4">
            <button
              type="button"
              onClick={runAgricultureSim}
              disabled={isSimulating}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-[#34D399] via-[#059669] to-[#047857] hover:from-[#4ade80] hover:to-[#059669] disabled:opacity-50 text-[#080B12] font-display font-bold text-sm tracking-wide uppercase flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-[#34D399]/20"
            >
              <Sprout className="w-4 h-4" />
              <span>
                {isSimulating
                  ? `SIMULATING CROP CYCLE (SOL ${simSol})...`
                  : `SIMULATE ${selectedCrop.growthCycleSols}-SOL GROWTH CYCLE`}
              </span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
