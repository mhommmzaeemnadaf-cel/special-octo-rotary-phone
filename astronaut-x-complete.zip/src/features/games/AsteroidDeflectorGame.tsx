import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldAlert, Play, RotateCcw, Target, Sparkles, CheckCircle2,
  AlertTriangle, Crosshair, Award, Flame, Compass, Radio
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../../utils/audio';
import { useProgress } from '../../context/ProgressContext';

export default function AsteroidDeflectorGame() {
  const { addXp, unlockAchievement, completeMission } = useProgress();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Game Control States
  const [gameState, setGameState] = useState<'briefing' | 'tracking' | 'intercepted' | 'cleared' | 'impact'>('briefing');
  const [launchAngle, setLaunchAngle] = useState<number>(45); // degrees
  const [impactorMassKg, setImpactorMassKg] = useState<number>(610); // NASA DART mass = 610 kg
  const [burnVelocityKms, setBurnVelocityKms] = useState<number>(6.6); // km/s
  const [betaMomentum, setBetaMomentum] = useState<number>(2.4); // Ejecta momentum boost factor
  const [missDistanceKm, setMissDistanceKm] = useState<number>(0);
  const [score, setScore] = useState<number>(0);

  // Simulation physics ref
  const simRef = useRef({
    asteroid: { x: 620, y: 70, vx: -2.2, vy: 1.6, r: 16, deflected: false, path: [] as { x: number; y: number }[] },
    probe: { x: 120, y: 380, vx: 0, vy: 0, launched: false, active: false },
    earth: { x: 100, y: 390, r: 42 },
    particles: [] as { x: number; y: number; vx: number; vy: number; life: number; color: string }[],
  });

  const resetGame = () => {
    simRef.current.asteroid = {
      x: 640,
      y: 60,
      vx: -2.2,
      vy: 1.55,
      r: 16,
      deflected: false,
      path: [],
    };
    simRef.current.probe = {
      x: 100,
      y: 390,
      vx: 0,
      vy: 0,
      launched: false,
      active: false,
    };
    simRef.current.particles = [];
    setGameState('tracking');
    setMissDistanceKm(0);
  };

  const handleLaunchImpactor = () => {
    if (gameState !== 'tracking') return;
    soundManager.playLaunch();

    const rad = (launchAngle * Math.PI) / 180;
    const speed = burnVelocityKms * 1.1;

    simRef.current.probe = {
      x: 100,
      y: 390,
      vx: speed * Math.cos(rad),
      vy: -speed * Math.sin(rad),
      launched: true,
      active: true,
    };
  };

  // 60FPS Canvas Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      const sim = simRef.current;

      ctx.clearRect(0, 0, width, height);

      // Deep space grid
      ctx.fillStyle = '#070A12';
      ctx.fillRect(0, 0, width, height);

      // Earth Safe Clearance Perimeter (12,800 km limit)
      const earthX = sim.earth.x;
      const earthY = sim.earth.y;

      ctx.beginPath();
      ctx.arc(earthX, earthY, 110, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(239, 68, 68, 0.25)';
      ctx.setLineDash([4, 6]);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = 'rgba(239, 68, 68, 0.04)';
      ctx.fill();

      // Earth Atmosphere & Body
      const earthGlow = ctx.createRadialGradient(earthX, earthY, 10, earthX, earthY, 65);
      earthGlow.addColorStop(0, '#38BDF8');
      earthGlow.addColorStop(0.6, '#0284C7');
      earthGlow.addColorStop(1, 'transparent');
      ctx.fillStyle = earthGlow;
      ctx.beginPath();
      ctx.arc(earthX, earthY, 60, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#0369A1';
      ctx.beginPath();
      ctx.arc(earthX, earthY, sim.earth.r, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#FFFFFF';
      ctx.font = '10px monospace';
      ctx.fillText('PLANET EARTH', earthX - 35, earthY + 5);

      // Draw Projected Trajectory Trail
      if (sim.asteroid.path.length > 1) {
        ctx.beginPath();
        ctx.moveTo(sim.asteroid.path[0].x, sim.asteroid.path[0].y);
        for (let i = 1; i < sim.asteroid.path.length; i++) {
          ctx.lineTo(sim.asteroid.path[i].x, sim.asteroid.path[i].y);
        }
        ctx.strokeStyle = sim.asteroid.deflected ? 'rgba(52, 211, 153, 0.6)' : 'rgba(248, 113, 113, 0.4)';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      // Update Asteroid Movement
      if (gameState === 'tracking' || gameState === 'intercepted') {
        sim.asteroid.x += sim.asteroid.vx;
        sim.asteroid.y += sim.asteroid.vy;
        sim.asteroid.path.push({ x: sim.asteroid.x, y: sim.asteroid.y });

        // Update Probe Movement
        if (sim.probe.active) {
          sim.probe.x += sim.probe.vx;
          sim.probe.y += sim.probe.vy;

          // Check for Kinetic Collision between Probe and Asteroid
          const dist = Math.hypot(sim.probe.x - sim.asteroid.x, sim.probe.y - sim.asteroid.y);
          if (dist < sim.asteroid.r + 6) {
            // Collision Occurred! Apply DART Momentum Transfer
            soundManager.playAlarm();
            sim.probe.active = false;
            sim.asteroid.deflected = true;
            setGameState('intercepted');

            // Kinetic Deflection Formula: deltaV = beta * (m_probe / m_asteroid) * v_rel
            const deflectionAngleRad = 0.08 * betaMomentum;
            const currentSpeed = Math.hypot(sim.asteroid.vx, sim.asteroid.vy);
            const currentAngle = Math.atan2(sim.asteroid.vy, sim.asteroid.vx);
            const newAngle = currentAngle - deflectionAngleRad;

            sim.asteroid.vx = currentSpeed * Math.cos(newAngle);
            sim.asteroid.vy = currentSpeed * Math.sin(newAngle);

            // Spawn explosive debris particles
            for (let i = 0; i < 30; i++) {
              sim.particles.push({
                x: sim.asteroid.x,
                y: sim.asteroid.y,
                vx: (Math.random() - 0.5) * 6,
                vy: (Math.random() - 0.5) * 6,
                life: 1.0,
                color: Math.random() > 0.5 ? '#FBBF24' : '#C65B43',
              });
            }
          }
        }

        // Check if Asteroid reached perigee near Earth
        const earthDist = Math.hypot(sim.asteroid.x - earthX, sim.asteroid.y - earthY);

        if (earthDist < sim.earth.r + sim.asteroid.r) {
          // Direct Impact with Earth!
          setGameState('impact');
          setMissDistanceKm(0);
          soundManager.playAlarm();
        } else if (sim.asteroid.x < 0 || sim.asteroid.y > height) {
          // Asteroid flew past Earth
          const finalClearanceKm = Math.round(earthDist * 320); // 1 px = 320 km
          setMissDistanceKm(finalClearanceKm);

          if (finalClearanceKm > 14000) {
            setGameState('cleared');
            const calculatedScore = Math.min(1000, Math.round(finalClearanceKm / 25));
            setScore(calculatedScore);
            addXp(250, 'Successfully Deflected Hazardous Asteroid');
            completeMission('dart-deflector', 250);
            confetti({ particleCount: 75, spread: 70, origin: { y: 0.6 } });
          } else {
            setGameState('impact');
          }
        }
      }

      // Draw Particles
      for (let i = sim.particles.length - 1; i >= 0; i--) {
        const p = sim.particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.025;
        if (p.life <= 0) {
          sim.particles.splice(i, 1);
          continue;
        }
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
      }

      // Draw Kinetic Impactor Probe
      if (sim.probe.active) {
        ctx.fillStyle = '#38BDF8';
        ctx.beginPath();
        ctx.arc(sim.probe.x, sim.probe.y, 4, 0, Math.PI * 2);
        ctx.fill();

        // Rocket exhaust plume
        ctx.strokeStyle = '#FBBF24';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(sim.probe.x, sim.probe.y);
        ctx.lineTo(sim.probe.x - sim.probe.vx * 2, sim.probe.y - sim.probe.vy * 2);
        ctx.stroke();
      }

      // Draw Asteroid (Didymos/Dimorphos binary proxy)
      ctx.save();
      ctx.translate(sim.asteroid.x, sim.asteroid.y);
      ctx.fillStyle = sim.asteroid.deflected ? '#34D399' : '#C65B43';
      ctx.beginPath();
      ctx.arc(0, 0, sim.asteroid.r, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillStyle = '#FFFFFF';
      ctx.font = '9px monospace';
      ctx.fillText('ASTEROID-2026', -35, -20);
      ctx.restore();

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [gameState, burnVelocityKms, betaMomentum]);

  return (
    <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-5 sm:p-7 shadow-2xl space-y-6">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-[#C65B43]/20 text-[#FF7B59] border border-[#C65B43]/40 font-bold">
              PLANETARY DEFENSE RADAR
            </span>
            <span className="text-xs font-mono text-[#9298A3]">NASA DART MISSION LAB</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-display font-bold text-white mt-1">
            DART Asteroid Deflector Simulation
          </h3>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={resetGame}
            className="px-3.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-xs flex items-center space-x-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET TRAJECTORY</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Canvas Display Viewport */}
        <div className="lg:col-span-8 bg-black rounded-xl overflow-hidden border border-white/10 relative">
          <canvas
            ref={canvasRef}
            width={720}
            height={440}
            className="w-full h-[400px] object-cover"
          />

          {/* HUD Overlay Stats */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-2 text-[10px] font-mono">
            <div className="px-2.5 py-1 rounded bg-black/70 backdrop-blur-md border border-white/10 text-white">
              STATUS: <strong className={gameState === 'cleared' ? 'text-[#34D399]' : gameState === 'impact' ? 'text-red-400' : 'text-[#FBBF24]'}>
                {gameState.toUpperCase()}
              </strong>
            </div>
            {missDistanceKm > 0 && (
              <div className="px-2.5 py-1 rounded bg-black/70 backdrop-blur-md border border-white/10 text-[#38BDF8]">
                EARTH PERIGEE CLEARANCE: {missDistanceKm.toLocaleString()} KM
              </div>
            )}
          </div>

          {/* Outcome Banner */}
          {gameState === 'cleared' && (
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
              <CheckCircle2 className="w-12 h-12 text-[#34D399] mb-2" />
              <h4 className="text-2xl font-display font-bold text-white mb-1">PLANETARY DEFENSE SUCCESS!</h4>
              <p className="text-xs text-[#9298A3] max-w-md mb-4">
                Kinetic momentum transfer deflected the asteroid trajectory, clearing Earth by {missDistanceKm.toLocaleString()} km. Earth is safe!
              </p>
              <div className="font-mono text-sm text-[#FBBF24] mb-4">+250 XP AWARDED • SCORE: {score}</div>
              <button
                onClick={resetGame}
                className="px-6 py-2.5 rounded-xl bg-[#34D399] text-[#080B12] font-mono text-xs font-bold uppercase cursor-pointer"
              >
                INTERCEPT NEXT THREAT
              </button>
            </div>
          )}

          {gameState === 'impact' && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
              <AlertTriangle className="w-12 h-12 text-red-500 mb-2" />
              <h4 className="text-2xl font-display font-bold text-white mb-1">CATASTROPHIC IMPACT!</h4>
              <p className="text-xs text-red-200 max-w-md mb-4">
                Insufficient deflection momentum! The asteroid penetrated Earth's gravitational clearance perimeter. Adjust launch angle and burn velocity.
              </p>
              <button
                onClick={resetGame}
                className="px-6 py-2.5 rounded-xl bg-red-500 text-white font-mono text-xs font-bold uppercase cursor-pointer"
              >
                RECALCULATE TRAJECTORY
              </button>
            </div>
          )}
        </div>

        {/* Controls & Launch Console */}
        <div className="lg:col-span-4 bg-[#0A0F1D] rounded-xl border border-white/10 p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <span className="text-[#38BDF8] uppercase font-bold">KINETIC IMPACTOR CONTROLS</span>
            <Target className="w-4 h-4 text-[#38BDF8]" />
          </div>

          {/* Launch Angle Slider */}
          <div className="space-y-1">
            <div className="flex justify-between text-white/80">
              <span>Launch Angle:</span>
              <span className="text-white font-bold">{launchAngle}°</span>
            </div>
            <input
              type="range"
              min={15}
              max={85}
              value={launchAngle}
              onChange={(e) => setLaunchAngle(Number(e.target.value))}
              disabled={gameState !== 'tracking'}
              className="w-full accent-[#38BDF8] cursor-pointer"
            />
          </div>

          {/* Impactor Burn Velocity */}
          <div className="space-y-1">
            <div className="flex justify-between text-white/80">
              <span>Impact Velocity:</span>
              <span className="text-white font-bold">{burnVelocityKms} km/s</span>
            </div>
            <input
              type="range"
              min={4.0}
              max={9.0}
              step={0.2}
              value={burnVelocityKms}
              onChange={(e) => setBurnVelocityKms(Number(e.target.value))}
              disabled={gameState !== 'tracking'}
              className="w-full accent-[#FBBF24] cursor-pointer"
            />
          </div>

          {/* Beta Momentum Transfer Factor */}
          <div className="space-y-1">
            <div className="flex justify-between text-white/80">
              <span>Ejecta Momentum Boost (β):</span>
              <span className="text-[#34D399] font-bold">{betaMomentum}x</span>
            </div>
            <input
              type="range"
              min={1.0}
              max={3.6}
              step={0.1}
              value={betaMomentum}
              onChange={(e) => setBetaMomentum(Number(e.target.value))}
              disabled={gameState !== 'tracking'}
              className="w-full accent-[#34D399] cursor-pointer"
            />
          </div>

          <div className="p-3 rounded-lg bg-white/[0.02] border border-white/5 text-[11px] text-[#9298A3] leading-relaxed font-sans">
            💡 <strong>Physics Principle:</strong> In the real NASA DART mission (2022), the spacecraft collided with Dimorphos at 6.6 km/s, transferring momentum boosted by outward rocky debris ejecta ($\beta \approx 2.4-3.6$).
          </div>

          {/* Action Button */}
          <button
            onClick={gameState === 'briefing' ? resetGame : handleLaunchImpactor}
            disabled={gameState === 'cleared' || gameState === 'impact'}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#C65B43] via-[#E07A5F] to-[#FF7B59] hover:from-[#D76951] text-white font-display font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-[#C65B43]/20"
          >
            <Flame className="w-4 h-4" />
            <span>
              {gameState === 'briefing' ? 'START THREAT TRACKING' : 'FIRE KINETIC IMPACTOR'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
}
