import React, { useState } from 'react';
import {
  Gamepad2, ShieldAlert, Orbit, Crosshair, Sparkles, Award,
  Rocket, Scale, Trophy, Flame, Play, Compass, Sun, Shield
} from 'lucide-react';
import AsteroidDeflectorGame from './AsteroidDeflectorGame';
import OrbitalSlingshotGame from './OrbitalSlingshotGame';
import SpacecraftDockingGame from './SpacecraftDockingGame';
import SolarShieldGame from './SolarShieldGame';
import RoverDriveGame from '../../components/RoverDriveGame';
import GravityPlayground from '../../components/GravityPlayground';

export default function SpaceGamesArcade() {
  const [activeGame, setActiveGame] = useState<'dart' | 'slingshot' | 'docking' | 'shield' | 'rover' | 'gravity'>('dart');

  const games = [
    {
      id: 'dart',
      title: 'DART Asteroid Deflector',
      icon: ShieldAlert,
      badge: 'PLANETARY DEFENSE',
      tagline: 'Kinetic impactor deflection physics',
      color: '#C65B43',
    },
    {
      id: 'slingshot',
      title: 'Orbital Slingshot Navigator',
      icon: Orbit,
      badge: 'GRAVITY ASSIST',
      tagline: 'Voyager Grand Tour multi-body mechanics',
      color: '#38BDF8',
    },
    {
      id: 'docking',
      title: 'ISS 6-DOF Docking Simulator',
      icon: Crosshair,
      badge: 'RENDEZVOUS',
      tagline: 'Reaction Control System orbital latching',
      color: '#34D399',
    },
    {
      id: 'shield',
      title: 'Helios CME Magneto-Shield',
      icon: Sun,
      badge: 'SPACE WEATHER',
      tagline: 'Deflect coronal mass ejections with Lorentz force',
      color: '#F59E0B',
    },
    {
      id: 'rover',
      title: 'Jezero Rover Driving Mini-Game',
      icon: Rocket,
      badge: 'SURFACE ROVER',
      tagline: 'Drive Perseverance & collect rock cores',
      color: '#F59E0B',
    },
    {
      id: 'gravity',
      title: '0.38g Gravity Playground',
      icon: Scale,
      badge: 'PHYSICS LAB',
      tagline: 'Earth vs Mars vs Moon ballistic ballistics',
      color: '#A855F7',
    },
  ];

  return (
    <section id="space-games-arcade" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#34D399]/10 border border-[#34D399]/20 text-[#34D399] text-xs font-mono uppercase tracking-widest mb-4">
          <Gamepad2 className="w-3.5 h-3.5" />
          <span>ASTRONAUT FLIGHT SIMULATION ARCADE</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-display font-extrabold text-[#F5F1E8] tracking-tight mb-4">
          Interactive Spaceflight Simulations
        </h2>
        <p className="text-[#9298A3] text-sm sm:text-base leading-relaxed">
          Test real-world aerospace physics across 6 authentic simulations: deflect hazardous asteroids with kinetic probes, navigate orbital slingshots, execute 6-DOF station dockings, deflect Coronal Mass Ejection plasma streams with magnetic fields, pilot rovers, and experiment with low-gravity ballistics.
        </p>
      </div>

      {/* Game Selector Sub-Tabs */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {games.map((g) => {
          const Icon = g.icon;
          const isActive = activeGame === g.id;
          return (
            <button
              key={g.id}
              onClick={() => setActiveGame(g.id as any)}
              className={`px-4 py-3 rounded-xl font-mono text-xs flex items-center space-x-2.5 transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#C65B43] text-white font-bold shadow-lg shadow-[#C65B43]/20 scale-105'
                  : 'bg-white/[0.04] text-[#9298A3] hover:text-white hover:bg-white/[0.08] border border-white/5'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{g.title}</span>
            </button>
          );
        })}
      </div>

      {/* Active Game Content Viewport */}
      <div>
        {activeGame === 'dart' && <AsteroidDeflectorGame />}
        {activeGame === 'slingshot' && <OrbitalSlingshotGame />}
        {activeGame === 'docking' && <SpacecraftDockingGame />}
        {activeGame === 'shield' && <SolarShieldGame />}
        {activeGame === 'rover' && <RoverDriveGame />}
        {activeGame === 'gravity' && <GravityPlayground />}
      </div>
    </section>
  );
}
