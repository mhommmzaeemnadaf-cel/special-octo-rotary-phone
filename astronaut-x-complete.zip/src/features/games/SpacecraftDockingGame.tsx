import React, { useState, useEffect, useRef } from 'react';
import {
  Crosshair, Play, RotateCcw, Target, Sparkles, CheckCircle2,
  AlertTriangle, Compass, Award, Shield, ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Disc
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../../utils/audio';
import { useProgress } from '../../context/ProgressContext';

export default function SpacecraftDockingGame() {
  const { addXp, completeMission } = useProgress();

  const [gameState, setGameState] = useState<'approaching' | 'docked' | 'breached' | 'aborted'>('approaching');

  // Spacecraft 6-DOF dynamic physics state
  const [posX, setPosX] = useState<number>(14.2); // meters horizontal offset (-50 to +50)
  const [posY, setPosY] = useState<number>(-12.5); // meters vertical offset (-50 to +50)
  const [posZ, setPosZ] = useState<number>(45.0); // range distance in meters (50m -> 0m)

  const [velX, setVelX] = useState<number>(-0.45); // m/s
  const [velY, setVelY] = useState<number>(0.38); // m/s
  const [velZ, setVelZ] = useState<number>(-0.65); // closure rate m/s (approaching)

  const [rollAngle, setRollAngle] = useState<number>(8.5); // degrees
  const [rollRate, setRollRate] = useState<number>(-0.3); // deg/s
  const [rcsFuel, setRcsFuel] = useState<number>(100); // %

  const resetDocking = () => {
    setPosX(14.0);
    setPosY(-12.0);
    setPosZ(45.0);
    setVelX(-0.4);
    setVelY(0.35);
    setVelZ(-0.6);
    setRollAngle(8.0);
    setRollRate(-0.25);
    setRcsFuel(100);
    setGameState('approaching');
  };

  // RCS Pulse Thruster Functions
  const pulseRcs = (axis: 'x' | 'y' | 'z' | 'roll', direction: number) => {
    if (gameState !== 'approaching' || rcsFuel <= 0) return;
    soundManager.playClick();
    setRcsFuel((f) => Math.max(0, f - 1.5));

    if (axis === 'x') setVelX((v) => +(v + direction * 0.25).toFixed(2));
    if (axis === 'y') setVelY((v) => +(v + direction * 0.25).toFixed(2));
    if (axis === 'z') setVelZ((v) => +(v + direction * 0.20).toFixed(2));
    if (axis === 'roll') setRollRate((r) => +(r + direction * 0.4).toFixed(2));
  };

  // Physics simulation tick (runs 20 times per second)
  useEffect(() => {
    if (gameState !== 'approaching') return;

    const interval = setInterval(() => {
      setPosX((x) => +(x + velX * 0.1).toFixed(2));
      setPosY((y) => +(y + velY * 0.1).toFixed(2));
      setRollAngle((a) => +(a + rollRate * 0.1).toFixed(2));

      setPosZ((z) => {
        const nextZ = +(z + velZ * 0.1).toFixed(2);

        // Contact with Docking Mechanism!
        if (nextZ <= 0.2) {
          clearInterval(interval);

          const alignmentError = Math.hypot(posX, posY);
          const closureRate = Math.abs(velZ);
          const rollError = Math.abs(rollAngle);

          // Docking Constraints: alignment < 1.8m, closure < 0.22 m/s, roll < 3.5 deg
          if (alignmentError < 1.8 && closureRate < 0.22 && rollError < 3.5) {
            setGameState('docked');
            soundManager.playSuccess();
            addXp(250, 'Mastered 6-DOF Spacecraft Orbital Docking');
            completeMission('iss-docking', 250);
            confetti({ particleCount: 85, spread: 70, origin: { y: 0.6 } });
          } else {
            setGameState('breached');
            soundManager.playAlarm();
          }
          return 0;
        }
        return nextZ;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [gameState, velX, velY, velZ, rollRate, posX, posY, rollAngle]);

  // Keyboard navigation shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).tagName === 'INPUT') return;
      if (e.key === 'a' || e.key === 'A') pulseRcs('x', -1);
      if (e.key === 'd' || e.key === 'D') pulseRcs('x', 1);
      if (e.key === 'w' || e.key === 'W') pulseRcs('y', 1);
      if (e.key === 's' || e.key === 'S') pulseRcs('y', -1);
      if (e.key === 'q' || e.key === 'Q') pulseRcs('z', -1); // Brake
      if (e.key === 'e' || e.key === 'E') pulseRcs('z', 1);  // Forward
      if (e.key === 'j' || e.key === 'J') pulseRcs('roll', -1);
      if (e.key === 'l' || e.key === 'L') pulseRcs('roll', 1);
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, rcsFuel]);

  const alignmentDist = Math.hypot(posX, posY).toFixed(1);
  const isAligned = Math.hypot(posX, posY) < 1.8 && Math.abs(rollAngle) < 3.5;
  const isSpeedSafe = Math.abs(velZ) < 0.22;

  return (
    <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-5 sm:p-7 shadow-2xl space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-[#34D399]/20 text-[#34D399] border border-[#34D399]/40 font-bold">
              6-DOF RENDEZVOUS SIMULATOR
            </span>
            <span className="text-xs font-mono text-[#9298A3]">INTERNATIONAL DOCKING ADAPTER (IDA)</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-display font-bold text-white mt-1">
            ISS / Gateway Spacecraft Docking Challenge
          </h3>
        </div>

        <button
          onClick={resetDocking}
          className="px-3.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-xs flex items-center space-x-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>RESET DOCKING APPROACH</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Cockpit HUD Viewport */}
        <div className="lg:col-span-8 bg-black rounded-xl overflow-hidden border border-white/10 relative h-[420px] flex items-center justify-center">
          {/* Starfield & Earth orbital limb in background */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#030712] via-[#080E1E] to-[#04152D] pointer-events-none" />

          {/* Station Docking Target Ring (grows larger as distance posZ shrinks) */}
          <div
            className="relative flex items-center justify-center transition-all duration-100"
            style={{
              transform: `scale(${Math.max(0.4, 2.2 - (posZ / 25))}) translate(${posX * 4}px, ${posY * 4}px) rotate(${rollAngle}deg)`,
            }}
          >
            {/* Outer ISS Module Body Graphic */}
            <div className="w-48 h-48 rounded-full border-4 border-slate-600 bg-slate-900/80 shadow-[0_0_50px_rgba(56,189,248,0.25)] flex items-center justify-center relative">
              {/* Petals / Alignment Guides */}
              <div className="absolute top-0 w-3 h-8 bg-amber-400 rounded-t" />
              <div className="absolute bottom-0 w-3 h-8 bg-amber-400 rounded-b" />
              <div className="absolute left-0 w-8 h-3 bg-amber-400 rounded-l" />
              <div className="absolute right-0 w-8 h-3 bg-amber-400 rounded-r" />

              {/* Inner Latch Tunnel */}
              <div className="w-24 h-24 rounded-full border-2 border-dashed border-[#38BDF8] flex items-center justify-center bg-black">
                <div className="w-4 h-4 rounded-full bg-[#34D399]/40 border border-[#34D399]" />
              </div>
            </div>
          </div>

          {/* Fixed Cockpit Reticle Crosshairs */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-32 h-32 rounded-full border border-white/20 flex items-center justify-center">
              <div className="w-full h-[1px] bg-[#38BDF8]/40" />
              <div className="h-full w-[1px] bg-[#38BDF8]/40 absolute" />
              <div className="w-8 h-8 rounded-full border-2 border-[#38BDF8] animate-pulse" />
            </div>
          </div>

          {/* Live Flight Telemetry Overlays */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-2 text-[10px] font-mono">
            <div className="px-2.5 py-1 rounded bg-black/75 border border-white/10 text-white">
              RANGE (Z): <strong className="text-xl text-[#38BDF8]">{posZ.toFixed(1)} m</strong>
            </div>
            <div className="px-2.5 py-1 rounded bg-black/75 border border-white/10 text-white">
              CLOSURE: <strong className={isSpeedSafe ? 'text-[#34D399]' : 'text-red-400'}>{Math.abs(velZ).toFixed(2)} m/s</strong> (Max 0.22)
            </div>
            <div className="px-2.5 py-1 rounded bg-black/75 border border-white/10 text-white">
              ALIGN OFFSET: <strong className={isAligned ? 'text-[#34D399]' : 'text-[#FBBF24]'}>{alignmentDist} m</strong>
            </div>
            <div className="px-2.5 py-1 rounded bg-black/75 border border-white/10 text-white">
              ROLL: <strong>{rollAngle.toFixed(1)}°</strong>
            </div>
          </div>

          {/* Outcome Modals */}
          {gameState === 'docked' && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
              <CheckCircle2 className="w-12 h-12 text-[#34D399] mb-2" />
              <h4 className="text-2xl font-display font-bold text-white mb-1">HARD DOCK CONFIRMED!</h4>
              <p className="text-xs text-[#9298A3] max-w-md mb-4">
                Soft latches captured, alignment seals pressurized. You successfully docked to the space station within NASA flight tolerances!
              </p>
              <div className="font-mono text-sm text-[#FBBF24] mb-4">+250 XP AWARDED</div>
              <button
                onClick={resetDocking}
                className="px-6 py-2.5 rounded-xl bg-[#34D399] text-[#080B12] font-mono text-xs font-bold uppercase cursor-pointer"
              >
                NEW DOCKING RUN
              </button>
            </div>
          )}

          {gameState === 'breached' && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
              <AlertTriangle className="w-12 h-12 text-red-500 mb-2" />
              <h4 className="text-2xl font-display font-bold text-white mb-1">DOCKING COLLISION BREACH!</h4>
              <p className="text-xs text-red-200 max-w-md mb-4">
                Velocity exceeded 0.22 m/s or alignment collar collided with guide petals! Counter-thrust in space to cancel momentum.
              </p>
              <button
                onClick={resetDocking}
                className="px-6 py-2.5 rounded-xl bg-red-500 text-white font-mono text-xs font-bold uppercase cursor-pointer"
              >
                RE-ENGAGE APPROACH
              </button>
            </div>
          )}
        </div>

        {/* 6-DOF Pulse Thruster Tactical Panel */}
        <div className="lg:col-span-4 bg-[#0A0F1D] rounded-xl border border-white/10 p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <span className="text-[#38BDF8] uppercase font-bold">RCS THRUSTER CONSOLE</span>
            <span className="text-[#FBBF24]">FUEL: {rcsFuel.toFixed(0)}%</span>
          </div>

          {/* Translation Control D-PAD */}
          <div className="text-center space-y-2">
            <span className="text-[10px] text-[#9298A3] block uppercase">Lateral Translation [W, A, S, D]</span>
            <div className="grid grid-cols-3 gap-1.5 max-w-[160px] mx-auto">
              <div />
              <button
                onClick={() => pulseRcs('y', 1)}
                className="p-2.5 rounded bg-white/5 hover:bg-white/15 border border-white/10 text-white flex items-center justify-center cursor-pointer"
                title="Thruster Up [W]"
              >
                <ArrowUp className="w-4 h-4" />
              </button>
              <div />
              <button
                onClick={() => pulseRcs('x', -1)}
                className="p-2.5 rounded bg-white/5 hover:bg-white/15 border border-white/10 text-white flex items-center justify-center cursor-pointer"
                title="Thruster Left [A]"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => pulseRcs('y', -1)}
                className="p-2.5 rounded bg-white/5 hover:bg-white/15 border border-white/10 text-white flex items-center justify-center cursor-pointer"
                title="Thruster Down [S]"
              >
                <ArrowDown className="w-4 h-4" />
              </button>
              <button
                onClick={() => pulseRcs('x', 1)}
                className="p-2.5 rounded bg-white/5 hover:bg-white/15 border border-white/10 text-white flex items-center justify-center cursor-pointer"
                title="Thruster Right [D]"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Longitudinal Z & Roll Controls */}
          <div className="pt-2 border-t border-white/10 space-y-2">
            <span className="text-[10px] text-[#9298A3] block uppercase">Fore / Aft Velocity (Z)</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => pulseRcs('z', 1)}
                className="p-2 rounded bg-white/5 hover:bg-white/15 border border-white/10 text-white text-[11px] cursor-pointer"
              >
                + ACCEL [E]
              </button>
              <button
                onClick={() => pulseRcs('z', -1)}
                className="p-2 rounded bg-[#C65B43]/20 hover:bg-[#C65B43]/40 border border-[#C65B43]/40 text-[#FF7B59] text-[11px] font-bold cursor-pointer"
              >
                - BRAKE [Q]
              </button>
            </div>

            <span className="text-[10px] text-[#9298A3] block uppercase mt-2">Roll Orientation Alignment</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => pulseRcs('roll', -1)}
                className="p-2 rounded bg-white/5 hover:bg-white/15 border border-white/10 text-white text-[11px] cursor-pointer"
              >
                ⟲ ROLL LEFT [J]
              </button>
              <button
                onClick={() => pulseRcs('roll', 1)}
                className="p-2 rounded bg-white/5 hover:bg-white/15 border border-white/10 text-white text-[11px] cursor-pointer"
              >
                ⟳ ROLL RIGHT [L]
              </button>
            </div>
          </div>

          <div className="p-2.5 rounded bg-white/[0.02] border border-white/5 text-[10px] text-[#9298A3] leading-relaxed font-sans">
            ⚡ <strong>Newton's First Law:</strong> No air friction in space! Once you thrust in a direction, the spacecraft glides at constant speed until you fire an opposing counter-thrust.
          </div>
        </div>
      </div>
    </div>
  );
}
