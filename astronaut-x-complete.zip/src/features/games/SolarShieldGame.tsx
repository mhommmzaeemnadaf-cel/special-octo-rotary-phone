import React, { useState, useEffect, useRef } from 'react';
import {
  Shield, Sun, Zap, AlertTriangle, Play, RotateCcw, Award,
  Activity, Compass, BatteryCharging, Radio, Volume2, Sparkles, CheckCircle2
} from 'lucide-react';
import { useProgress } from '../../context/ProgressContext';
import { soundManager } from '../../utils/audio';
import { BUNDLED_DONKI_CMES, DonkiCmeEvent } from '../../services/nasa/nasaSpaceWeatherService';

interface SolarParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  charge: number; // positive for protons, negative for electrons
  mass: number;
  energyKeV: number;
  radius: number;
  color: string;
  deflected: boolean;
  absorbed: boolean;
}

export default function SolarShieldGame() {
  const { awardXp, unlockAchievement } = useProgress();

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Simulation Controls & Telemetry
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [gameWon, setGameWon] = useState(false);
  const [stormLevel, setStormLevel] = useState<'C-Class' | 'M-Class' | 'X-Class' | 'DONKI-Live'>('DONKI-Live');
  const [activeDonkiEvent, setActiveDonkiEvent] = useState<DonkiCmeEvent>(BUNDLED_DONKI_CMES[0]);

  // Player controls
  const [magneticFluxTesla, setMagneticFluxTesla] = useState<number>(1.5); // 0.2 to 3.0 Tesla
  const [gimbalAngleDeg, setGimbalAngleDeg] = useState<number>(0); // -45 to +45 deg
  const [cryoPowerPercent, setCryoPowerPercent] = useState<number>(100);
  const [isOverdriveActive, setIsOverdriveActive] = useState<boolean>(false);

  // Scoring & Metrics
  const [radiationDoseMSv, setRadiationDoseMSv] = useState<number>(0);
  const [particlesDeflectedCount, setParticlesDeflectedCount] = useState<number>(0);
  const [stormElapsedSec, setStormElapsedSec] = useState<number>(0);
  const stormDurationSec = 25; // 25s storm survival

  const particlesRef = useRef<SolarParticle[]>([]);
  const animFrameRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(performance.now());
  const powerDrainTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Audio tone synth helper
  const playDeflectAudioTone = (freq = 520) => {
    try {
      const ctx = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!ctx) return;
      const audioCtx = new ctx();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.12);
    } catch (e) {
      // Audio not permitted without interaction
    }
  };

  // Reset Game
  const resetGame = () => {
    setIsPlaying(false);
    setGameOver(false);
    setGameWon(false);
    setRadiationDoseMSv(0);
    setParticlesDeflectedCount(0);
    setStormElapsedSec(0);
    setCryoPowerPercent(100);
    setIsOverdriveActive(false);
    particlesRef.current = [];
  };

  // Start Simulation
  const handleStartGame = () => {
    soundManager.playClick();
    resetGame();
    setIsPlaying(true);
  };

  // Trigger Cryogenic Overdrive Burst
  const triggerOverdrive = () => {
    if (cryoPowerPercent < 25 || isOverdriveActive) return;
    soundManager.playSuccess();
    setIsOverdriveActive(true);
    setCryoPowerPercent((p) => Math.max(0, p - 30));
    setTimeout(() => {
      setIsOverdriveActive(false);
    }, 3500);
  };

  // Power Regeneration & Drainage Loop
  useEffect(() => {
    if (!isPlaying || gameOver || gameWon) return;

    const interval = setInterval(() => {
      setStormElapsedSec((sec) => {
        const next = sec + 1;
        if (next >= stormDurationSec) {
          // Survived Storm!
          setGameWon(true);
          setIsPlaying(false);
          soundManager.playSuccess();
          awardXp(250);
          unlockAchievement('solar_shield_master');
          unlockAchievement('donki_heliophysicist');
        }
        return next;
      });

      // Battery recharge or drain
      setCryoPowerPercent((prev) => {
        let drain = (magneticFluxTesla / 3.0) * 2.5;
        if (isOverdriveActive) drain += 6;
        const recharged = prev - drain + 1.8;
        return Math.max(5, Math.min(100, recharged));
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isPlaying, gameOver, gameWon, magneticFluxTesla, isOverdriveActive]);

  // Main Canvas Physics & Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = canvas.parentElement?.clientWidth || 700);
    let height = (canvas.height = 360);

    const shipX = width - 110;
    const shipY = height / 2;

    const render = (time: number) => {
      const dt = Math.min(0.05, (time - lastTimeRef.current) / 1000);
      lastTimeRef.current = time;

      // Clear Canvas
      ctx.fillStyle = '#060913';
      ctx.fillRect(0, 0, width, height);

      // Starfield Background
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      for (let i = 0; i < 40; i++) {
        const sx = ((i * 12345.67) % width);
        const sy = ((i * 67890.12) % height);
        ctx.fillRect(sx, sy, 1, 1);
      }

      // 1. Draw Solar Corona on the Left
      const sunGradient = ctx.createRadialGradient(-30, height / 2, 20, -30, height / 2, 140);
      sunGradient.addColorStop(0, '#FFFFFF');
      sunGradient.addColorStop(0.3, '#F59E0B');
      sunGradient.addColorStop(0.7, '#C65B43');
      sunGradient.addColorStop(1, 'transparent');

      ctx.fillStyle = sunGradient;
      ctx.beginPath();
      ctx.arc(-30, height / 2, 140, 0, Math.PI * 2);
      ctx.fill();

      // Pulsing Coronal Flaring Filaments
      ctx.strokeStyle = 'rgba(251, 191, 36, 0.35)';
      ctx.lineWidth = 3;
      for (let j = 0; j < 5; j++) {
        const flareY = height / 2 + Math.sin(time * 0.003 + j) * 70;
        ctx.beginPath();
        ctx.moveTo(0, flareY);
        ctx.bezierCurveTo(40, flareY + Math.cos(time * 0.004) * 20, 80, flareY - 10, 120, flareY + 15);
        ctx.stroke();
      }

      // 2. Spawn Solar Wind & CME Energetic Particles
      if (isPlaying && !gameOver && !gameWon) {
        const baseSpeed =
          stormLevel === 'DONKI-Live'
            ? Math.min(520, (activeDonkiEvent.speedKmS / 1450) * 440 + 80)
            : stormLevel === 'C-Class' ? 240 : stormLevel === 'M-Class' ? 340 : 460;
        const spawnCount =
          stormLevel === 'DONKI-Live'
            ? activeDonkiEvent.speedKmS > 1200 ? 7 : 5
            : stormLevel === 'C-Class' ? 2 : stormLevel === 'M-Class' ? 4 : 8;
        if (Math.random() < 0.85) {
          for (let k = 0; k < spawnCount; k++) {
            const isProton = Math.random() > 0.3; // Protons carry massive momentum
            const speed = baseSpeed + Math.random() * 80;
            const spreadY = (Math.random() - 0.5) * height * 0.9;

            particlesRef.current.push({
              x: 10,
              y: height / 2 + spreadY,
              vx: speed,
              vy: (Math.random() - 0.5) * 60,
              charge: isProton ? 1 : -1,
              mass: isProton ? 1.0 : 0.0005,
              energyKeV: isProton ? 80 + Math.random() * 120 : 10 + Math.random() * 20,
              radius: isProton ? 2.5 : 1.5,
              color: isProton ? '#F59E0B' : '#38BDF8',
              deflected: false,
              absorbed: false,
            });
          }
        }
      }

      // Effective Shield Strength (boosted if Overdrive is active)
      const effectiveTesla = isOverdriveActive ? magneticFluxTesla * 2.5 : magneticFluxTesla;
      const effectiveShieldRadius = 80 + effectiveTesla * 24;
      const gimbalRad = (gimbalAngleDeg * Math.PI) / 180;

      // 3. Draw Magnetic Dipole Sheath & Shield Bubble around Spacecraft
      const shieldCenterX = shipX - 25;
      const shieldCenterY = shipY;

      // Shield Bubble Aura
      const shieldGlow = ctx.createRadialGradient(
        shieldCenterX, shieldCenterY, 10,
        shieldCenterX, shieldCenterY, effectiveShieldRadius
      );
      if (isOverdriveActive) {
        shieldGlow.addColorStop(0, 'rgba(52, 211, 153, 0.45)');
        shieldGlow.addColorStop(0.7, 'rgba(56, 189, 248, 0.3)');
        shieldGlow.addColorStop(1, 'transparent');
      } else {
        shieldGlow.addColorStop(0, 'rgba(56, 189, 248, 0.25)');
        shieldGlow.addColorStop(0.8, 'rgba(99, 102, 241, 0.15)');
        shieldGlow.addColorStop(1, 'transparent');
      }

      ctx.fillStyle = shieldGlow;
      ctx.beginPath();
      ctx.arc(shieldCenterX, shieldCenterY, effectiveShieldRadius, 0, Math.PI * 2);
      ctx.fill();

      // Magnetic Flux Lines (Dipole Coils)
      ctx.save();
      ctx.translate(shieldCenterX, shieldCenterY);
      ctx.rotate(gimbalRad);

      ctx.strokeStyle = isOverdriveActive ? '#34D399' : '#38BDF8';
      ctx.lineWidth = 1.5;
      for (let r = 40; r <= effectiveShieldRadius; r += 22) {
        ctx.beginPath();
        ctx.ellipse(0, 0, r, r * 0.65, 0, -Math.PI / 2, Math.PI / 2);
        ctx.stroke();
      }

      // Deflector Coil Projector Nozzle
      ctx.fillStyle = '#64748B';
      ctx.fillRect(-15, -6, 20, 12);
      ctx.fillStyle = isOverdriveActive ? '#34D399' : '#38BDF8';
      ctx.beginPath();
      ctx.arc(5, 0, 5, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      // 4. Update & Render Charged Particles
      const nextParticles: SolarParticle[] = [];
      let newDose = 0;
      let newDeflections = 0;

      for (let p of particlesRef.current) {
        // Distance to ship and shield center
        const dx = p.x - shieldCenterX;
        const dy = p.y - shieldCenterY;
        const distToShield = Math.sqrt(dx * dx + dy * dy);

        // Lorentz Force Physics Deflection: F = q * (v x B)
        if (distToShield < effectiveShieldRadius && !p.deflected) {
          // Deflection angle offset by gimbal
          const angleToCoil = Math.atan2(dy, dx) - gimbalRad;
          const forceMag = (effectiveTesla * 850) / Math.max(25, distToShield);

          // Deflect trajectory away from ship's center
          p.vy += Math.sin(angleToCoil) * forceMag * p.charge * dt * 8;
          p.vx -= Math.cos(angleToCoil) * forceMag * 0.4 * dt * 8;

          p.deflected = true;
          newDeflections++;
        }

        // Move particle
        p.x += p.vx * dt;
        p.y += p.vy * dt;

        // Check Collision with Spacecraft Crew Habitat (Box approx: shipX - 10 to shipX + 40, shipY - 25 to shipY + 25)
        const hitShip = (
          p.x >= shipX - 15 &&
          p.x <= shipX + 35 &&
          p.y >= shipY - 28 &&
          p.y <= shipY + 28
        );

        if (hitShip) {
          // Crew absorbs ionising radiation
          p.absorbed = true;
          newDose += p.charge > 0 ? 0.35 : 0.08; // Protons carry heavy ionisation dose
        } else if (p.x < width + 40 && p.y > -50 && p.y < height + 50) {
          nextParticles.push(p);

          // Draw Particle with Ion Trail
          ctx.fillStyle = p.deflected ? '#34D399' : p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.fill();

          // Particle Motion Tail
          ctx.strokeStyle = p.deflected ? 'rgba(52, 211, 153, 0.4)' : p.color === '#F59E0B' ? 'rgba(245, 158, 11, 0.3)' : 'rgba(56, 189, 248, 0.3)';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x - p.vx * 0.04, p.y - p.vy * 0.04);
          ctx.stroke();
        }
      }

      particlesRef.current = nextParticles;

      if (newDeflections > 0 && Math.random() < 0.25) {
        playDeflectAudioTone(440 + Math.random() * 200);
      }

      if (newDose > 0) {
        setRadiationDoseMSv((d) => {
          const total = d + newDose;
          if (total >= 75) {
            setGameOver(true);
            setIsPlaying(false);
          }
          return total;
        });
      }

      if (newDeflections > 0) {
        setParticlesDeflectedCount((c) => c + newDeflections);
      }

      // 5. Render Spacecraft & Crew Module
      ctx.save();
      ctx.translate(shipX, shipY);

      // Solar Panels
      ctx.fillStyle = '#1E3A8A';
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 1;
      ctx.fillRect(0, -42, 16, 26);
      ctx.strokeRect(0, -42, 16, 26);
      ctx.fillRect(0, 16, 16, 26);
      ctx.strokeRect(0, 16, 16, 26);

      // Habitat Core Hull
      ctx.fillStyle = '#E2E8F0';
      ctx.beginPath();
      ctx.roundRect(-10, -16, 36, 32, [6, 12, 12, 6]);
      ctx.fill();

      // Cockpit Dome Glass
      ctx.fillStyle = '#38BDF8';
      ctx.beginPath();
      ctx.arc(16, 0, 7, -Math.PI / 2, Math.PI / 2);
      ctx.fill();

      // Hull Label
      ctx.fillStyle = '#0F172A';
      ctx.font = 'bold 7px monospace';
      ctx.fillText('AX-1', -4, 3);

      ctx.restore();

      // Loop
      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying, gameOver, gameWon, magneticFluxTesla, gimbalAngleDeg, stormLevel, isOverdriveActive]);

  return (
    <div className="bg-[#0B1120] border border-white/10 rounded-2xl p-5 sm:p-7 text-[#F5F1E8] shadow-2xl relative overflow-hidden">
      {/* Background Decorative Gradient */}
      <div className="absolute -top-32 -left-32 w-80 h-80 rounded-full bg-[#C65B43]/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-80 h-80 rounded-full bg-[#38BDF8]/15 blur-3xl pointer-events-none" />

      {/* Top Banner & Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5 mb-5 relative z-10">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-[#F59E0B]/10 border border-[#F59E0B]/30 text-[#F59E0B] text-xs font-mono uppercase tracking-wider mb-2">
            <Sun className="w-3.5 h-3.5 animate-spin-slow" />
            <span>SOLAR SPACE WEATHER & MAGNETO-SHIELD LAB</span>
          </div>
          <h3 className="text-2xl sm:text-3xl font-display font-extrabold tracking-tight text-white flex items-center gap-3">
            Helios CME Shield Defender
          </h3>
          <p className="text-xs sm:text-sm text-[#9298A3] mt-1 max-w-2xl">
            Coronal Mass Ejections (CMEs) fire gigatons of relativistic protons across interplanetary space. Modulate your superconducting magnetic deflector coil to shield your crew habitat from lethal ionizing radiation.
          </p>
        </div>

        {/* Storm Scenario Level Toggle */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 self-start md:self-auto">
          <div className="flex items-center space-x-1.5 bg-white/5 p-1 rounded-xl border border-white/10">
            {(['DONKI-Live', 'X-Class', 'M-Class', 'C-Class'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => {
                  setStormLevel(lvl);
                  resetGame();
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all cursor-pointer ${
                  stormLevel === lvl
                    ? lvl === 'DONKI-Live'
                      ? 'bg-[#38BDF8] text-black font-bold shadow-lg shadow-[#38BDF8]/30'
                      : lvl === 'X-Class'
                      ? 'bg-[#C65B43] text-white font-bold shadow-lg shadow-[#C65B43]/30'
                      : 'bg-[#F59E0B] text-white font-bold shadow-lg shadow-[#F59E0B]/30'
                    : 'text-[#9298A3] hover:text-white'
                }`}
              >
                {lvl === 'DONKI-Live' ? '🛰️ NASA DONKI' : lvl}
              </button>
            ))}
          </div>

          {stormLevel === 'DONKI-Live' && (
            <select
              value={activeDonkiEvent.activityID}
              onChange={(e) => {
                const found = BUNDLED_DONKI_CMES.find((c) => c.activityID === e.target.value);
                if (found) {
                  setActiveDonkiEvent(found);
                  resetGame();
                }
              }}
              className="bg-white/10 border border-white/20 rounded-xl px-2.5 py-1.5 text-xs font-mono text-white focus:outline-none"
            >
              {BUNDLED_DONKI_CMES.map((c) => (
                <option key={c.activityID} value={c.activityID} className="bg-[#0B1120] text-white">
                  {c.activityID.slice(0, 10)} ({c.speedKmS} km/s)
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      {/* Telemetry Status Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5 font-mono text-xs relative z-10">
        <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span className="text-[#9298A3] flex items-center gap-1.5 text-[11px]">
            <Activity className="w-3.5 h-3.5 text-[#38BDF8]" />
            CUMULATIVE DOSE
          </span>
          <div className="mt-1 flex items-baseline gap-1">
            <span
              className={`text-xl font-bold ${
                radiationDoseMSv > 50 ? 'text-[#EF4444]' : radiationDoseMSv > 25 ? 'text-[#F59E0B]' : 'text-[#34D399]'
              }`}
            >
              {radiationDoseMSv.toFixed(1)}
            </span>
            <span className="text-[10px] text-[#9298A3]">mSv / 75 limit</span>
          </div>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span className="text-[#9298A3] flex items-center gap-1.5 text-[11px]">
            <Shield className="w-3.5 h-3.5 text-[#34D399]" />
            PARTICLES DEFLECTED
          </span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-xl font-bold text-white">{particlesDeflectedCount}</span>
            <span className="text-[10px] text-[#9298A3]">ions</span>
          </div>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span className="text-[#9298A3] flex items-center gap-1.5 text-[11px]">
            <BatteryCharging className="w-3.5 h-3.5 text-[#FBBF24]" />
            CRYO-COIL POWER
          </span>
          <div className="mt-1 flex items-baseline gap-1">
            <span
              className={`text-xl font-bold ${
                cryoPowerPercent < 25 ? 'text-[#EF4444]' : 'text-[#FBBF24]'
              }`}
            >
              {Math.round(cryoPowerPercent)}%
            </span>
            <span className="text-[10px] text-[#9298A3]">coolant</span>
          </div>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-xl p-3 flex flex-col justify-between">
          <span className="text-[#9298A3] flex items-center gap-1.5 text-[11px]">
            <Compass className="w-3.5 h-3.5 text-[#A855F7]" />
            STORM ELAPSED
          </span>
          <div className="mt-1 flex items-baseline gap-1">
            <span className="text-xl font-bold text-[#A855F7]">
              {stormElapsedSec}s
            </span>
            <span className="text-[10px] text-[#9298A3]">/ {stormDurationSec}s</span>
          </div>
        </div>
      </div>

      {/* Main Interactive Canvas */}
      <div className="relative rounded-xl overflow-hidden border border-white/15 shadow-inner mb-5">
        <canvas ref={canvasRef} className="w-full block" />

        {/* Canvas HUD Overlays */}
        <div className="absolute top-3 left-3 flex items-center space-x-2 pointer-events-none">
          <span className="px-2 py-0.5 rounded bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-mono text-[#F59E0B]">
            SUN CORONAL FLUX
          </span>
        </div>

        <div className="absolute top-3 right-3 flex items-center space-x-2 pointer-events-none">
          <span className="px-2 py-0.5 rounded bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-mono text-[#38BDF8]">
            HABITAT AX-1
          </span>
        </div>

        {/* Start Game Overlay Banner */}
        {!isPlaying && !gameOver && !gameWon && (
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center">
            <Sun className="w-12 h-12 text-[#F59E0B] mb-3 animate-pulse" />
            <h4 className="text-xl font-bold text-white mb-2 font-display">
              {stormLevel} Solar Storm Eruption Detected
            </h4>
            <p className="text-xs text-[#9298A3] max-w-md mb-5 leading-relaxed font-mono">
              High-energy protons are streaming across interplanetary space. Aim your deflector coils, modulate magnetic flux, and survive the 25-second solar storm.
            </p>
            <button
              onClick={handleStartGame}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#F59E0B] to-[#C65B43] hover:brightness-110 text-white font-mono font-bold text-xs flex items-center space-x-2 shadow-lg shadow-[#F59E0B]/30 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>ENGAGE MAGNETO-SHIELD</span>
            </button>
          </div>
        )}

        {/* Victory Overlay */}
        {gameWon && (
          <div className="absolute inset-0 bg-[#0B1120]/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
            <CheckCircle2 className="w-12 h-12 text-[#34D399] mb-3" />
            <h4 className="text-xl font-bold text-white mb-1 font-display">
              CME Storm Successfully Deflected!
            </h4>
            <p className="text-xs text-[#34D399] font-mono mb-2">
              +250 XP AWARDED • HELIOS SHIELD COMMANDER BADGE UNLOCKED
            </p>
            <p className="text-xs text-[#9298A3] max-w-sm mb-5 font-mono">
              Final Dose: {radiationDoseMSv.toFixed(1)} mSv (Safe threshold maintained). {particlesDeflectedCount} energetic ions diverted away from crew habitat!
            </p>
            <button
              onClick={resetGame}
              className="px-5 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-mono text-xs flex items-center space-x-2 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>RUN ANOTHER SIMULATION</span>
            </button>
          </div>
        )}

        {/* Critical Failure Overlay */}
        {gameOver && (
          <div className="absolute inset-0 bg-red-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
            <AlertTriangle className="w-12 h-12 text-[#EF4444] mb-3 animate-bounce" />
            <h4 className="text-xl font-bold text-white mb-1 font-display">
              Radiation Safety Threshold Breached!
            </h4>
            <p className="text-xs text-[#EF4444] font-mono mb-4">
              Crew absorbed {radiationDoseMSv.toFixed(1)} mSv. Increase magnetic flux and align deflector coils toward incoming proton tracks.
            </p>
            <button
              onClick={handleStartGame}
              className="px-5 py-2 rounded-xl bg-[#C65B43] hover:bg-[#b04a33] text-white font-mono text-xs flex items-center space-x-2 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>RETRY DEFENSE SYSTEM</span>
            </button>
          </div>
        )}
      </div>

      {/* Physics Controls Deck */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs relative z-10">
        {/* Slider 1: Magnetic Flux Tesla */}
        <div className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-2">
          <div className="flex justify-between items-center text-[#9298A3]">
            <span className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-[#38BDF8]" />
              MAGNETIC FLUX (B)
            </span>
            <span className="text-white font-bold">{magneticFluxTesla.toFixed(1)} Tesla</span>
          </div>
          <input
            type="range"
            min="0.2"
            max="3.0"
            step="0.1"
            value={magneticFluxTesla}
            onChange={(e) => setMagneticFluxTesla(parseFloat(e.target.value))}
            className="w-full accent-[#38BDF8] cursor-pointer"
          />
          <p className="text-[10px] text-[#9298A3]">
            Stronger fields bend higher energy protons (Lorentz force: F = q·v×B) but consume more cryo-power.
          </p>
        </div>

        {/* Slider 2: Deflector Gimbal Orientation */}
        <div className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-2">
          <div className="flex justify-between items-center text-[#9298A3]">
            <span className="flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-[#F59E0B]" />
              GIMBAL ANGLE (θ)
            </span>
            <span className="text-white font-bold">
              {gimbalAngleDeg > 0 ? `+${gimbalAngleDeg}°` : `${gimbalAngleDeg}°`}
            </span>
          </div>
          <input
            type="range"
            min="-45"
            max="45"
            step="1"
            value={gimbalAngleDeg}
            onChange={(e) => setGimbalAngleDeg(parseInt(e.target.value))}
            className="w-full accent-[#F59E0B] cursor-pointer"
          />
          <p className="text-[10px] text-[#9298A3]">
            Align the dipole magnetic field bubble to deflect incoming coronal shock fronts around the habitat.
          </p>
        </div>

        {/* Overdrive Action Button */}
        <div className="bg-white/5 p-4 rounded-xl border border-white/10 flex flex-col justify-between space-y-2">
          <div>
            <div className="flex justify-between items-center text-[#9298A3] mb-1">
              <span className="flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-[#34D399]" />
                CRYO OVERDRIVE
              </span>
              <span className={`font-bold ${isOverdriveActive ? 'text-[#34D399] animate-pulse' : 'text-white'}`}>
                {isOverdriveActive ? 'ACTIVE (2.5x)' : 'STANDBY'}
              </span>
            </div>
            <p className="text-[10px] text-[#9298A3]">
              Superconductor burst boosts magnetic flux by +250% for 3.5s. Costs 30% cryo-coolant.
            </p>
          </div>

          <button
            onClick={triggerOverdrive}
            disabled={!isPlaying || isOverdriveActive || cryoPowerPercent < 25}
            className={`w-full py-2 rounded-lg font-mono text-xs font-bold transition-all flex items-center justify-center space-x-2 ${
              isOverdriveActive
                ? 'bg-[#34D399] text-black shadow-lg shadow-[#34D399]/40'
                : cryoPowerPercent >= 25 && isPlaying
                ? 'bg-gradient-to-r from-[#34D399] to-[#38BDF8] text-black hover:brightness-110 cursor-pointer'
                : 'bg-white/5 text-[#9298A3] cursor-not-allowed border border-white/5'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isOverdriveActive ? 'OVERDRIVE ACTIVE' : 'TRIGGER CRYO SURGE'}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
