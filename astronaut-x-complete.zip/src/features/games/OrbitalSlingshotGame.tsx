import React, { useState, useEffect, useRef } from 'react';
import {
  Orbit, Play, RotateCcw, Target, Sparkles, CheckCircle2,
  AlertTriangle, Compass, Award, Flame, Zap
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { soundManager } from '../../utils/audio';
import { useProgress } from '../../context/ProgressContext';

interface CelestialBody {
  name: string;
  x: number;
  y: number;
  r: number;
  mass: number;
  color: string;
  gravityWellRadius: number;
}

export default function OrbitalSlingshotGame() {
  const { addXp, completeMission } = useProgress();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [gameState, setGameState] = useState<'ready' | 'flying' | 'escaped' | 'crashed' | 'lost'>('ready');
  const [launchAngle, setLaunchAngle] = useState<number>(35); // degrees
  const [injectionDeltaV, setInjectionDeltaV] = useState<number>(3.8); // km/s
  const [currentSpeed, setCurrentSpeed] = useState<number>(0);
  const [gravityAssistsCount, setGravityAssistsCount] = useState<number>(0);
  const [fuelRemaining, setFuelRemaining] = useState<number>(100);

  // Solar system planetary layout for gravity assist
  const bodies: CelestialBody[] = [
    { name: 'Sun', x: 70, y: 360, r: 24, mass: 2800, color: '#FBBF24', gravityWellRadius: 80 },
    { name: 'Earth', x: 180, y: 300, r: 12, mass: 650, color: '#38BDF8', gravityWellRadius: 55 },
    { name: 'Mars', x: 320, y: 220, r: 9, mass: 420, color: '#C65B43', gravityWellRadius: 48 },
    { name: 'Jupiter', x: 500, y: 140, r: 22, mass: 1900, color: '#F59E0B', gravityWellRadius: 90 },
  ];

  const probeRef = useRef({
    x: 180,
    y: 300,
    vx: 0,
    vy: 0,
    trail: [] as { x: number; y: number }[],
    active: false,
    assists: new Set<string>(),
  });

  const resetGame = () => {
    probeRef.current = {
      x: 180,
      y: 300,
      vx: 0,
      vy: 0,
      trail: [],
      active: false,
      assists: new Set(),
    };
    setGameState('ready');
    setCurrentSpeed(0);
    setGravityAssistsCount(0);
    setFuelRemaining(100);
  };

  const handleLaunchProbe = () => {
    if (gameState === 'flying') return;
    soundManager.playLaunch();

    const rad = (launchAngle * Math.PI) / 180;
    const speed = injectionDeltaV * 1.4;

    probeRef.current.x = 180;
    probeRef.current.y = 280;
    probeRef.current.vx = speed * Math.cos(rad);
    probeRef.current.vy = -speed * Math.sin(rad);
    probeRef.current.trail = [{ x: 180, y: 280 }];
    probeRef.current.active = true;
    probeRef.current.assists.clear();

    setGameState('flying');
    setGravityAssistsCount(0);
  };

  const handleMidCourseBurn = () => {
    if (gameState !== 'flying' || fuelRemaining <= 0) return;
    soundManager.playClick();
    setFuelRemaining((prev) => Math.max(0, prev - 25));

    // Boost speed in current flight direction
    const probe = probeRef.current;
    const speed = Math.hypot(probe.vx, probe.vy);
    if (speed > 0) {
      probe.vx *= 1.25;
      probe.vy *= 1.25;
    }
  };

  // 60FPS Multi-body Gravity Simulation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      const probe = probeRef.current;

      ctx.clearRect(0, 0, width, height);
      ctx.fillStyle = '#080C16';
      ctx.fillRect(0, 0, width, height);

      // Draw Gravity Wells & Planetary Bodies
      bodies.forEach((body) => {
        // Gravity well outer glow
        const wellGrad = ctx.createRadialGradient(body.x, body.y, body.r, body.x, body.y, body.gravityWellRadius);
        wellGrad.addColorStop(0, `${body.color}33`);
        wellGrad.addColorStop(1, 'transparent');
        ctx.fillStyle = wellGrad;
        ctx.beginPath();
        ctx.arc(body.x, body.y, body.gravityWellRadius, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = `${body.color}44`;
        ctx.setLineDash([2, 4]);
        ctx.beginPath();
        ctx.arc(body.x, body.y, body.gravityWellRadius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);

        // Body sphere
        ctx.fillStyle = body.color;
        ctx.beginPath();
        ctx.arc(body.x, body.y, body.r, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#FFFFFF';
        ctx.font = '10px monospace';
        ctx.fillText(body.name, body.x - 14, body.y + body.r + 14);
      });

      // Target Escape Gateway (Interstellar Boundary)
      ctx.fillStyle = 'rgba(52, 211, 153, 0.15)';
      ctx.fillRect(width - 45, 0, 45, height);
      ctx.strokeStyle = '#34D399';
      ctx.beginPath();
      ctx.moveTo(width - 45, 0);
      ctx.lineTo(width - 45, height);
      ctx.stroke();

      ctx.save();
      ctx.translate(width - 15, height / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.fillStyle = '#34D399';
      ctx.font = '10px monospace';
      ctx.fillText('INTERSTELLAR ESCAPE BOUNDARY', -90, 0);
      ctx.restore();

      // Draw Probe Trail
      if (probe.trail.length > 1) {
        ctx.beginPath();
        ctx.moveTo(probe.trail[0].x, probe.trail[0].y);
        for (let i = 1; i < probe.trail.length; i++) {
          ctx.lineTo(probe.trail[i].x, probe.trail[i].y);
        }
        ctx.strokeStyle = '#38BDF8';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }

      // Physics Step for Probe
      if (gameState === 'flying' && probe.active) {
        let ax = 0;
        let ay = 0;

        bodies.forEach((body) => {
          const dx = body.x - probe.x;
          const dy = body.y - probe.y;
          const distSq = dx * dx + dy * dy;
          const dist = Math.sqrt(distSq);

          // Check planetary collision
          if (dist < body.r + 3) {
            probe.active = false;
            setGameState('crashed');
            soundManager.playAlarm();
          }

          // Check if inside Gravity Well for Slingshot assist
          if (dist < body.gravityWellRadius && !probe.assists.has(body.name)) {
            probe.assists.add(body.name);
            setGravityAssistsCount(probe.assists.size);
            soundManager.playSuccess();
          }

          // Newtonian Gravitational Force: a = G * M / r^2
          if (distSq > 100) {
            const force = body.mass / distSq;
            ax += force * (dx / dist);
            ay += force * (dy / dist);
          }
        });

        probe.vx += ax * 0.12;
        probe.vy += ay * 0.12;
        probe.x += probe.vx;
        probe.y += probe.vy;

        const currentSpeedKms = +(Math.hypot(probe.vx, probe.vy) * 2.8).toFixed(1);
        setCurrentSpeed(currentSpeedKms);

        probe.trail.push({ x: probe.x, y: probe.y });
        if (probe.trail.length > 300) probe.trail.shift();

        // Check if reached Interstellar Escape
        if (probe.x >= width - 45) {
          probe.active = false;
          setGameState('escaped');
          addXp(300, 'Interstellar Gravity Assist Slingshot Success');
          completeMission('slingshot-escape', 300);
          confetti({ particleCount: 80, spread: 75, origin: { y: 0.6 } });
        } else if (probe.x < 0 || probe.y < 0 || probe.y > height) {
          probe.active = false;
          setGameState('lost');
        }
      }

      // Draw Probe
      if (probe.active || gameState === 'ready') {
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.arc(probe.x, probe.y, 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#38BDF8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(probe.x, probe.y, 7, 0, Math.PI * 2);
        ctx.stroke();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [gameState, bodies]);

  return (
    <div className="bg-[#101827]/90 rounded-2xl border border-white/10 p-5 sm:p-7 shadow-2xl space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-[#38BDF8]/20 text-[#38BDF8] border border-[#38BDF8]/40 font-bold">
              ORBITAL MECHANICS SIM
            </span>
            <span className="text-xs font-mono text-[#9298A3]">VOYAGER GRAND TOUR SLINGSHOT</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-display font-bold text-white mt-1">
            Orbital Slingshot & Gravity Assist Navigator
          </h3>
        </div>

        <button
          onClick={resetGame}
          className="px-3.5 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-white font-mono text-xs flex items-center space-x-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>RELOAD TRAJECTORY</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Canvas Display Viewport */}
        <div className="lg:col-span-8 bg-black rounded-xl overflow-hidden border border-white/10 relative">
          <canvas
            ref={canvasRef}
            width={720}
            height={440}
            className="w-full h-[400px] object-cover"
          />

          {/* Telemetry Overlay */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-2 text-[10px] font-mono">
            <div className="px-2.5 py-1 rounded bg-black/70 backdrop-blur-md border border-white/10 text-white">
              VELOCITY: <strong className="text-[#38BDF8]">{currentSpeed} km/s</strong>
            </div>
            <div className="px-2.5 py-1 rounded bg-black/70 backdrop-blur-md border border-white/10 text-[#34D399]">
              GRAVITY ASSISTS: {gravityAssistsCount} / 3 PLANETS
            </div>
            <div className="px-2.5 py-1 rounded bg-black/70 backdrop-blur-md border border-white/10 text-[#FBBF24]">
              RCS FUEL: {fuelRemaining}%
            </div>
          </div>

          {/* Success Banner */}
          {gameState === 'escaped' && (
            <div className="absolute inset-0 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
              <CheckCircle2 className="w-12 h-12 text-[#34D399] mb-2" />
              <h4 className="text-2xl font-display font-bold text-white mb-1">INTERSTELLAR ESCAPE VELOCITY ACHIEVED!</h4>
              <p className="text-xs text-[#9298A3] max-w-md mb-4">
                By slingshotting through planetary gravity wells, your probe gained hyperbolic excess velocity without burning extra fuel—just like Voyager 1 & 2!
              </p>
              <div className="font-mono text-sm text-[#FBBF24] mb-4">+300 XP AWARDED • FINAL SPEED: {currentSpeed} km/s</div>
              <button
                onClick={resetGame}
                className="px-6 py-2.5 rounded-xl bg-[#34D399] text-[#080B12] font-mono text-xs font-bold uppercase cursor-pointer"
              >
                PLOT NEW MISSION
              </button>
            </div>
          )}

          {gameState === 'crashed' && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
              <AlertTriangle className="w-12 h-12 text-red-500 mb-2" />
              <h4 className="text-2xl font-display font-bold text-white mb-1">PLANETARY IMPACT!</h4>
              <p className="text-xs text-red-200 max-w-md mb-4">
                Probe entered the dense atmosphere or crashed into a celestial body. Adjust your launch angle to perform a flyby outside the physical radius.
              </p>
              <button
                onClick={resetGame}
                className="px-6 py-2.5 rounded-xl bg-red-500 text-white font-mono text-xs font-bold uppercase cursor-pointer"
              >
                RECALCULATE SLINGSHOT
              </button>
            </div>
          )}

          {gameState === 'lost' && (
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-in fade-in">
              <AlertTriangle className="w-12 h-12 text-[#FBBF24] mb-2" />
              <h4 className="text-2xl font-display font-bold text-white mb-1">TRAJECTORY DEFICIT</h4>
              <p className="text-xs text-white/80 max-w-md mb-4">
                Probe drifted into solar orbit without reaching escape velocity. Use Mid-Course RCS Burns or align with Jupiter's massive gravity well.
              </p>
              <button
                onClick={resetGame}
                className="px-6 py-2.5 rounded-xl bg-[#FBBF24] text-black font-mono text-xs font-bold uppercase cursor-pointer"
              >
                TRY AGAIN
              </button>
            </div>
          )}
        </div>

        {/* Flight Trajectory Controls */}
        <div className="lg:col-span-4 bg-[#0A0F1D] rounded-xl border border-white/10 p-5 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-white/10 pb-2">
            <span className="text-[#34D399] uppercase font-bold">TRAJECTORY CONTROLS</span>
            <Compass className="w-4 h-4 text-[#34D399]" />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-white/80">
              <span>Earth Ejection Angle:</span>
              <span className="text-white font-bold">{launchAngle}°</span>
            </div>
            <input
              type="range"
              min={10}
              max={75}
              value={launchAngle}
              onChange={(e) => setLaunchAngle(Number(e.target.value))}
              disabled={gameState === 'flying'}
              className="w-full accent-[#38BDF8] cursor-pointer"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-white/80">
              <span>Trans-Mars Injection Δv:</span>
              <span className="text-white font-bold">{injectionDeltaV} km/s</span>
            </div>
            <input
              type="range"
              min={2.2}
              max={5.5}
              step={0.1}
              value={injectionDeltaV}
              onChange={(e) => setInjectionDeltaV(Number(e.target.value))}
              disabled={gameState === 'flying'}
              className="w-full accent-[#FBBF24] cursor-pointer"
            />
          </div>

          <div className="p-3 rounded-lg bg-white/[0.02] border border-white/5 text-[11px] text-[#9298A3] leading-relaxed font-sans">
            💡 <strong>Gravity Assist Principle:</strong> When a spacecraft performs a close flyby behind an orbiting planet, it gains linear momentum relative to the Sun, accelerating into the outer solar system for free!
          </div>

          {/* Action Buttons */}
          <div className="space-y-2">
            <button
              onClick={handleLaunchProbe}
              disabled={gameState === 'flying'}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#38BDF8] to-[#0284C7] disabled:opacity-50 text-[#080B12] font-display font-bold text-xs uppercase tracking-wider flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-lg shadow-[#38BDF8]/20"
            >
              <Orbit className="w-4 h-4" />
              <span>LAUNCH DEEP SPACE PROBE</span>
            </button>

            {gameState === 'flying' && (
              <button
                onClick={handleMidCourseBurn}
                disabled={fuelRemaining <= 0}
                className="w-full py-3 rounded-xl bg-[#FBBF24] hover:bg-[#F59E0B] disabled:opacity-30 text-black font-display font-bold text-xs uppercase flex items-center justify-center space-x-1.5 cursor-pointer shadow animate-pulse"
              >
                <Zap className="w-4 h-4" />
                <span>FIRE RCS CORRECTION BURN (-25% FUEL)</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
